<?php
/**
 * Serves the Fileora web app (public/fileora.html) on the homepage or on a
 * chosen path, plus one page per tool (e.g. /merge-pdf/) with its own title,
 * description and canonical link for search engines. The WordPress settings
 * are injected into the app's CONFIG object. Everything else (blog, pages,
 * wp-admin) keeps working as normal.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Frontend {

	/** @var array|null Tool list from public/tools.json (written by the build). */
	private static $tools = null;

	public static function init() {
		add_action( 'template_redirect', array( __CLASS__, 'maybe_serve' ), 0 );
		add_action( 'init', array( __CLASS__, 'register_sitemap' ) );
	}

	/** All tools, keyed by page slug. */
	public static function tools() {
		if ( null === self::$tools ) {
			self::$tools = array();
			$file        = FILEORA_DIR . 'public/tools.json';
			$list        = file_exists( $file ) ? json_decode( (string) file_get_contents( $file ), true ) : array(); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			$disabled    = (array) Fileora_Settings::get()['disabled'];
			foreach ( (array) $list as $tool ) {
				if ( isset( $tool['slug'], $tool['id'] ) && ! in_array( $tool['id'], $disabled, true ) ) {
					self::$tools[ $tool['slug'] ] = $tool;
				}
			}
		}
		return self::$tools;
	}

	/** Site-relative path of the app, without slashes: '' (homepage) or e.g. 'tools'. */
	private static function base() {
		$s = Fileora_Settings::get();
		return 'path' === $s['serve'] ? trim( $s['path'], '/' ) : '';
	}

	/** Absolute URL path of the app with a trailing slash, e.g. '/' or '/tools/'. */
	public static function base_path() {
		$home = rtrim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
		$base = self::base();
		return $home . '/' . ( '' !== $base ? $base . '/' : '' );
	}

	/** Full URL of the app itself. */
	public static function app_url() {
		$base = self::base();
		return home_url( '/' . ( '' !== $base ? $base . '/' : '' ) );
	}

	public static function tool_url( array $tool ) {
		$base = self::base();
		return home_url( '/' . ( '' !== $base ? $base . '/' : '' ) . $tool['slug'] . '/' );
	}

	private static function requested_path() {
		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/';
		$path = trim( (string) wp_parse_url( $uri, PHP_URL_PATH ), '/' );
		$home = trim( (string) wp_parse_url( home_url(), PHP_URL_PATH ), '/' );
		if ( '' !== $home && 0 === strpos( $path, $home ) ) {
			$path = trim( substr( $path, strlen( $home ) ), '/' );
		}
		return $path;
	}

	/**
	 * What to serve for this request.
	 *
	 * @return false|array False for "not ours", otherwise ['tool' => array|null].
	 */
	public static function match() {
		$s = Fileora_Settings::get();
		if ( 'off' === $s['serve'] || is_admin() || wp_doing_ajax() || is_feed() || is_robots() ) {
			return false;
		}
		// Admins can see the theme instead: add ?fileora-theme=1 to the URL.
		if ( isset( $_GET['fileora-theme'] ) && current_user_can( 'manage_options' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return false;
		}
		$path = self::requested_path();
		$base = self::base();
		if ( $path === $base ) {
			return array( 'tool' => null );
		}
		if ( ! empty( $s['tool_pages'] ) ) {
			$prefix = '' !== $base ? $base . '/' : '';
			if ( '' === $prefix || 0 === strpos( $path, $prefix ) ) {
				$slug  = substr( $path, strlen( $prefix ) );
				$tools = self::tools();
				if ( isset( $tools[ $slug ] ) ) {
					return array( 'tool' => $tools[ $slug ] );
				}
			}
		}
		return false;
	}

	/** Values the app reads from its CONFIG object. */
	public static function config() {
		$s = Fileora_Settings::get();
		return apply_filters(
			'fileora_config',
			array(
				'apiBase'   => untrailingslashit( rest_url( Fileora_REST::NS ) ),
				'maxFileMB' => Fileora_Settings::max_mb( get_current_user_id() ),
				'nonce'     => is_user_logged_in() ? wp_create_nonce( 'wp_rest' ) : '',
				'disabled'  => array_values( (array) $s['disabled'] ),
				'toolPages' => ! empty( $s['tool_pages'] ),
				'toolBase'  => self::base_path(),
			)
		);
	}

	private static function replace_tag( $html, $pattern, $replacement ) {
		return preg_replace_callback(
			$pattern,
			function () use ( $replacement ) {
				return $replacement;
			},
			$html,
			1
		);
	}

	public static function render( $tool = null ) {
		$file = FILEORA_DIR . 'public/fileora.html';
		$html = file_exists( $file ) ? file_get_contents( $file ) : false; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		if ( false === $html ) {
			return false;
		}
		$json = wp_json_encode( self::config(), JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP );
		$html = self::replace_tag( $html, '/const CONFIG = \{[^}]*\};/', 'const CONFIG = ' . $json . ';' );

		// Search-engine tags: one title, description and canonical address per page.
		$site = get_bloginfo( 'name' );
		if ( $tool ) {
			$title = sprintf( '%s online, free | %s', $tool['name'], $site );
			$desc  = $tool['desc'] . ( ! empty( $tool['browser'] ) ? ' Free, no sign-up, and your files never leave your device.' : ' Free and no sign-up. Files are deleted automatically.' );
			$url   = self::tool_url( $tool );
			$html  = self::replace_tag( $html, '#<title>.*?</title>#s', '<title>' . esc_html( $title ) . '</title>' );
			$html  = self::replace_tag( $html, '#<meta name="description" content="[^"]*">#', '<meta name="description" content="' . esc_attr( $desc ) . '">' );
			$html  = self::replace_tag( $html, '#<meta property="og:title" content="[^"]*">#', '<meta property="og:title" content="' . esc_attr( $title ) . '">' );
			$html  = self::replace_tag( $html, '#<meta property="og:description" content="[^"]*">#', '<meta property="og:description" content="' . esc_attr( $desc ) . '">' );
		} else {
			$url = self::app_url();
		}
		$html = str_replace( '</head>', '<link rel="canonical" href="' . esc_url( $url ) . '">' . "\n" . '<meta property="og:url" content="' . esc_url( $url ) . '">' . "\n</head>", $html );

		// Point the app's account links at WordPress.
		$html = str_replace(
			array( 'href="/login"', 'href="/signup"' ),
			array( 'href="' . esc_url( wp_login_url() ) . '"', 'href="' . esc_url( wp_registration_url() ) . '"' ),
			$html
		);
		return apply_filters( 'fileora_html', $html, $tool );
	}

	public static function maybe_serve() {
		$match = self::match();
		if ( false === $match ) {
			return;
		}
		$html = self::render( $match['tool'] );
		if ( false === $html ) {
			Fileora_Log::error( 'public/fileora.html is missing' );
			return; // fall back to the theme
		}
		status_header( 200 );
		header( 'Content-Type: text/html; charset=utf-8' );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Referrer-Policy: strict-origin-when-cross-origin' );
		if ( is_user_logged_in() ) {
			nocache_headers(); // the page contains a personal nonce
		}
		echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- complete HTML document shipped with the plugin
		exit;
	}

	/** Adds the app and every tool page to WordPress's own sitemap (wp-sitemap.xml). */
	public static function register_sitemap() {
		$s = Fileora_Settings::get();
		if ( 'off' === $s['serve'] || ! function_exists( 'wp_register_sitemap_provider' ) || ! class_exists( 'WP_Sitemaps_Provider' ) ) {
			return;
		}
		require_once FILEORA_DIR . 'includes/class-fileora-sitemap.php';
		wp_register_sitemap_provider( 'fileora', new Fileora_Sitemap() );
	}
}
