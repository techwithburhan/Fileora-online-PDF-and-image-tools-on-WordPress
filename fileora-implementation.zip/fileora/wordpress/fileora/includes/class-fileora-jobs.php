<?php
/**
 * Job records: one row per server task. Holds no file contents, only what is
 * needed for status checks, daily limits and usage statistics.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Jobs {

	const DB_VERSION = '1';

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'fileora_jobs';
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table   = self::table();
		$collate = $wpdb->get_charset_collate();
		dbDelta(
			"CREATE TABLE {$table} (
			id char(32) NOT NULL,
			tool varchar(20) NOT NULL,
			token_hash char(64) NOT NULL,
			status varchar(12) NOT NULL DEFAULT 'queued',
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			ip_hash char(64) NOT NULL,
			files smallint(5) unsigned NOT NULL DEFAULT 0,
			bytes_in bigint(20) unsigned NOT NULL DEFAULT 0,
			result_name varchar(200) DEFAULT NULL,
			bytes_out bigint(20) unsigned DEFAULT NULL,
			error varchar(255) DEFAULT NULL,
			created_at datetime NOT NULL,
			finished_at datetime DEFAULT NULL,
			downloaded_at datetime DEFAULT NULL,
			PRIMARY KEY  (id),
			KEY created_at (created_at),
			KEY ip_created (ip_hash, created_at)
			) {$collate};"
		);
		update_option( 'fileora_db_version', self::DB_VERSION, false );
	}

	public static function maybe_upgrade() {
		if ( get_option( 'fileora_db_version' ) !== self::DB_VERSION ) {
			self::install();
		}
	}

	public static function create( array $row ) {
		global $wpdb;
		$row['created_at'] = gmdate( 'Y-m-d H:i:s' );
		return false !== $wpdb->insert( self::table(), $row ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
	}

	public static function find( $id ) {
		global $wpdb;
		$table = self::table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %s", $id ) );
	}

	public static function update( $id, array $data ) {
		global $wpdb;
		return $wpdb->update( self::table(), $data, array( 'id' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/** Stores the final outcome reported by the processing server, once. */
	public static function finish( $row, array $status ) {
		if ( in_array( $row->status, array( 'done', 'failed' ), true ) ) {
			return;
		}
		self::update(
			$row->id,
			array(
				'status'      => 'done' === $status['status'] ? 'done' : 'failed',
				'result_name' => isset( $status['name'] ) ? substr( sanitize_file_name( $status['name'] ), 0, 200 ) : null,
				'bytes_out'   => isset( $status['size'] ) ? (int) $status['size'] : null,
				'error'       => isset( $status['error'] ) ? substr( sanitize_text_field( $status['error'] ), 0, 255 ) : null,
				'finished_at' => gmdate( 'Y-m-d H:i:s' ),
			)
		);
	}

	/** Tasks started by this visitor (or account) in the last 24 hours. */
	public static function count_recent( $ip_hash, $user_id ) {
		global $wpdb;
		$table = self::table();
		$since = gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS );
		if ( $user_id ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND created_at >= %s", $user_id, $since ) );
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE ip_hash = %s AND created_at >= %s", $ip_hash, $since ) );
	}

	/** Usage per tool for the dashboard. */
	public static function stats( $days = 30 ) {
		global $wpdb;
		$table = self::table();
		$since = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $wpdb->get_results( $wpdb->prepare( "SELECT tool, COUNT(*) AS total, SUM(status = 'done') AS done, SUM(status = 'failed') AS failed, ROUND(AVG(CASE WHEN finished_at IS NOT NULL THEN TIMESTAMPDIFF(SECOND, created_at, finished_at) END)) AS avg_seconds, SUM(bytes_in) AS bytes_in FROM {$table} WHERE created_at >= %s GROUP BY tool ORDER BY total DESC", $since ) );
	}

	public static function recent_failures( $limit = 10 ) {
		global $wpdb;
		$table = self::table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $wpdb->get_results( $wpdb->prepare( "SELECT tool, error, created_at FROM {$table} WHERE status = 'failed' ORDER BY created_at DESC LIMIT %d", $limit ) );
	}

	/** Jobs that never reported back (server restarted, visitor left) are closed. */
	public static function fail_stale( $seconds ) {
		global $wpdb;
		$table = self::table();
		$since = gmdate( 'Y-m-d H:i:s', time() - $seconds );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET status = 'failed', error = 'No result before the time limit', finished_at = %s WHERE status IN ('queued','running') AND created_at < %s", gmdate( 'Y-m-d H:i:s' ), $since ) );
	}

	public static function purge( $days ) {
		global $wpdb;
		$table = self::table();
		$since = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE created_at < %s", $since ) );
	}
}
