<?php
/**
 * Hourly housekeeping (WP-Cron). Files are deleted by the processing service
 * itself; this closes stuck job records and removes old ones.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Cleanup {

	const HOOK = 'fileora_cleanup';

	public static function init() {
		add_action( self::HOOK, array( __CLASS__, 'run' ) );
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + 300, 'hourly', self::HOOK );
		}
	}

	public static function unschedule() {
		wp_clear_scheduled_hook( self::HOOK );
	}

	public static function run() {
		Fileora_Jobs::fail_stale( 2 * HOUR_IN_SECONDS );
		Fileora_Jobs::purge( (int) Fileora_Settings::get()['retention_days'] );
	}
}
