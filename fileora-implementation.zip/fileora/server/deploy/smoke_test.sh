#!/usr/bin/env bash
# Checks the processing service end to end: health, then a real job
# (Protect PDF) through submit -> status -> download -> delete.
#   sudo bash deploy/smoke_test.sh
set -euo pipefail
KEY=$(grep '^FILEORA_KEY=' /etc/fileora/fileora.env | cut -d= -f2-)
BASE=${BASE:-http://127.0.0.1:8000}
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
echo "1) Health:"; curl -fsS "$BASE/health" | head -c 400; echo
# a valid one-page PDF made by Ghostscript
gs -q -dNOPAUSE -dBATCH -dSAFER -sDEVICE=pdfwrite -o "$TMP/test.pdf" -c showpage
echo "2) Submit Protect PDF job:"
JOB=$(curl -fsS -H "X-Fileora-Key: $KEY" -F "files[]=@$TMP/test.pdf" -F 'options={"pw":"secret123"}' "$BASE/jobs/protect" | python3 -c 'import sys,json; print(json.load(sys.stdin)["job"])')
echo "   job $JOB"
for i in $(seq 1 30); do
  STATUS=$(curl -fsS -H "X-Fileora-Key: $KEY" "$BASE/jobs/$JOB" | python3 -c 'import sys,json; d=json.load(sys.stdin); print(d["status"], d.get("error",""))')
  echo "   status: $STATUS"
  case "$STATUS" in done*) break;; failed*) exit 1;; esac
  sleep 1
done
curl -fsS -H "X-Fileora-Key: $KEY" -o "$TMP/out.pdf" "$BASE/jobs/$JOB/file"
qpdf --requires-password "$TMP/out.pdf" && echo "3) Download OK: the result needs a password." || { echo "3) Result is not protected"; exit 1; }
curl -fsS -X DELETE -H "X-Fileora-Key: $KEY" "$BASE/jobs/$JOB" >/dev/null && echo "4) Job deleted. All good."
