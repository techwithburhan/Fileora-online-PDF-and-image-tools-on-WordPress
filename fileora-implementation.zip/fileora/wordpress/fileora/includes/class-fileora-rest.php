<?php
/**
 * REST API: /wp-json/fileora/v1/...
 *
 *   POST /jobs/{tool}        upload files, start a job      -> 202 {job, token, status}
 *   GET  /jobs/{id}          job status (X-Fileora-Token)   -> {status, ahead, kind, name, size, text, error}
 *   GET  /jobs/{id}/file     download result (X-Fileora-Token)
 *   GET  /health             processing server status (admins only)
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_REST {

	const NS = 'fileora/v1';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function routes() {
		register_rest_route(
			self::NS,
			'/jobs/(?P<tool>[a-z][a-z0-9]{1,19})',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'submit' ),
				'permission_callback' => '__return_true', // public tools; limits are enforced in submit()
			)
		);
		register_rest_route(
			self::NS,
			'/jobs/(?P<id>[a-f0-9]{32})',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'status' ),
				'permission_callback' => '__return_true', // access is checked with the job token
			)
		);
		register_rest_route(
			self::NS,
			'/jobs/(?P<id>[a-f0-9]{32})/file',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'file' ),
				'permission_callback' => '__return_true',
			)
		);
		register_rest_route(
			self::NS,
			'/health',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'health' ),
				'permission_callback' => function () {
					return current_user_can( 'manage_options' );
				},
			)
		);
	}

	private static function error( $message, $status ) {
		$response = new WP_REST_Response( array( 'error' => $message ), $status );
		$response->header( 'Cache-Control', 'no-store' );
		return $response;
	}

	/** POST /jobs/{tool} */
	public static function submit( WP_REST_Request $request ) {
		$settings = Fileora_Settings::get();
		$tool     = (string) $request['tool'];
		$def      = Fileora_Tools::get( $tool );

		if ( ! $def ) {
			return self::error( 'Unknown tool.', 404 );
		}
		if ( ! Fileora_Tools::enabled( $tool ) ) {
			return self::error( sprintf( '%s is switched off on this site.', $def['label'] ), 403 );
		}
		if ( empty( $settings['service_key'] ) ) {
			return self::error( 'The processing server isn’t connected yet.', 503 );
		}

		// Daily limit per visitor (or per account when logged in). Admins are never limited.
		$user_id = get_current_user_id();
		$ip_hash = Fileora_Security::ip_hash();
		$limit   = (int) apply_filters( 'fileora_daily_limit', (int) $settings['daily_limit'], $user_id );
		if ( $limit > 0 && ! current_user_can( 'manage_options' ) && Fileora_Jobs::count_recent( $ip_hash, $user_id ) >= $limit ) {
			return self::error( sprintf( 'You’ve reached the limit of %d tasks in 24 hours. Please try again later.', $limit ), 429 );
		}

		/**
		 * Last check before a job is created, e.g. Cloudflare Turnstile or "members only".
		 * Return a WP_Error to refuse; its message is shown to the visitor.
		 */
		$allowed = apply_filters( 'fileora_pre_submit', true, $request, $tool );
		if ( is_wp_error( $allowed ) ) {
			$data = $allowed->get_error_data();
			return self::error( $allowed->get_error_message(), isset( $data['status'] ) ? (int) $data['status'] : 403 );
		}

		// Files.
		$raw       = $request->get_file_params();
		$files     = Fileora_Security::normalize_files( isset( $raw['files'] ) ? $raw['files'] : null );
		$max_bytes = Fileora_Settings::max_mb( $user_id ) * MB_IN_BYTES;
		$max_files = min( (int) $settings['max_files'], (int) $def['max_files'] );
		if ( '' !== $def['accept'] ) {
			if ( ! $files ) {
				return self::error( 'Add a file first.', 400 );
			}
			if ( count( $files ) > $max_files ) {
				return self::error( sprintf( '%s accepts up to %d files at a time.', $def['label'], $max_files ), 400 );
			}
		} elseif ( $files ) {
			return self::error( 'This tool doesn’t take files.', 400 );
		}
		$bytes = 0;
		foreach ( $files as $file ) {
			$check = Fileora_Security::validate_file( $file, $def['accept'], $max_bytes );
			if ( is_wp_error( $check ) ) {
				return self::error( $check->get_error_message(), $check->get_error_data()['status'] );
			}
			$bytes += $file['size'];
		}

		// Options (JSON from the browser) and the web address for HTML to PDF.
		$options = (string) $request->get_param( 'options' );
		if ( strlen( $options ) > 20000 || ! is_array( json_decode( $options, true ) ) ) {
			$options = '{}';
		}
		$url = '';
		if ( 'html2pdf' === $tool ) {
			$url = esc_url_raw( trim( (string) $request->get_param( 'url' ) ), array( 'http', 'https' ) );
			if ( '' === $url ) {
				return self::error( 'Enter a web address, like https://example.com.', 400 );
			}
		}

		$result = Fileora_Processor::submit( $tool, $files, $options, $url );
		if ( is_wp_error( $result ) ) {
			return self::error( $result->get_error_message(), 502 );
		}
		if ( 202 !== $result['status'] || empty( $result['body']['job'] ) ) {
			$message = isset( $result['body']['error'] ) ? $result['body']['error'] : 'The processing server couldn’t accept this file.';
			$code    = $result['status'] >= 400 && $result['status'] < 500 && 401 !== $result['status'] ? $result['status'] : 502;
			if ( 401 === $result['status'] ) {
				Fileora_Log::error( 'service rejected the shared key; check FILEORA_KEY' );
				$message = 'The processing server isn’t set up correctly. Please try again later.';
			}
			return self::error( $message, $code );
		}

		list( $token, $hash ) = Fileora_Security::new_token();
		$job_id               = sanitize_key( $result['body']['job'] );
		Fileora_Jobs::create(
			array(
				'id'         => $job_id,
				'tool'       => $tool,
				'token_hash' => $hash,
				'status'     => 'queued',
				'user_id'    => $user_id,
				'ip_hash'    => $ip_hash,
				'files'      => count( $files ),
				'bytes_in'   => $bytes,
			)
		);
		do_action( 'fileora_job_created', $job_id, $tool, $user_id );

		$response = new WP_REST_Response(
			array(
				'job'    => $job_id,
				'token'  => $token,
				'status' => 'queued',
			),
			202
		);
		$response->header( 'Cache-Control', 'no-store' );
		return $response;
	}

	/** Finds the job and checks the browser's token. */
	private static function authorized_job( WP_REST_Request $request ) {
		$row = Fileora_Jobs::find( (string) $request['id'] );
		if ( ! $row || ! Fileora_Security::token_matches( $request->get_header( 'x_fileora_token' ), $row->token_hash ) ) {
			return self::error( 'This task wasn’t found. Please run it again.', 404 );
		}
		return $row;
	}

	/** GET /jobs/{id} */
	public static function status( WP_REST_Request $request ) {
		$row = self::authorized_job( $request );
		if ( $row instanceof WP_REST_Response ) {
			return $row;
		}
		if ( 'failed' === $row->status ) {
			$response = new WP_REST_Response(
				array(
					'status' => 'failed',
					'error'  => $row->error ? $row->error : 'The task failed.',
				),
				200
			);
			$response->header( 'Cache-Control', 'no-store' );
			return $response;
		}

		$result = Fileora_Processor::status( $row->id );
		if ( is_wp_error( $result ) ) {
			return self::error( 'Lost contact with the processing server. Please try again.', 502 );
		}
		if ( 404 === $result['status'] ) {
			Fileora_Jobs::finish( $row, array( 'status' => 'failed', 'error' => 'Expired' ) );
			return self::error( 'This task has expired. Please run it again.', 410 );
		}
		$body = $result['body'];
		$out  = array_intersect_key( $body, array_flip( array( 'status', 'ahead', 'kind', 'name', 'size', 'error', 'text' ) ) );

		if ( isset( $body['status'] ) && in_array( $body['status'], array( 'done', 'failed' ), true ) ) {
			Fileora_Jobs::finish( $row, $body );
			if ( 'done' === $body['status'] && isset( $body['kind'] ) && 'text' === $body['kind'] ) {
				Fileora_Processor::delete( $row->id ); // the text is in this response; nothing left to download
			}
			do_action( 'fileora_job_finished', $row->id, $row->tool, $body['status'] );
		}
		$response = new WP_REST_Response( $out, 200 );
		$response->header( 'Cache-Control', 'no-store' );
		return $response;
	}

	/** GET /jobs/{id}/file: streams the file, then deletes it on the server. */
	public static function file( WP_REST_Request $request ) {
		$row = self::authorized_job( $request );
		if ( $row instanceof WP_REST_Response ) {
			return $row;
		}
		if ( 'done' !== $row->status ) {
			return self::error( 'This task isn’t finished yet.', 409 );
		}
		if ( $row->downloaded_at ) {
			return self::error( 'This file was already downloaded and has been deleted from the server. Please run the task again.', 410 );
		}
		$sent = Fileora_Processor::stream( $row->id, $row->result_name ? $row->result_name : 'fileora-result' );
		if ( is_wp_error( $sent ) ) {
			return self::error( $sent->get_error_message(), 502 );
		}
		Fileora_Jobs::update( $row->id, array( 'downloaded_at' => gmdate( 'Y-m-d H:i:s' ) ) );
		Fileora_Processor::delete( $row->id );
		exit;
	}

	/** GET /health (admins) */
	public static function health() {
		$health = Fileora_Processor::health();
		if ( is_wp_error( $health ) ) {
			return self::error( $health->get_error_message(), 502 );
		}
		return new WP_REST_Response( $health, 200 );
	}
}
