<?php
/**
 * Settings screen.
 *
 * @package Fileora
 * @var array          $s
 * @var array          $tools
 * @var array|WP_Error $health
 * @var int            $upload
 * @var string         $site_url
 */

defined( 'ABSPATH' ) || exit;
$name  = Fileora_Settings::OPTION;
$ready = is_array( $health ) && isset( $health['tools'] ) ? $health['tools'] : array();
?>
<div class="wrap">
	<h1>Fileora settings</h1>
	<?php settings_errors(); ?>

	<?php if ( is_wp_error( $health ) ) : ?>
		<div class="notice notice-error"><p><strong>The processing server can’t be reached</strong> at <code><?php echo esc_html( $s['service_url'] ); ?></code>. Browser tools still work; server tools will fail until it runs. See README section 7.</p></div>
	<?php elseif ( empty( $health['key_set'] ) ) : ?>
		<div class="notice notice-warning"><p>The processing server is running but has no <code>FILEORA_KEY</code>. Copy the shared key below into <code>/etc/fileora/fileora.env</code> and restart it.</p></div>
	<?php endif; ?>

	<?php if ( $upload < $s['max_mb'] * MB_IN_BYTES ) : ?>
		<div class="notice notice-warning"><p>PHP accepts uploads up to <strong><?php echo esc_html( size_format( $upload ) ); ?></strong>, less than the <?php echo (int) $s['max_mb']; ?> MB set below. Raise <code>upload_max_filesize</code> and <code>post_max_size</code> (README section 7.6).</p></div>
	<?php endif; ?>

	<form method="post" action="options.php">
		<?php settings_fields( 'fileora' ); ?>

		<h2 class="title">Website</h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row">Show Fileora on</th>
				<td>
					<fieldset>
						<label><input type="radio" name="<?php echo esc_attr( $name ); ?>[serve]" value="home" <?php checked( $s['serve'], 'home' ); ?>> The homepage</label><br>
						<label><input type="radio" name="<?php echo esc_attr( $name ); ?>[serve]" value="path" <?php checked( $s['serve'], 'path' ); ?>> This address only: <code><?php echo esc_html( home_url( '/' ) ); ?></code><input type="text" class="regular-text" style="width:12em" name="<?php echo esc_attr( $name ); ?>[path]" value="<?php echo esc_attr( $s['path'] ); ?>"></label><br>
						<label><input type="radio" name="<?php echo esc_attr( $name ); ?>[serve]" value="off" <?php checked( $s['serve'], 'off' ); ?>> Nowhere (API only)</label>
					</fieldset>
					<p class="description">Currently at <a href="<?php echo esc_url( $site_url ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $site_url ); ?></a>. Admins can add <code>?fileora-theme=1</code> to see the theme instead.</p>
				</td>
			</tr>
			<tr>
				<th scope="row">Tool pages</th>
				<td>
					<label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[tool_pages]" value="1" <?php checked( ! empty( $s['tool_pages'] ) ); ?>> Give every tool its own address, like <code><?php echo esc_html( trailingslashit( $site_url ) ); ?>merge-pdf/</code></label>
					<p class="description">Recommended for Google: each tool page gets its own title, description and canonical link, and is listed in <a href="<?php echo esc_url( home_url( '/wp-sitemap.xml' ) ); ?>" target="_blank" rel="noopener">wp-sitemap.xml</a>. A tool page wins over a WordPress page with the same address.</p>
				</td>
			</tr>
		</table>

		<h2 class="title">Processing server</h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><label for="fileora-url">Server address</label></th>
				<td><input id="fileora-url" type="url" class="regular-text" name="<?php echo esc_attr( $name ); ?>[service_url]" value="<?php echo esc_attr( $s['service_url'] ); ?>">
				<p class="description">Usually <code>http://127.0.0.1:8000</code> (same VPS). Never expose this port to the internet.</p></td>
			</tr>
			<tr>
				<th scope="row"><label for="fileora-key">Shared key</label></th>
				<td><input id="fileora-key" type="text" class="large-text code" name="<?php echo esc_attr( $name ); ?>[service_key]" value="<?php echo esc_attr( $s['service_key'] ); ?>" autocomplete="off" spellcheck="false">
				<p class="description">Must equal <code>FILEORA_KEY</code> in <code>/etc/fileora/fileora.env</code>. <label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[new_key]" value="1"> Generate a new key on save</label></p></td>
			</tr>
		</table>

		<h2 class="title">Limits</h2>
		<table class="form-table" role="presentation">
			<tr><th scope="row"><label for="fileora-mb">Max file size</label></th><td><input id="fileora-mb" type="number" min="1" max="2048" name="<?php echo esc_attr( $name ); ?>[max_mb]" value="<?php echo (int) $s['max_mb']; ?>" class="small-text"> MB per file</td></tr>
			<tr><th scope="row"><label for="fileora-files">Max files</label></th><td><input id="fileora-files" type="number" min="1" max="100" name="<?php echo esc_attr( $name ); ?>[max_files]" value="<?php echo (int) $s['max_files']; ?>" class="small-text"> per task</td></tr>
			<tr><th scope="row"><label for="fileora-limit">Server tasks</label></th><td><input id="fileora-limit" type="number" min="0" name="<?php echo esc_attr( $name ); ?>[daily_limit]" value="<?php echo (int) $s['daily_limit']; ?>" class="small-text"> per visitor in 24 hours <p class="description">0 means no limit. Browser tools are never limited. Developers can raise it per user with the <code>fileora_daily_limit</code> filter (e.g. for Pro members).</p></td></tr>
			<tr><th scope="row"><label for="fileora-ret">Keep task records</label></th><td><input id="fileora-ret" type="number" min="1" max="365" name="<?php echo esc_attr( $name ); ?>[retention_days]" value="<?php echo (int) $s['retention_days']; ?>" class="small-text"> days <p class="description">Records hold the tool, size and status for statistics, never the files.</p></td></tr>
		</table>

		<h2 class="title">Server tools</h2>
		<p>Browser tools (Merge, Split, Sign, Watermark, ...) are always on. Turn off server tools that this server can’t run yet; they disappear from the website.</p>
		<table class="widefat striped" style="max-width:820px">
			<thead><tr><th>On</th><th>Tool</th><th>Needs</th><th>Server status</th></tr></thead>
			<tbody>
			<?php foreach ( $tools as $id => $t ) : ?>
				<tr>
					<td><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[enabled][]" value="<?php echo esc_attr( $id ); ?>" <?php checked( ! in_array( $id, (array) $s['disabled'], true ) ); ?> aria-label="<?php echo esc_attr( $t['label'] ); ?>"></td>
					<td><?php echo esc_html( $t['label'] ); ?></td>
					<td><?php echo esc_html( $t['needs'] ); ?></td>
					<td>
					<?php
					if ( ! isset( $ready[ $id ] ) ) {
						echo '<span style="color:#787c82">Unknown</span>';
					} elseif ( $ready[ $id ] ) {
						echo '<span style="color:#008a20">Ready</span>';
					} else {
						echo '<span style="color:#d63638">Not available</span>';
					}
					?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php submit_button( 'Save settings' ); ?>
	</form>
</div>
