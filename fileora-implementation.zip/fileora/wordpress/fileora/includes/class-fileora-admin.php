<?php
/**
 * Admin screens: Fileora → Dashboard and Fileora → Settings.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Admin {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( FILEORA_FILE ), array( __CLASS__, 'links' ) );
	}

	public static function menu() {
		add_menu_page( 'Fileora', 'Fileora', 'manage_options', 'fileora', array( __CLASS__, 'dashboard' ), 'dashicons-media-document', 58 );
		add_submenu_page( 'fileora', 'Fileora dashboard', 'Dashboard', 'manage_options', 'fileora', array( __CLASS__, 'dashboard' ) );
		add_submenu_page( 'fileora', 'Fileora settings', 'Settings', 'manage_options', 'fileora-settings', array( __CLASS__, 'settings' ) );
	}

	public static function register() {
		register_setting(
			'fileora',
			Fileora_Settings::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( 'Fileora_Settings', 'sanitize' ),
			)
		);
	}

	public static function links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=fileora-settings' ) ) . '">Settings</a>' );
		return $links;
	}

	/** Health is cached for a minute so the dashboard stays fast. */
	public static function health() {
		$cached = get_transient( 'fileora_health' );
		if ( false !== $cached ) {
			return $cached;
		}
		$health = Fileora_Processor::health();
		if ( ! is_wp_error( $health ) ) {
			set_transient( 'fileora_health', $health, MINUTE_IN_SECONDS );
		}
		return $health;
	}

	public static function dashboard() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$health   = self::health();
		$stats    = Fileora_Jobs::stats( 30 );
		$failures = Fileora_Jobs::recent_failures( 10 );
		$tools    = Fileora_Tools::all();
		include FILEORA_DIR . 'admin/views/dashboard.php';
	}

	public static function settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s        = Fileora_Settings::get();
		$tools    = Fileora_Tools::all();
		$health   = self::health();
		$upload   = wp_max_upload_size();
		$site_url = 'home' === $s['serve'] ? home_url( '/' ) : home_url( '/' . $s['path'] . '/' );
		include FILEORA_DIR . 'admin/views/settings.php';
	}
}
