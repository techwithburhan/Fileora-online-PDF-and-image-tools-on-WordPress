<?php
/**
 * Plugin settings, stored in one option: fileora_settings.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Settings {

	const OPTION = 'fileora_settings';

	public static function defaults() {
		return array(
			'service_url'    => 'http://127.0.0.1:8000',
			'service_key'    => '',
			'serve'          => 'home',   // home | path | off
			'path'           => 'tools',
			'tool_pages'     => 1,        // every tool gets its own address, e.g. /merge-pdf/
			'max_mb'         => 100,
			'max_files'      => 20,
			'daily_limit'    => 30,       // server tasks per visitor per 24 h, 0 = no limit
			'retention_days' => 30,       // how long job records (no files) stay for statistics
			'disabled'       => array( 'edit', 'summarize', 'translate' ),
		);
	}

	public static function get() {
		$saved = get_option( self::OPTION, array() );
		return wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
	}

	/** File size limit in MB for a user (0 = visitor). Filter it to give members more. */
	public static function max_mb( $user_id = 0 ) {
		return max( 1, (int) apply_filters( 'fileora_max_mb', (int) self::get()['max_mb'], (int) $user_id ) );
	}

	/** Called on activation: keeps existing values, creates a shared key once. */
	public static function ensure_defaults() {
		$settings = self::get();
		if ( empty( $settings['service_key'] ) ) {
			$settings['service_key'] = wp_generate_password( 48, false, false );
		}
		update_option( self::OPTION, $settings, false );
	}

	public static function sanitize( $input ) {
		$d   = self::defaults();
		$old = self::get();
		$in  = is_array( $input ) ? $input : array();

		$url = isset( $in['service_url'] ) ? esc_url_raw( trim( $in['service_url'] ), array( 'http', 'https' ) ) : '';
		$key = isset( $in['service_key'] ) ? preg_replace( '/[^A-Za-z0-9_\-]/', '', $in['service_key'] ) : '';
		if ( ! empty( $in['new_key'] ) ) {
			$key = wp_generate_password( 48, false, false );
		}
		$serve = isset( $in['serve'] ) && in_array( $in['serve'], array( 'home', 'path', 'off' ), true ) ? $in['serve'] : $d['serve'];
		$path  = isset( $in['path'] ) ? trim( sanitize_title_with_dashes( $in['path'] ), '/' ) : $d['path'];

		$enabled  = isset( $in['enabled'] ) ? array_map( 'sanitize_key', (array) $in['enabled'] ) : array();
		$disabled = array_values( array_diff( array_keys( Fileora_Tools::all() ), $enabled ) );

		return array(
			'service_url'    => $url ? untrailingslashit( $url ) : $old['service_url'],
			'service_key'    => strlen( $key ) >= 24 ? $key : $old['service_key'],
			'serve'          => $serve,
			'path'           => $path ? $path : $d['path'],
			'tool_pages'     => empty( $in['tool_pages'] ) ? 0 : 1,
			'max_mb'         => max( 1, min( 2048, absint( isset( $in['max_mb'] ) ? $in['max_mb'] : $d['max_mb'] ) ) ),
			'max_files'      => max( 1, min( 100, absint( isset( $in['max_files'] ) ? $in['max_files'] : $d['max_files'] ) ) ),
			'daily_limit'    => min( 100000, absint( isset( $in['daily_limit'] ) ? $in['daily_limit'] : $d['daily_limit'] ) ),
			'retention_days' => max( 1, min( 365, absint( isset( $in['retention_days'] ) ? $in['retention_days'] : $d['retention_days'] ) ) ),
			'disabled'       => $disabled,
		);
	}
}
