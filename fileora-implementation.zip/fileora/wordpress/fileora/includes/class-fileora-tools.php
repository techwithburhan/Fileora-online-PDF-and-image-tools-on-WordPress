<?php
/**
 * Registry of the tools that run on the processing server.
 * Browser tools (merge, split, sign, ...) never reach WordPress.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Tools {

	/** File extensions per input group. Must match the processing service. */
	const EXTENSIONS = array(
		'pdf'   => array( 'pdf' ),
		'word'  => array( 'doc', 'docx', 'odt', 'rtf', 'txt' ),
		'ppt'   => array( 'ppt', 'pptx', 'pps', 'ppsx', 'odp' ),
		'excel' => array( 'xls', 'xlsx', 'ods', 'csv' ),
	);

	/**
	 * Server tools: label, accepted input group ('' = web address), most files per job.
	 *
	 * @return array<string, array{label:string, accept:string, max_files:int, needs:string}>
	 */
	public static function all() {
		$tools = array(
			'compress'  => array( 'Compress PDF', 'pdf', 20, 'Ghostscript' ),
			'repair'    => array( 'Repair PDF', 'pdf', 1, 'qpdf, Ghostscript' ),
			'ocr'       => array( 'OCR PDF', 'pdf', 10, 'OCRmyPDF, Tesseract' ),
			'pdfa'      => array( 'PDF to PDF/A', 'pdf', 10, 'OCRmyPDF, Ghostscript' ),
			'word2pdf'  => array( 'Word to PDF', 'word', 20, 'LibreOffice' ),
			'ppt2pdf'   => array( 'PowerPoint to PDF', 'ppt', 20, 'LibreOffice' ),
			'excel2pdf' => array( 'Excel to PDF', 'excel', 20, 'LibreOffice' ),
			'html2pdf'  => array( 'HTML to PDF', '', 0, 'Chromium (Playwright)' ),
			'pdf2word'  => array( 'PDF to Word', 'pdf', 10, 'pdf2docx' ),
			'pdf2ppt'   => array( 'PDF to PowerPoint', 'pdf', 10, 'PyMuPDF, python-pptx' ),
			'pdf2excel' => array( 'PDF to Excel', 'pdf', 10, 'pdfplumber, openpyxl' ),
			'edit'      => array( 'Edit PDF', 'pdf', 1, 'Editor screen (not built yet)' ),
			'forms'     => array( 'PDF Forms', 'pdf', 1, 'PyMuPDF' ),
			'protect'   => array( 'Protect PDF', 'pdf', 20, 'qpdf' ),
			'unlock'    => array( 'Unlock PDF', 'pdf', 20, 'qpdf' ),
			'redact'    => array( 'Redact PDF', 'pdf', 1, 'PyMuPDF' ),
			'summarize' => array( 'AI Summarizer', 'pdf', 1, 'Claude API key' ),
			'translate' => array( 'Translate PDF', 'pdf', 1, 'Claude API key' ),
		);
		$out = array();
		foreach ( $tools as $id => $t ) {
			$out[ $id ] = array(
				'label'     => $t[0],
				'accept'    => $t[1],
				'max_files' => $t[2],
				'needs'     => $t[3],
			);
		}
		/**
		 * Filter the server tool registry, e.g. to add a new tool.
		 */
		return apply_filters( 'fileora_server_tools', $out );
	}

	public static function get( $id ) {
		$all = self::all();
		return isset( $all[ $id ] ) ? $all[ $id ] : null;
	}

	public static function enabled( $id ) {
		$settings = Fileora_Settings::get();
		return null !== self::get( $id ) && ! in_array( $id, (array) $settings['disabled'], true );
	}
}
