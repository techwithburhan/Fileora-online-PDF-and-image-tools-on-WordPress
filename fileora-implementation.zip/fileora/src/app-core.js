/* =====================================================================
   Fileora — single-page PDF tools
   ---------------------------------------------------------------------
   15 tools run fully in the browser (pdf-lib + pdf.js, loaded on demand).
   The other tools run as jobs on a processing server (see README.md):
       POST {apiBase}/jobs/{toolId}   multipart: files[], options (JSON), url
            -> 202 { job, token }
       GET  {apiBase}/jobs/{job}      header X-Fileora-Token -> { status, ahead, kind, name, size, text, error }
       GET  {apiBase}/jobs/{job}/file header X-Fileora-Token -> the result file
   On WordPress the Fileora plugin fills in CONFIG automatically:
       apiBase  REST base, e.g. https://example.com/wp-json/fileora/v1
       nonce    REST nonce for logged-in users
       disabled tool ids switched off in WordPress -> Fileora -> Settings
       toolPages true when every tool has its own address, e.g. /merge-pdf/
       toolBase  the address the app lives at, e.g. / or /tools/
   ===================================================================== */
'use strict';
const CONFIG = { apiBase: '', maxFileMB: 200, nonce: '', disabled: [], toolPages: false, toolBase: '/' };

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const icon = (n, cls = 'ic') => `<svg class="${cls}" aria-hidden="true"><use href="#i-${n}"/></svg>`;
const HAS_GSAP = () => typeof window.gsap !== 'undefined';
const REDUCED = matchMedia('(prefers-reduced-motion: reduce)').matches;
const IS_MAC = /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent);
const store = {
  get(k, d) { try { const v = localStorage.getItem('fileora.' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem('fileora.' + k, JSON.stringify(v)); } catch (e) { /* storage unavailable */ } }
};
function fmtSize(b) { if (b < 1024) return b + ' B'; if (b < 1048576) return (b / 1024).toFixed(b < 10240 ? 1 : 0) + ' KB'; return (b / 1048576).toFixed(b < 10485760 ? 2 : 1) + ' MB'; }
function baseName(n) { return String(n).replace(/\.[^.]+$/, '') || 'file'; }
function extOf(n) { const m = /\.([^.]+)$/.exec(n || ''); return m ? m[1].toLowerCase() : ''; }

/* ---------------- data ---------------- */
const CATS = [
  { id: 'organize', name: 'Organize', desc: 'Combine, split, reorder and rotate pages.' },
  { id: 'optimize', name: 'Optimize', desc: 'Shrink files, fix damaged ones and make scans searchable.' },
  { id: 'to', name: 'Convert to PDF', tab: 'To PDF', desc: 'Turn documents, images, web pages and scans into PDFs.' },
  { id: 'from', name: 'Convert from PDF', tab: 'From PDF', desc: 'Get editable Word, Excel and PowerPoint files, images or Markdown.' },
  { id: 'edit', name: 'Edit and sign', desc: 'Add text, signatures, watermarks, page numbers and form fields.' },
  { id: 'security', name: 'Security', desc: 'Lock, unlock and permanently black out sensitive content.' },
  { id: 'ai', name: 'AI and review', desc: 'Summarize, translate and compare documents.' },
  { id: 'image', name: 'Images', desc: 'Compress, resize, crop and convert photos, right in your browser.' },
  { id: 'workflows', name: 'Workflows', desc: 'Chain tools together and run them in one go.' }
];
const CAT = Object.fromEntries(CATS.map(c => [c.id, c]));

const ACCEPT = {
  pdf: { ext: ['pdf'], input: '.pdf,application/pdf', noun: 'PDF', nouns: 'PDF files' },
  image: { ext: ['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp', 'avif'], input: 'image/*', noun: 'image', nouns: 'images' },
  word: { ext: ['doc', 'docx', 'odt', 'rtf', 'txt'], input: '.doc,.docx,.odt,.rtf,.txt', noun: 'Word file', nouns: 'Word files' },
  ppt: { ext: ['ppt', 'pptx', 'pps', 'ppsx', 'odp'], input: '.ppt,.pptx,.pps,.ppsx,.odp', noun: 'PowerPoint file', nouns: 'PowerPoint files' },
  excel: { ext: ['xls', 'xlsx', 'ods', 'csv'], input: '.xls,.xlsx,.ods,.csv', noun: 'spreadsheet', nouns: 'spreadsheets' },
  html: { ext: ['html', 'htm'], input: '.html,.htm', noun: 'HTML file', nouns: 'HTML files' }
};
const LANGS = [['en', 'English'], ['hi', 'Hindi'], ['bn', 'Bengali'], ['ta', 'Tamil'], ['te', 'Telugu'], ['mr', 'Marathi'], ['ur', 'Urdu'], ['ar', 'Arabic'], ['zh', 'Chinese (Simplified)'], ['ja', 'Japanese'], ['ko', 'Korean'], ['fr', 'French'], ['de', 'German'], ['es', 'Spanish'], ['pt', 'Portuguese'], ['it', 'Italian'], ['ru', 'Russian'], ['tr', 'Turkish'], ['id', 'Indonesian']];

const pageSizeOpt = (v = 'a4') => ({ id: 'size', type: 'seg', label: 'Page size', value: v, choices: [['fit', 'Fit image'], ['a4', 'A4'], ['letter', 'US Letter']] });
const orientOpt = { id: 'orient', type: 'seg', label: 'Orientation', value: 'auto', choices: [['auto', 'Auto'], ['portrait', 'Portrait'], ['landscape', 'Landscape']], show: o => o.size !== 'fit' };
const marginOpt = { id: 'margin', type: 'seg', label: 'Margin', value: 'small', choices: [['none', 'None'], ['small', 'Small'], ['large', 'Large']] };

const TOOLS = [
  /* organize */
  { id: 'merge', name: 'Merge PDF', cat: 'organize', icon: 'merge', client: true, accept: 'pdf', multi: true, min: 2,
    desc: 'Combine several PDFs into one file, in exactly the order you want.', keys: 'combine join append together one file',
    cta: 'Merge PDF', verb: 'Merging', tip: 'Drag the files to change their order. The file marked 1 comes first.', opts: [] },
  { id: 'split', name: 'Split PDF', cat: 'organize', icon: 'split', client: true, accept: 'pdf', multi: false,
    desc: 'Pull out page ranges or break a PDF into separate files.', keys: 'extract pages separate divide cut remove',
    cta: 'Split PDF', verb: 'Splitting', opts: [
      { id: 'mode', type: 'seg', label: 'Split by', value: 'ranges', choices: [['ranges', 'Page ranges'], ['all', 'Every page'], ['chunk', 'Fixed size']] },
      { id: 'ranges', type: 'text', label: 'Pages to extract', value: '1-2', placeholder: 'For example: 1-3, 5, 8-', help: 'Use commas between ranges. “8-” means page 8 to the end.', show: o => o.mode === 'ranges' },
      { id: 'together', type: 'toggle', label: 'Put all ranges in one PDF', value: false, show: o => o.mode === 'ranges' },
      { id: 'chunk', type: 'number', label: 'Pages per file', value: 2, min: 1, max: 999, suffix: 'pages', show: o => o.mode === 'chunk' }
    ] },
  { id: 'organize', name: 'Organize PDF', cat: 'organize', icon: 'organize', client: true, accept: 'pdf', multi: false, pages: true,
    desc: 'Reorder, rotate and delete pages using a visual page view.', keys: 'reorder sort pages delete remove move arrange',
    cta: 'Save PDF', verb: 'Saving', tip: 'Drag pages to reorder them. Use the buttons under each page to rotate or delete it.', opts: [] },
  { id: 'rotate', name: 'Rotate PDF', cat: 'organize', icon: 'rotate', client: true, accept: 'pdf', multi: true,
    desc: 'Turn pages the right way up, for one file or a whole batch at once.', keys: 'turn orientation flip sideways landscape',
    cta: 'Rotate PDF', verb: 'Rotating', opts: [
      { id: 'angle', type: 'seg', label: 'Rotate', value: '90', choices: [['90', '90° right'], ['180', '180°'], ['270', '90° left']] },
      { id: 'which', type: 'seg', label: 'Pages', value: 'all', choices: [['all', 'All'], ['odd', 'Odd'], ['even', 'Even']] }
    ] },
  /* optimize */
  { id: 'compress', name: 'Compress PDF', cat: 'optimize', icon: 'compress', client: true, serverFirst: true, accept: 'pdf', multi: true,
    desc: 'Make PDFs smaller for email and uploads while keeping them readable.', keys: 'shrink reduce size smaller optimize email kb mb',
    cta: 'Compress PDF', verb: 'Compressing', opts: [
      { id: 'level', type: 'seg', label: 'Compression', value: 'balanced', wrap: false, choices: [['light', 'Light'], ['balanced', 'Balanced'], ['strong', 'Strong']],
        help: o => (CONFIG.apiBase ? { light: 'Best quality, smaller savings.', balanced: 'Good quality at a much smaller size. Text stays selectable.', strong: 'Smallest file for email. Images get lower resolution.' }
          : { light: 'Lossless clean-up. Text stays selectable; savings are smaller.', balanced: 'Good quality at a much smaller size. Pages become images.', strong: 'Smallest file for email. Pages become lower-resolution images.' })[o.level] }
    ] },
  { id: 'repair', name: 'Repair PDF', cat: 'optimize', icon: 'repair', client: true, serverFirst: true, accept: 'pdf', multi: false,
    desc: 'Recover what you can from a damaged or corrupt PDF.', keys: 'fix broken corrupt damaged recover',
    cta: 'Repair PDF', verb: 'Repairing', opts: [] },
  { id: 'ocr', name: 'OCR PDF', cat: 'optimize', icon: 'ocr', accept: 'pdf', multi: true,
    desc: 'Turn scanned PDFs into searchable text you can select and copy.', keys: 'scan text recognition searchable selectable',
    cta: 'Run OCR', verb: 'Recognizing text', opts: [
      { id: 'lang', type: 'select', label: 'Document language', value: 'en', choices: LANGS },
      { id: 'out', type: 'seg', label: 'Output', value: 'pdf', choices: [['pdf', 'Searchable PDF'], ['txt', 'Text file']] }
    ] },
  { id: 'pdfa', name: 'PDF to PDF/A', cat: 'optimize', icon: 'archive', accept: 'pdf', multi: true,
    desc: 'Convert to PDF/A, the ISO standard for long-term archiving.', keys: 'archive iso standard long term pdfa',
    cta: 'Convert to PDF/A', verb: 'Converting', opts: [
      { id: 'level', type: 'select', label: 'Conformance level', value: '2b', choices: [['1b', 'PDF/A-1b'], ['2b', 'PDF/A-2b (recommended)'], ['3b', 'PDF/A-3b']] }
    ] },
  /* convert to */
  { id: 'word2pdf', name: 'Word to PDF', cat: 'to', icon: 'doc', accept: 'word', multi: true,
    desc: 'Convert DOC and DOCX files into PDFs that look the same everywhere.', keys: 'docx doc word microsoft office',
    cta: 'Convert to PDF', verb: 'Converting', opts: [] },
  { id: 'ppt2pdf', name: 'PowerPoint to PDF', cat: 'to', icon: 'slides', accept: 'ppt', multi: true,
    desc: 'Turn PPT and PPTX slide decks into PDFs that are easy to share.', keys: 'pptx ppt slides presentation deck',
    cta: 'Convert to PDF', verb: 'Converting', opts: [
      { id: 'notes', type: 'toggle', label: 'Include speaker notes', value: false }
    ] },
  { id: 'excel2pdf', name: 'Excel to PDF', cat: 'to', icon: 'sheet', accept: 'excel', multi: true,
    desc: 'Convert spreadsheets into PDFs with tidy, readable pages.', keys: 'xlsx xls csv spreadsheet sheet table',
    cta: 'Convert to PDF', verb: 'Converting', opts: [
      { id: 'orient', type: 'seg', label: 'Orientation', value: 'landscape', choices: [['portrait', 'Portrait'], ['landscape', 'Landscape']] },
      { id: 'fit', type: 'toggle', label: 'Fit all columns on one page', value: true }
    ] },
  { id: 'jpg2pdf', name: 'JPG to PDF', cat: 'to', icon: 'image', client: true, accept: 'image', multi: true,
    desc: 'Turn photos and images into a PDF with the page size and margins you choose.', keys: 'jpeg png image photo picture webp convert',
    cta: 'Convert to PDF', verb: 'Converting', tip: 'Drag images to change their order. Each image becomes one page.',
    opts: [pageSizeOpt('a4'), orientOpt, marginOpt] },
  { id: 'html2pdf', name: 'HTML to PDF', cat: 'to', icon: 'html', accept: 'url', multi: false,
    desc: 'Enter a web page address and save that page as a PDF.', keys: 'web page website url link html save',
    cta: 'Convert to PDF', verb: 'Capturing the page', opts: [
      { id: 'page', type: 'seg', label: 'Page size', value: 'a4', choices: [['a4', 'A4'], ['letter', 'US Letter'], ['one', 'One long page']] },
      { id: 'orient', type: 'seg', label: 'Orientation', value: 'portrait', choices: [['portrait', 'Portrait'], ['landscape', 'Landscape']], show: o => o.page !== 'one' },
      { id: 'clean', type: 'toggle', label: 'Hide ads and pop-ups', value: true }
    ] },
  { id: 'scan', name: 'Scan to PDF', cat: 'to', icon: 'camera', client: true, accept: 'image', multi: true, camera: true,
    desc: 'Use your phone or webcam to capture paper documents as a clean PDF.', keys: 'camera photo phone paper capture document scanner',
    cta: 'Create PDF', verb: 'Building your scan', opts: [
      { id: 'filter', type: 'seg', label: 'Look', value: 'doc', choices: [['none', 'Original'], ['gray', 'Greyscale'], ['doc', 'Document']], help: o => ({ none: 'Keeps the photo as it is.', gray: 'Removes colour casts from lighting.', doc: 'High contrast black and white, best for text.' }[o.filter]) },
      pageSizeOpt('a4'), orientOpt, marginOpt
    ] },
  /* convert from */
  { id: 'pdf2word', name: 'PDF to Word', cat: 'from', icon: 'doc', accept: 'pdf', multi: true,
    desc: 'Turn PDFs into editable Word documents that keep the layout.', keys: 'docx doc word editable microsoft office',
    cta: 'Convert to Word', verb: 'Converting', opts: [
      { id: 'ocr', type: 'toggle', label: 'Recognize text in scanned pages', value: true }
    ] },
  { id: 'pdf2ppt', name: 'PDF to PowerPoint', cat: 'from', icon: 'slides', accept: 'pdf', multi: true,
    desc: 'Turn each PDF page into an editable PowerPoint slide.', keys: 'pptx ppt slides presentation deck',
    cta: 'Convert to PowerPoint', verb: 'Converting', opts: [] },
  { id: 'pdf2excel', name: 'PDF to Excel', cat: 'from', icon: 'sheet', accept: 'pdf', multi: true,
    desc: 'Pull tables out of PDFs straight into Excel spreadsheets.', keys: 'xlsx xls csv table spreadsheet data extract',
    cta: 'Convert to Excel', verb: 'Extracting tables', opts: [
      { id: 'sheets', type: 'seg', label: 'Worksheets', value: 'page', choices: [['page', 'One per page'], ['one', 'All in one']] }
    ] },
  { id: 'pdf2jpg', name: 'PDF to JPG', cat: 'from', icon: 'image', client: true, accept: 'pdf', multi: true,
    desc: 'Save every page as a sharp JPG or PNG image.', keys: 'jpeg png image picture export pages photo',
    cta: 'Convert to images', verb: 'Rendering pages', opts: [
      { id: 'format', type: 'seg', label: 'Format', value: 'jpg', choices: [['jpg', 'JPG'], ['png', 'PNG']] },
      { id: 'dpi', type: 'seg', label: 'Quality', value: '150', choices: [['96', 'Screen'], ['150', 'High'], ['300', 'Print']], help: o => `${o.dpi} dpi` }
    ] },
  { id: 'pdf2md', name: 'PDF to Markdown', cat: 'from', icon: 'markdown', client: true, isNew: true, accept: 'pdf', multi: false,
    desc: 'Get clean Markdown with headings and lists, ready for notes, docs and LLMs.', keys: 'md markdown text llm notes ai plain extract',
    cta: 'Convert to Markdown', verb: 'Reading the text', opts: [
      { id: 'breaks', type: 'toggle', label: 'Mark page breaks', value: false }
    ] },
  /* edit */
  { id: 'edit', name: 'Edit PDF', cat: 'edit', icon: 'edit', accept: 'pdf', multi: false,
    desc: 'Add text, images, shapes and freehand notes to any page.', keys: 'annotate text add write draw shapes modify',
    cta: 'Open in editor', verb: 'Opening the editor', opts: [] },
  { id: 'sign', name: 'Sign PDF', cat: 'edit', icon: 'sign', client: true, accept: 'pdf', multi: false,
    desc: 'Draw or type your signature and place it on the page.', keys: 'signature esign e-sign autograph initial',
    cta: 'Sign PDF', verb: 'Signing', opts: [
      { id: 'signature', type: 'signature', label: 'Your signature', value: null },
      { id: 'where', type: 'seg', label: 'Pages', value: 'last', choices: [['first', 'First'], ['last', 'Last'], ['all', 'All']] },
      { id: 'pos', type: 'pos', label: 'Position on the page', value: 'br' },
      { id: 'width', type: 'range', label: 'Size', value: 28, min: 12, max: 60, step: 1, suffix: '%' },
      { id: 'date', type: 'toggle', label: 'Add today’s date under it', value: true }
    ] },
  { id: 'watermark', name: 'Watermark', cat: 'edit', icon: 'drop', client: true, accept: 'pdf', multi: true,
    desc: 'Stamp text across your pages. Choose size, angle, colour and opacity.', keys: 'stamp confidential draft overlay brand',
    cta: 'Add watermark', verb: 'Stamping', opts: [
      { id: 'text', type: 'text', label: 'Watermark text', value: 'CONFIDENTIAL', placeholder: 'For example: DRAFT' },
      { id: 'layout', type: 'seg', label: 'Layout', value: 'center', choices: [['center', 'Centred'], ['tile', 'Tiled']] },
      { id: 'angle', type: 'seg', label: 'Angle', value: '45', choices: [['0', '0°'], ['45', '45°'], ['-45', '−45°']] },
      { id: 'fsize', type: 'range', label: 'Text size', value: 60, min: 16, max: 140, step: 2, suffix: 'pt' },
      { id: 'opacity', type: 'range', label: 'Opacity', value: 20, min: 5, max: 100, step: 5, suffix: '%' },
      { id: 'color', type: 'color', label: 'Colour', value: '#E0464C', choices: ['#E0464C', '#16182F', '#2F6BF3', '#0E9F57', '#8C90A8'] }
    ] },
  { id: 'pagenum', name: 'Page numbers', cat: 'edit', icon: 'num', client: true, accept: 'pdf', multi: true,
    desc: 'Number your pages with the position, format and size you choose.', keys: 'numbering paginate pagination footer header count',
    cta: 'Add page numbers', verb: 'Numbering', opts: [
      { id: 'pos', type: 'pos', label: 'Position', value: 'bc', cells: ['tl', 'tc', 'tr', 'bl', 'bc', 'br'] },
      { id: 'fmt', type: 'select', label: 'Format', value: 'n', choices: [['n', '1'], ['page', 'Page 1'], ['of', '1 of 12'], ['pageof', 'Page 1 of 12']] },
      { id: 'start', type: 'number', label: 'Start at', value: 1, min: 0, max: 9999 },
      { id: 'fsize', type: 'range', label: 'Text size', value: 11, min: 7, max: 24, step: 1, suffix: 'pt' },
      { id: 'skipFirst', type: 'toggle', label: 'Skip the first page (cover)', value: false }
    ] },
  { id: 'crop', name: 'Crop PDF', cat: 'edit', icon: 'crop', client: true, accept: 'pdf', multi: false,
    desc: 'Trim the margins of every page, with a live preview.', keys: 'trim margins cut edges whitespace',
    cta: 'Crop PDF', verb: 'Cropping', opts: [
      { id: 'm', type: 'margins', label: 'Trim from each edge (mm)', value: { top: 10, right: 10, bottom: 10, left: 10 } }
    ] },
  { id: 'forms', name: 'PDF Forms', cat: 'edit', icon: 'form', isNew: true, accept: 'pdf', multi: false,
    desc: 'Detect form fields automatically and turn flat PDFs into fillable forms.', keys: 'fillable fields checkbox form fill acroform',
    cta: 'Create fillable form', verb: 'Detecting fields', opts: [
      { id: 'detect', type: 'seg', label: 'Detect', value: 'all', choices: [['all', 'All fields'], ['text', 'Text only'], ['check', 'Checkboxes']] }
    ] },
  /* security */
  { id: 'protect', name: 'Protect PDF', cat: 'security', icon: 'lock', accept: 'pdf', multi: true,
    desc: 'Add a password so only the right people can open the file.', keys: 'password encrypt lock secure',
    cta: 'Protect PDF', verb: 'Encrypting', opts: [
      { id: 'pw', type: 'password', label: 'Password', value: '', placeholder: 'At least 6 characters' },
      { id: 'pw2', type: 'password', label: 'Repeat password', value: '' },
      { id: 'noprint', type: 'toggle', label: 'Block printing and copying', value: false }
    ], validate: o => (!o.pw || o.pw.length < 6) ? 'Use a password with at least 6 characters.' : (o.pw !== o.pw2 ? 'The two passwords don’t match.' : '') },
  { id: 'unlock', name: 'Unlock PDF', cat: 'security', icon: 'unlock', accept: 'pdf', multi: true,
    desc: 'Remove the password from a PDF you are allowed to open.', keys: 'remove password decrypt open',
    cta: 'Unlock PDF', verb: 'Unlocking', opts: [
      { id: 'pw', type: 'password', label: 'Current password', value: '', placeholder: 'If the file needs one to open' },
      { id: 'rights', type: 'toggle', label: 'I own this file or have permission to unlock it', value: false }
    ], validate: o => o.rights ? '' : 'Confirm that you have permission to unlock this file.' },
  { id: 'redact', name: 'Redact PDF', cat: 'security', icon: 'redact', accept: 'pdf', multi: false,
    desc: 'Permanently black out names, numbers and other sensitive text.', keys: 'black out censor hide remove sensitive private gdpr',
    cta: 'Redact PDF', verb: 'Redacting', opts: [
      { id: 'terms', type: 'textarea', label: 'Words to black out', value: '', placeholder: 'One word or phrase per line' },
      { id: 'emails', type: 'toggle', label: 'Email addresses', value: true },
      { id: 'phones', type: 'toggle', label: 'Phone numbers', value: true }
    ] },
  /* ai */
  { id: 'summarize', name: 'AI Summarizer', cat: 'ai', icon: 'summary', isNew: true, accept: 'pdf', multi: false,
    desc: 'Get the key points of a long document in seconds.', keys: 'summary tldr ai key points digest abstract',
    cta: 'Summarize', verb: 'Reading and summarizing', opts: [
      { id: 'len', type: 'seg', label: 'Length', value: 'medium', choices: [['short', 'Short'], ['medium', 'Medium'], ['long', 'Detailed']] },
      { id: 'style', type: 'seg', label: 'Style', value: 'bullets', choices: [['bullets', 'Bullet points'], ['para', 'Paragraphs']] },
      { id: 'lang', type: 'select', label: 'Write the summary in', value: 'en', choices: LANGS }
    ] },
  { id: 'translate', name: 'Translate PDF', cat: 'ai', icon: 'translate', isNew: true, accept: 'pdf', multi: false,
    desc: 'Translate PDFs into another language while keeping fonts and layout.', keys: 'language translation ai hindi spanish french',
    cta: 'Translate PDF', verb: 'Translating', opts: [
      { id: 'to', type: 'select', label: 'Translate into', value: 'hi', choices: LANGS }
    ] },
  { id: 'compare', name: 'Compare PDF', cat: 'ai', icon: 'compare', client: true, accept: 'pdf', multi: true, min: 2, max: 2,
    desc: 'See exactly what changed between two versions of a document.', keys: 'diff difference versions changes review',
    cta: 'Compare files', verb: 'Comparing', tip: 'Add the original first, then the changed version.', opts: [
      { id: 'ignoreCase', type: 'toggle', label: 'Ignore upper and lower case', value: false }
    ] },
  /* images (all in the browser, see image-tools.js) */
  { id: 'imgcompress', name: 'Compress image', cat: 'image', icon: 'compress', client: true, accept: 'image', multi: true,
    desc: 'Shrink JPG, PNG and WebP photos for the web, email and uploads.', keys: 'image photo picture smaller reduce size kb jpg png webp optimize',
    cta: 'Compress images', verb: 'Compressing', opts: [
      { id: 'quality', type: 'range', label: 'Quality', value: 72, min: 30, max: 95, step: 1, suffix: '%', help: 'Lower quality gives a smaller file. 70 to 80% looks the same to most people.' },
      { id: 'maxSide', type: 'select', label: 'Largest side', value: '0', choices: [['0', 'Keep the size'], ['3840', '3840 px (4K)'], ['2560', '2560 px'], ['1920', '1920 px (Full HD)'], ['1280', '1280 px'], ['800', '800 px']] },
      { id: 'format', type: 'seg', label: 'Save as', value: 'same', choices: [['same', 'Same type'], ['image/jpeg', 'JPG'], ['image/webp', 'WebP']] }
    ] },
  { id: 'imgresize', name: 'Resize image', cat: 'image', icon: 'resize', client: true, accept: 'image', multi: true,
    desc: 'Change the size of photos in pixels or by percentage, one or many at once.', keys: 'image photo dimensions pixels scale width height smaller bigger',
    cta: 'Resize images', verb: 'Resizing', opts: [
      { id: 'mode', type: 'seg', label: 'Resize by', value: 'px', choices: [['px', 'Pixels'], ['pct', 'Percentage']] },
      { id: 'width', type: 'number', label: 'Width', value: 1080, min: 1, max: 20000, suffix: 'px', show: o => o.mode === 'px' },
      { id: 'height', type: 'number', label: 'Height', value: 0, min: 0, max: 20000, suffix: 'px', help: 'Leave at 0 to keep the proportions.', show: o => o.mode === 'px' },
      { id: 'percent', type: 'range', label: 'Size', value: 50, min: 5, max: 200, step: 5, suffix: '%', show: o => o.mode === 'pct' }
    ] },
  { id: 'imgconvert', name: 'Convert image', cat: 'image', icon: 'image', client: true, accept: 'image', multi: true,
    desc: 'Change photos between JPG, PNG and WebP, including iPhone and GIF images your browser can open.', keys: 'image format jpg jpeg png webp gif bmp convert change',
    cta: 'Convert images', verb: 'Converting', opts: [
      { id: 'to', type: 'seg', label: 'Convert to', value: 'image/png', choices: [['image/jpeg', 'JPG'], ['image/png', 'PNG'], ['image/webp', 'WebP']] },
      { id: 'quality', type: 'range', label: 'Quality', value: 90, min: 40, max: 100, step: 1, suffix: '%', show: o => o.to !== 'image/png' }
    ] },
  { id: 'imgcrop', name: 'Crop image', cat: 'image', icon: 'crop', client: true, accept: 'image', multi: false,
    desc: 'Cut photos to a square, 16:9 or any shape, with a live preview.', keys: 'image photo cut trim square aspect ratio instagram',
    cta: 'Crop image', verb: 'Cropping', opts: [
      { id: 'ratio', type: 'select', label: 'Shape', value: '1:1', choices: [['orig', 'Original shape'], ['1:1', 'Square (1:1)'], ['4:5', 'Portrait (4:5)'], ['4:3', 'Landscape (4:3)'], ['3:2', 'Photo (3:2)'], ['16:9', 'Widescreen (16:9)']] },
      { id: 'size', type: 'range', label: 'Crop size', value: 100, min: 20, max: 100, step: 1, suffix: '%' },
      { id: 'pos', type: 'pos', label: 'Keep this part', value: 'mc' }
    ] },
  { id: 'jpg2png', name: 'JPG to PNG', cat: 'image', icon: 'image', client: true, accept: 'image', multi: true,
    desc: 'Turn JPG photos into lossless PNG images.', keys: 'jpeg jpg png convert lossless',
    cta: 'Convert to PNG', verb: 'Converting', opts: [] },
  { id: 'png2jpg', name: 'PNG to JPG', cat: 'image', icon: 'image', client: true, accept: 'image', multi: true,
    desc: 'Turn PNG images into smaller JPG files. Transparent areas become white.', keys: 'png jpg jpeg convert smaller transparent',
    cta: 'Convert to JPG', verb: 'Converting', opts: [
      { id: 'quality', type: 'range', label: 'Quality', value: 90, min: 40, max: 100, step: 1, suffix: '%' }
    ] }
];
/* tools switched off in WordPress are removed; some tools move to the server when one is connected */
(CONFIG.disabled || []).forEach(id => { const i = TOOLS.findIndex(t => t.id === id); if (i >= 0) TOOLS.splice(i, 1); });
TOOLS.forEach(t => { if (!t.min) t.min = 1; if (t.serverFirst && CONFIG.apiBase) t.client = false; });
const TOOL = Object.fromEntries(TOOLS.map(t => [t.id, t]));
const slugOf = t => t.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
const TOOL_BY_SLUG = Object.fromEntries(TOOLS.map(t => [slugOf(t), t]));
/* Real address of a tool page (/merge-pdf/) when WordPress serves them, otherwise a #tool/ link. */
const toolHref = t => CONFIG.toolPages ? CONFIG.toolBase.replace(/\/?$/, '/') + slugOf(t) + '/' : '#tool/' + t.id;
const toolLink = t => `href="${toolHref(t)}" data-tool="${t.id}"`;

const QUICK = ['merge', 'compress', 'pdf2word', 'sign', 'jpg2pdf', 'split'];
const WF_STEPS = ['merge', 'compress', 'rotate', 'pagenum', 'watermark', 'crop', 'repair'];
const WF_PRESETS = [
  { id: 'p-shrink', preset: true, name: 'Merge and compress', desc: 'Combine files, then shrink the result for email.', steps: [{ tool: 'merge', o: {} }, { tool: 'compress', o: { level: 'balanced' } }] },
  { id: 'p-contract', preset: true, name: 'Contract pack', desc: 'Merge, number every page and stamp it confidential.', steps: [{ tool: 'merge', o: {} }, { tool: 'pagenum', o: { pos: 'br', fmt: 'pageof' } }, { tool: 'watermark', o: { text: 'CONFIDENTIAL', opacity: 12 } }] }
];

/* ---------------- state ---------------- */
const UI = { cat: 'all', q: '', priv: false, fav: false };
let favs = new Set(store.get('favs', []));
let recent = store.get('recent', []);
let userWfs = store.get('workflows', []);

/* ---------------- toasts ---------------- */
function toast(msg, kind = 'info') {
  const el = document.createElement('div');
  el.className = 'toast' + (kind === 'error' ? ' err' : '');
  el.innerHTML = icon(kind === 'error' ? 'alert' : kind === 'ok' ? 'check' : 'info') + `<span>${esc(msg)}</span>`;
  $('#toasts').appendChild(el);
  if (HAS_GSAP()) gsap.from(el, { y: 16, opacity: 0, duration: .3, ease: 'power2.out' });
  setTimeout(() => {
    if (HAS_GSAP()) gsap.to(el, { opacity: 0, y: 8, duration: .25, onComplete: () => el.remove() }); else el.remove();
  }, kind === 'error' ? 5200 : 3200);
}

/* ---------------- overlays ---------------- */
const OV = [];
function openOv(el, opts = {}) {
  if (OV.find(o => o.el === el)) return;
  el.hidden = false;
  OV.push({ el, prev: document.activeElement, onClose: opts.onClose });
  document.body.classList.add('locked');
  const box = el.querySelector('.pl-box, .modal-box, .ws-panel, .drawer-panel');
  const bg = el.querySelector('.ov-bg, .drawer-bg');
  if (HAS_GSAP() && !REDUCED) {
    gsap.killTweensOf([box, bg]);
    if (bg) gsap.fromTo(bg, { opacity: 0 }, { opacity: 1, duration: .25 });
    if (box) {
      if (box.classList.contains('drawer-panel')) gsap.fromTo(box, { xPercent: 100 }, { xPercent: 0, duration: .4, ease: 'power3.out' });
      else gsap.fromTo(box, { opacity: 0, y: 18, scale: .985 }, { opacity: 1, y: 0, scale: 1, duration: .38, ease: 'power3.out', clearProps: 'transform,opacity' });
    }
  }
  const f = opts.focus ? (el.matches(opts.focus) ? el : $(opts.focus, el)) : el.querySelector('input:not([type=hidden]):not([hidden]),button,[href]');
  setTimeout(() => f && f.focus({ preventScroll: true }), 30);
}
function closeOv(el) {
  const i = OV.findIndex(o => o.el === el);
  if (i < 0) return;
  const [o] = OV.splice(i, 1);
  const done = () => {
    el.hidden = true;
    if (!OV.length) document.body.classList.remove('locked');
    o.onClose && o.onClose();
  };
  const box = el.querySelector('.pl-box, .modal-box, .ws-panel, .drawer-panel');
  const bg = el.querySelector('.ov-bg, .drawer-bg');
  if (HAS_GSAP() && !REDUCED && box) {
    if (bg) gsap.to(bg, { opacity: 0, duration: .2 });
    if (box.classList.contains('drawer-panel')) gsap.to(box, { xPercent: 100, duration: .28, ease: 'power2.in', onComplete: done });
    else gsap.to(box, { opacity: 0, y: 10, duration: .18, ease: 'power2.in', onComplete: () => { gsap.set(box, { clearProps: 'all' }); done(); } });
  } else done();
  if (o.prev && o.prev.focus && document.contains(o.prev)) o.prev.focus({ preventScroll: true });
}
const topOv = () => OV[OV.length - 1];
document.addEventListener('click', e => {
  const c = e.target.closest('[data-close]');
  if (!c) return;
  const ov = c.closest('.ov, .drawer');
  if (ov) {
    if (ov.id === 'ws') return closeTool();
    closeOv(ov);
  }
});
document.addEventListener('keydown', e => {
  const t = topOv();
  if (e.key === 'Escape') {
    if (!$('#mega').hidden) return closeMega();
    if (t) { e.preventDefault(); t.el.id === 'ws' ? closeTool() : closeOv(t.el); }
    return;
  }
  if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); openPalette(); return; }
  if (e.key === '/' && !t && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) { e.preventDefault(); openPalette(); return; }
  if (e.key === 'Tab' && t) {
    const f = $$('button:not([disabled]),[href],input:not([type=hidden]):not([hidden]),select,textarea,[tabindex]:not([tabindex="-1"])', t.el).filter(x => x.offsetParent !== null);
    if (!f.length) return;
    const first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  }
});

/* ---------------- catalog ---------------- */
const tileCls = t => 'tile' + (t.cat === 'ai' ? ' ai' : '') + (t.cat === 'workflows' ? ' wf' : '');
function toolCard(t) {
  const meta = [t.client ? `<span class="tag tag-local" title="Runs in your browser">${icon('device')}<span class="tl">In browser</span></span>` : '', t.isNew ? '<span class="tag tag-new">New</span>' : ''].join('');
  return `<article class="tool" data-cat="${t.cat}" data-id="${t.id}">
    <span class="${tileCls(t)}">${icon(t.icon)}</span>
    <div class="tx"><h4><a class="tool-link" ${toolLink(t)}>${esc(t.name)}</a></h4><p>${esc(t.desc)}</p>
    <div class="tool-meta">${meta}</div></div>
    <button class="icon-btn sm fav${favs.has(t.id) ? ' on' : ''}" data-fav="${t.id}" aria-pressed="${favs.has(t.id)}" aria-label="Add ${esc(t.name)} to favourites">${icon('star', 'ic ic-sm')}</button>
  </article>`;
}
function chainHtml(steps) {
  return '<div class="chain">' + steps.map((s, i) => { const t = TOOL[s.tool]; return (i ? `<span class="sep">${icon('chev-right')}</span>` : '') + `<span class="tile sm c-${t.cat}" title="${esc(t.name)}">${icon(t.icon)}</span>`; }).join('') + '</div>';
}
function wfCards() {
  const all = [...WF_PRESETS, ...userWfs].filter(w => w.steps.every(st => TOOL[st.tool]));
  return `<article class="tool wf-new" data-cat="workflows" data-id="wf-new">
      <span class="tile wf">${icon('plus')}</span>
      <div class="tx"><h4><a class="tool-link" href="#" data-wf-new>Create a workflow</a></h4><p>Chain your favourite tools, save the steps and reuse them on new files.</p><div class="tool-meta"></div></div>
    </article>` + all.map(w => `<article class="tool" data-cat="workflows" data-id="wf-${w.id}" data-wf="${w.id}">
      ${chainHtml(w.steps)}
      <div class="tx"><h4><a class="tool-link" href="#wf/${w.id}">${esc(w.name)}</a></h4><p>${esc(w.desc || w.steps.map(s => TOOL[s.tool].name).join(', then '))}</p>
      <div class="tool-meta"><span class="tag tag-local" title="Runs in your browser">${icon('device')}<span class="tl">In browser</span></span>${w.preset ? '<span class="tag">Ready-made</span>' : ''}</div></div>
      ${w.preset ? '' : `<button class="icon-btn sm wf-del" data-wf-del="${w.id}" aria-label="Delete workflow ${esc(w.name)}">${icon('trash', 'ic ic-sm')}</button>`}
    </article>`).join('');
}
function renderCatalog() {
  $('#catalog').innerHTML = CATS.map(c => {
    const items = c.id === 'workflows' ? wfCards() : TOOLS.filter(t => t.cat === c.id).map(toolCard).join('');
    const n = c.id === 'workflows' ? WF_PRESETS.length + userWfs.length : TOOLS.filter(t => t.cat === c.id).length;
    return `<section class="cat-block" data-cat="${c.id}" aria-labelledby="cat-${c.id}">
      <header class="cat-head"><h3 id="cat-${c.id}"><span class="dot"></span>${esc(c.name)}</h3><span class="cnt">${n} ${c.id === 'workflows' ? (n === 1 ? 'workflow' : 'workflows') : (n === 1 ? 'tool' : 'tools')}</span><p>${esc(c.desc)}</p></header>
      <div class="grid">${items}</div></section>`;
  }).join('');
  applyFilter(false);
}
function renderTabs() {
  const n = id => id === 'all' ? TOOLS.length : id === 'workflows' ? WF_PRESETS.length + userWfs.length : TOOLS.filter(t => t.cat === id).length;
  $('#tabs').innerHTML = [{ id: 'all', name: 'All' }, ...CATS].map(c => `<button class="tab" role="tab" data-tab="${c.id}" data-cat="${c.id}" aria-selected="${UI.cat === c.id}" title="${esc(c.name)}">${c.id === 'all' ? '' : '<span class="dot"></span>'}${esc(c.tab || c.name)}<span class="n">${n(c.id)}</span></button>`).join('');
}
function matches(t, q) {
  if (!q) return true;
  const hay = (t.name + ' ' + t.desc + ' ' + (t.keys || '') + ' ' + (CAT[t.cat] ? CAT[t.cat].name : '')).toLowerCase();
  return q.toLowerCase().split(/\s+/).filter(Boolean).every(w => hay.includes(w));
}
function applyFilter(animate = true) {
  const cards = $$('#catalog .tool');
  const doFlip = animate && HAS_GSAP() && window.Flip && !REDUCED;
  const state = doFlip ? Flip.getState('#catalog .tool, #catalog .cat-head') : null;
  let shown = 0;
  cards.forEach(el => {
    const id = el.dataset.id, cat = el.dataset.cat;
    let ok = UI.cat === 'all' || UI.cat === cat;
    if (ok && cat === 'workflows') {
      const w = [...WF_PRESETS, ...userWfs].find(x => 'wf-' + x.id === id);
      const name = w ? w.name + ' ' + (w.desc || '') + ' workflow ' + w.steps.map(s => TOOL[s.tool].name).join(' ') : 'create workflow chain automate';
      ok = matches({ name, desc: '', cat }, UI.q) && !UI.fav;
    } else if (ok) {
      const t = TOOL[id];
      ok = matches(t, UI.q) && (!UI.priv || t.client) && (!UI.fav || favs.has(id));
    }
    el.hidden = !ok;
    if (ok) shown++;
  });
  $$('#catalog .cat-block').forEach(b => { b.hidden = !$$('.tool', b).some(c => !c.hidden); });
  const empty = $('#emptyState');
  empty.hidden = shown > 0;
  if (!shown) {
    $('#emptyTitle').textContent = UI.fav && !UI.q ? 'No favourites yet' : 'No tools match';
    $('#emptyText').textContent = UI.fav && !UI.q ? 'Tap the star on any tool to keep it here.' : UI.q ? `Nothing matches “${UI.q}”. Try a different word, like “convert” or “sign”.` : 'Try another category or turn off a filter.';
  }
  if (doFlip) {
    Flip.from(state, {
      duration: .45, ease: 'power2.inOut', absolute: true, nested: true, prune: true,
      onEnter: els => gsap.fromTo(els, { opacity: 0, scale: .96 }, { opacity: 1, scale: 1, duration: .35, delay: .1 }),
      onLeave: els => gsap.to(els, { opacity: 0, scale: .96, duration: .2 })
    });
  }
}
function setCat(id, scroll) {
  UI.cat = id;
  $$('#tabs .tab').forEach(b => b.setAttribute('aria-selected', b.dataset.tab === id));
  const tab = $(`#tabs [data-tab="${id}"]`);
  if (tab) tab.scrollIntoView({ block: 'nearest', inline: 'nearest' });
  applyFilter();
  if (scroll) $('#tools').scrollIntoView({ behavior: REDUCED ? 'auto' : 'smooth' });
}
function toggleFav(id) {
  favs.has(id) ? favs.delete(id) : favs.add(id);
  store.set('favs', [...favs]);
  $$(`[data-fav="${id}"]`).forEach(b => { b.classList.toggle('on', favs.has(id)); b.setAttribute('aria-pressed', favs.has(id)); });
  toast(favs.has(id) ? `${TOOL[id].name} added to favourites` : `${TOOL[id].name} removed from favourites`, 'ok');
  if (UI.fav) applyFilter();
}
function pushRecent(id) {
  recent = [id, ...recent.filter(x => x !== id)].slice(0, 6);
  store.set('recent', recent);
  renderRecent();
}
function renderRecent() {
  const r = recent.filter(id => TOOL[id]);
  const el = $('#recent');
  el.hidden = !r.length;
  el.innerHTML = '<span>Recently used</span>' + r.map(id => { const t = TOOL[id]; return `<a class="chip c-${t.cat}" ${toolLink(t)}>${icon(t.icon)}${esc(t.name)}</a>`; }).join('');
}

/* ---------------- command palette ---------------- */
const PL = { items: [], sel: 0 };
function plScore(t, q) {
  if (!q) return 1;
  const n = t.name.toLowerCase(), k = (t.keys || '').toLowerCase(), d = t.desc.toLowerCase();
  let s = 0;
  for (const w of q.toLowerCase().split(/\s+/).filter(Boolean)) {
    let ws = 0;
    if (n.startsWith(w)) ws = 100; else if (n.split(/\s+/).some(x => x.startsWith(w))) ws = 70; else if (n.includes(w)) ws = 50;
    else if (k.split(/\s+/).some(x => x.startsWith(w))) ws = 40; else if (k.includes(w)) ws = 25; else if (d.includes(w)) ws = 12;
    if (!ws) return 0;
    s += ws;
  }
  return s;
}
function plActions() {
  return [
    { kind: 'act', id: 'wf', name: 'Create a workflow', desc: 'Chain tools and run them in one step', icon: 'workflow', cat: 'workflows', run: () => openWfBuilder() },
    { kind: 'act', id: 'theme', name: document.documentElement.dataset.theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme', desc: 'Change how Fileora looks', icon: document.documentElement.dataset.theme === 'dark' ? 'sun' : 'moon', cat: 'workflows', run: toggleTheme },
    { kind: 'act', id: 'local', name: 'Show tools that run in your browser', desc: 'Files never leave your device', icon: 'device', cat: 'optimize', run: () => { setPriv(true); setCat('all', true); } }
  ];
}
function renderPalette() {
  const q = $('#plInput').value.trim();
  const tools = TOOLS.map(t => ({ t, s: plScore(t, q) })).filter(x => x.s).sort((a, b) => b.s - a.s || TOOLS.indexOf(a.t) - TOOLS.indexOf(b.t));
  let list = tools.map(x => ({ kind: 'tool', ...x.t }));
  if (!q) {
    const rec = recent.filter(id => TOOL[id]).map(id => ({ kind: 'tool', ...TOOL[id], rec: true }));
    const rest = list.filter(x => !recent.includes(x.id));
    list = [...rec, ...rest];
  }
  const acts = plActions().filter(a => !q || plScore(a, q));
  PL.items = [...list, ...acts];
  PL.sel = Math.min(PL.sel, Math.max(0, PL.items.length - 1));
  const box = $('#plList');
  if (!PL.items.length) { box.innerHTML = `<div class="pl-empty">No tools match “${esc(q)}”.<br>Try “convert”, “password” or “images”.</div>`; return; }
  let html = '', grp = '';
  PL.items.forEach((it, i) => {
    const g = it.kind === 'act' ? 'Actions' : it.rec ? 'Recently used' : q ? 'Tools' : 'All tools';
    if (g !== grp) { html += `<div class="pl-group">${g}</div>`; grp = g; }
    html += `<div class="pl-item" role="option" id="pl-${i}" data-i="${i}" aria-selected="${i === PL.sel}">
      <span class="${it.kind === 'act' ? 'tile' : tileCls(it)} c-${it.cat}">${icon(it.icon)}</span>
      <div><b>${esc(it.name)}</b><small>${esc(it.desc)}</small></div>
      <span class="pl-cat">${it.kind === 'act' ? '' : esc(CAT[it.cat].name)}</span></div>`;
  });
  box.innerHTML = html;
  $('#plInput').setAttribute('aria-activedescendant', 'pl-' + PL.sel);
}
function plMove(d) {
  if (!PL.items.length) return;
  PL.sel = (PL.sel + d + PL.items.length) % PL.items.length;
  $$('#plList .pl-item').forEach(el => el.setAttribute('aria-selected', +el.dataset.i === PL.sel));
  const el = $(`#pl-${PL.sel}`);
  el && el.scrollIntoView({ block: 'nearest' });
  $('#plInput').setAttribute('aria-activedescendant', 'pl-' + PL.sel);
}
function plPick(i) {
  const it = PL.items[i];
  if (!it) return;
  closeOv($('#palette'));
  setTimeout(() => it.kind === 'act' ? it.run() : openTool(it.id), 60);
}
function openPalette(q = '') {
  closeMega();
  const dr = $('#drawer'); if (!dr.hidden) closeOv(dr);
  if (!$('#palette').hidden) return $('#plInput').focus();
  $('#plInput').value = q; PL.sel = 0; renderPalette();
  openOv($('#palette'), { focus: '#plInput' });
}

/* ---------------- header: mega menu, drawer, theme ---------------- */
function megaHtml(kind) {
  const col = c => `<div class="mega-col c-${c.id}"><h4><span class="dot"></span>${esc(c.name)}</h4>${TOOLS.filter(t => t.cat === c.id).map(t => `<a ${toolLink(t)} data-close-mega><span class="${tileCls(t)} sm">${icon(t.icon)}</span>${esc(t.name)}</a>`).join('')}</div>`;
  if (kind === 'convert') return `<div class="mega-grid two">${col(CAT.to)}${col(CAT.from)}</div>`;
  return `<div class="mega-grid">${CATS.filter(c => c.id !== 'workflows').map(col).join('')}
    <div class="mega-wf c-workflows"><span class="tile wf sm">${icon('workflow')}</span><h4 style="font-size:15px;font-weight:600">Workflows</h4><p>Run several tools in a row on new files, in one step.</p><a class="btn btn-line btn-sm" href="#" data-wf-new data-close-mega>Create a workflow</a></div></div>`;
}
let megaKind = null;
function openMega(kind, btn) {
  if (megaKind === kind) return closeMega();
  megaKind = kind;
  $('#megaIn').innerHTML = megaHtml(kind);
  $('#mega').hidden = false;
  $$('[data-mega]').forEach(b => b.setAttribute('aria-expanded', b === btn));
  if (HAS_GSAP() && !REDUCED) gsap.fromTo('#mega', { opacity: 0, y: -8 }, { opacity: 1, y: 0, duration: .25, ease: 'power2.out' });
}
function closeMega() {
  if ($('#mega').hidden) return;
  megaKind = null;
  $('#mega').hidden = true;
  $$('[data-mega]').forEach(b => b.setAttribute('aria-expanded', 'false'));
}
function renderDrawer() {
  $('#drawerCats').innerHTML = CATS.filter(c => c.id !== 'workflows').map(c => `<details class="c-${c.id}"><summary><span class="dot"></span>${esc(c.name)}${icon('chev-down')}</summary><div>${TOOLS.filter(t => t.cat === c.id).map(t => `<a ${toolLink(t)} data-close><span class="${tileCls(t)} sm">${icon(t.icon)}</span>${esc(t.name)}</a>`).join('')}</div></details>`).join('')
    + `<details class="c-workflows"><summary><span class="dot"></span>Workflows${icon('chev-down')}</summary><div><a href="#" data-wf-new data-close><span class="tile wf sm">${icon('plus')}</span>Create a workflow</a></div></details>`;
}
function toggleTheme() {
  const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
  document.documentElement.dataset.theme = next;
  store.set('theme', next);
  try { localStorage.setItem('fileora.theme', next); } catch (e) { /* ignore */ }
  $('meta[name=theme-color]').content = next === 'dark' ? '#0E1020' : '#F2F3F8';
  $('#themeBtn').setAttribute('aria-label', next === 'dark' ? 'Switch to light theme' : 'Switch to dark theme');
}
function setPriv(on) { UI.priv = on; $('#privToggle').setAttribute('aria-pressed', on); }

/* ---------------- routing ---------------- */
let routeLock = false;
function toolFromPath() {
  if (!CONFIG.toolPages) return null;
  const base = CONFIG.toolBase.replace(/\/?$/, '/');
  const path = decodeURIComponent(location.pathname);
  if (!path.startsWith(base)) return null;
  return TOOL_BY_SLUG[path.slice(base.length).replace(/\/$/, '')] || null;
}
function route() {
  if (routeLock) return;
  const h = decodeURIComponent(location.hash || '');
  const fromPath = toolFromPath();
  let m;
  if (fromPath) { if (!WS.tool || WS.tool.id !== fromPath.id) openTool(fromPath.id, null, true); }
  else if ((m = /^#tool\/([\w-]+)/.exec(h)) && TOOL[m[1]]) { if (!WS.tool || WS.tool.id !== m[1]) openTool(m[1], null, true); }
  else if ((m = /^#wf\/([\w-]+)/.exec(h))) { const w = [...WF_PRESETS, ...userWfs].find(x => x.id === m[1]); if (w && (!WS.tool || WS.tool.id !== 'wf-' + w.id)) openTool(wfTool(w), null, true); }
  else if (WS.tool) closeTool(true);
}
function setHash(h) {
  routeLock = true;
  const toolUrl = CONFIG.toolPages && /^#tool\//.test(h || '') ? toolHref(TOOL[h.slice(6)]) : null;
  if (toolUrl) { if (location.pathname !== toolUrl) history.pushState(null, '', toolUrl); }
  else if (h) { if (location.hash !== h) history.pushState(null, '', h); }
  else if (toolFromPath()) history.pushState(null, '', CONFIG.toolBase.replace(/\/?$/, '/'));
  else if (/^#(tool|wf)\//.test(location.hash)) history.replaceState(null, '', location.pathname + location.search);
  setTimeout(() => { routeLock = false; }, 0);
}

/* ---------------- init (core) ---------------- */
function initCore() {
  const kbd = IS_MAC ? '⌘K' : 'Ctrl K';
  $$('[data-kbd]').forEach(k => { k.textContent = kbd; });
  $$('[data-n-tools]').forEach(e => { e.textContent = TOOLS.length; });
  $$('[data-n-local]').forEach(e => { e.textContent = TOOLS.filter(t => t.client).length; });
  $('#faqLocal').textContent = TOOLS.filter(t => t.client).map(t => t.name).join(', ').replace(/, ([^,]*)$/, ' and $1') + '. Turn on the “In browser” filter above the tool list to see them.';
  $('#year').textContent = new Date().getFullYear();
  $('#themeBtn').setAttribute('aria-label', document.documentElement.dataset.theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme');
  if (document.documentElement.dataset.theme === 'dark') $('meta[name=theme-color]').content = '#0E1020';

  $('#quick').innerHTML = QUICK.filter(id => TOOL[id]).map(id => { const t = TOOL[id]; return `<a class="chip c-${t.cat}" ${toolLink(t)}>${icon(t.icon)}${esc(t.name)}</a>`; }).join('');
  /* static links in the page (header, footer) */
  $$('a[href^="#tool/"]').forEach(a => { const t = TOOL[a.getAttribute('href').slice(6)]; if (t) { a.href = toolHref(t); a.dataset.tool = t.id; } else a.remove(); });
  renderTabs(); renderCatalog(); renderRecent(); renderDrawer();
  const tabsFade = () => { const t = $('#tabs'); t.classList.toggle('more', t.scrollWidth > t.clientWidth + 2 && t.scrollLeft + t.clientWidth < t.scrollWidth - 4); };
  addEventListener('resize', tabsFade); $('#tabs').addEventListener('scroll', tabsFade, { passive: true }); tabsFade();

  $('#tabs').addEventListener('click', e => { const b = e.target.closest('[data-tab]'); if (b) setCat(b.dataset.tab); });
  $('#tabs').addEventListener('keydown', e => {
    if (!/Arrow(Left|Right)/.test(e.key)) return;
    const tabs = $$('#tabs .tab'); const i = tabs.indexOf(document.activeElement);
    const n = tabs[(i + (e.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length];
    n.focus(); setCat(n.dataset.tab);
  });
  let ft;
  $('#filterInput').addEventListener('input', e => { clearTimeout(ft); ft = setTimeout(() => { UI.q = e.target.value.trim(); applyFilter(); }, 120); });
  $('#privToggle').addEventListener('click', () => { setPriv(!UI.priv); applyFilter(); });
  $('#favToggle').addEventListener('click', () => { UI.fav = !UI.fav; $('#favToggle').setAttribute('aria-pressed', UI.fav); applyFilter(); });
  $('#clearFilters').addEventListener('click', () => { UI.q = ''; $('#filterInput').value = ''; setPriv(false); UI.fav = false; $('#favToggle').setAttribute('aria-pressed', false); setCat('all'); });

  document.addEventListener('click', e => {
    const fav = e.target.closest('[data-fav]'); if (fav) { e.preventDefault(); return toggleFav(fav.dataset.fav); }
    const del = e.target.closest('[data-wf-del]'); if (del) { e.preventDefault(); return deleteWf(del.dataset.wfDel); }
    const nw = e.target.closest('[data-wf-new]'); if (nw) { e.preventDefault(); closeMega(); const dr = $('#drawer'); if (!dr.hidden) closeOv(dr); return openWfBuilder(); }
    if (e.target.closest('[data-close-mega]')) closeMega();
    const tl = e.target.closest('a[data-tool]');
    if (tl && !e.metaKey && !e.ctrlKey && !e.shiftKey && e.button === 0 && TOOL[tl.dataset.tool]) {
      e.preventDefault(); const dr = $('#drawer'); if (!dr.hidden) closeOv(dr); closeMega(); return openTool(tl.dataset.tool);
    }
    const cl = e.target.closest('[data-cat-link]'); if (cl) { e.preventDefault(); return setCat(cl.dataset.catLink, true); }
    const pal = e.target.closest('[data-palette]'); if (pal) { e.preventDefault(); return openPalette(); }
    const mg = e.target.closest('[data-mega]'); if (mg) return openMega(mg.dataset.mega, mg);
    if (!e.target.closest('#mega')) closeMega();
  });

  $('#plInput').addEventListener('input', () => { PL.sel = 0; renderPalette(); });
  $('#plInput').addEventListener('keydown', e => {
    if (e.key === 'ArrowDown') { e.preventDefault(); plMove(1); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); plMove(-1); }
    else if (e.key === 'Enter') { e.preventDefault(); plPick(PL.sel); }
  });
  $('#plList').addEventListener('click', e => { const it = e.target.closest('.pl-item'); if (it) plPick(+it.dataset.i); });
  $('#plList').addEventListener('mousemove', e => { const it = e.target.closest('.pl-item'); if (it && +it.dataset.i !== PL.sel) { PL.sel = +it.dataset.i; $$('#plList .pl-item').forEach(el => el.setAttribute('aria-selected', +el.dataset.i === PL.sel)); } });

  $('#themeBtn').addEventListener('click', toggleTheme);
  $('#menuBtn').addEventListener('click', () => { closeMega(); openOv($('#drawer')); $('#menuBtn').setAttribute('aria-expanded', 'true'); });
  $('#drawer').addEventListener('click', e => { if (e.target.closest('[data-close]')) $('#menuBtn').setAttribute('aria-expanded', 'false'); });
  $('#langSel').addEventListener('change', e => { document.documentElement.lang = e.target.value; });

  const hdr = $('#hdr'), tb = $('#toolbar');
  const onScroll = () => {
    hdr.classList.toggle('scrolled', scrollY > 4);
    const r = tb.getBoundingClientRect();
    tb.classList.toggle('stuck', r.top <= parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--hdr')) + 1 && scrollY > 200);
  };
  addEventListener('scroll', onScroll, { passive: true }); onScroll();
  addEventListener('hashchange', route);
  addEventListener('popstate', route);
}
