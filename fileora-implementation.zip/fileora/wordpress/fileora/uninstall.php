<?php
/**
 * Runs when the plugin is deleted from Plugins → Installed Plugins.
 * Removes the settings, the job table and the scheduled cleanup.
 *
 * @package Fileora
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;
$fileora_table = $wpdb->prefix . 'fileora_jobs';
$wpdb->query( "DROP TABLE IF EXISTS {$fileora_table}" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
delete_option( 'fileora_settings' );
delete_option( 'fileora_db_version' );
delete_transient( 'fileora_health' );
wp_clear_scheduled_hook( 'fileora_cleanup' );
