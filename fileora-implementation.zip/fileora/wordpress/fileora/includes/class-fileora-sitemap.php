<?php
/**
 * Sitemap provider: lists the Fileora app and its tool pages in
 * /wp-sitemap.xml (WordPress 5.5+ core sitemaps).
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Sitemap extends WP_Sitemaps_Provider {

	public function __construct() {
		$this->name        = 'fileora';
		$this->object_type = 'fileora';
	}

	public function get_url_list( $page_num, $object_subtype = '' ) {
		$urls = array( array( 'loc' => Fileora_Frontend::app_url() ) );
		if ( ! empty( Fileora_Settings::get()['tool_pages'] ) ) {
			foreach ( Fileora_Frontend::tools() as $tool ) {
				$urls[] = array( 'loc' => Fileora_Frontend::tool_url( $tool ) );
			}
		}
		return $urls;
	}

	public function get_max_num_pages( $object_subtype = '' ) {
		return 1;
	}
}
