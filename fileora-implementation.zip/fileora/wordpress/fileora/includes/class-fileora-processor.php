<?php
/**
 * HTTP client for the Fileora processing service (Python, 127.0.0.1:8000).
 *
 * Uploads and downloads use cURL directly: the WordPress HTTP API can't send
 * files as multipart uploads or stream large downloads. Small JSON calls use
 * wp_remote_*().
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Processor {

	private static function url( $path ) {
		return untrailingslashit( Fileora_Settings::get()['service_url'] ) . $path;
	}

	private static function key() {
		return Fileora_Settings::get()['service_key'];
	}

	/**
	 * Sends the files to the service and creates a job.
	 *
	 * @param string $tool    Tool id.
	 * @param array  $files   Normalized, validated uploads.
	 * @param string $options JSON options from the browser.
	 * @param string $url     Web address (HTML to PDF only).
	 * @return array{status:int, body:array}|WP_Error
	 */
	public static function submit( $tool, array $files, $options, $url = '' ) {
		if ( ! function_exists( 'curl_init' ) ) {
			return new WP_Error( 'fileora_curl', 'The PHP cURL extension is required.' );
		}
		$fields = array( 'options' => $options );
		foreach ( array_values( $files ) as $i => $file ) {
			$fields[ "files[{$i}]" ] = new CURLFile( $file['tmp_name'], 'application/octet-stream', sanitize_file_name( $file['name'] ) );
		}
		if ( '' !== $url ) {
			$fields['url'] = $url;
		}
		$ch = curl_init( self::url( '/jobs/' . rawurlencode( $tool ) ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_init
		curl_setopt_array( // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt_array
			$ch,
			array(
				CURLOPT_POST           => true,
				CURLOPT_POSTFIELDS     => $fields,
				CURLOPT_HTTPHEADER     => array( 'X-Fileora-Key: ' . self::key(), 'Expect:' ),
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_CONNECTTIMEOUT => 5,
				CURLOPT_TIMEOUT        => 300,
			)
		);
		$body   = curl_exec( $ch ); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_exec
		$status = (int) curl_getinfo( $ch, CURLINFO_RESPONSE_CODE ); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_getinfo
		$error  = curl_error( $ch ); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_error
		curl_close( $ch ); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_close
		if ( false === $body ) {
			Fileora_Log::error( 'submit failed', array( 'tool' => $tool, 'curl' => $error ) );
			return new WP_Error( 'fileora_unreachable', 'The processing server isn’t responding. Please try again in a minute.' );
		}
		$json = json_decode( $body, true );
		return array(
			'status' => $status,
			'body'   => is_array( $json ) ? $json : array(),
		);
	}

	/** @return array{status:int, body:array}|WP_Error */
	public static function status( $job_id ) {
		$response = wp_remote_get(
			self::url( '/jobs/' . $job_id ),
			array(
				'timeout' => 10,
				'headers' => array( 'X-Fileora-Key' => self::key() ),
			)
		);
		if ( is_wp_error( $response ) ) {
			Fileora_Log::error( 'status failed', array( 'job' => $job_id, 'error' => $response->get_error_message() ) );
			return $response;
		}
		$json = json_decode( wp_remote_retrieve_body( $response ), true );
		return array(
			'status' => (int) wp_remote_retrieve_response_code( $response ),
			'body'   => is_array( $json ) ? $json : array(),
		);
	}

	/** Deletes the job folder on the service right away. */
	public static function delete( $job_id ) {
		wp_remote_request(
			self::url( '/jobs/' . $job_id ),
			array(
				'method'   => 'DELETE',
				'timeout'  => 5,
				'blocking' => false,
				'headers'  => array( 'X-Fileora-Key' => self::key() ),
			)
		);
	}

	/**
	 * Streams the result file straight to the browser without loading it
	 * into memory. Returns WP_Error only if nothing was sent yet.
	 *
	 * @return true|WP_Error
	 */
	public static function stream( $job_id, $fallback_name ) {
		$headers = array();
		$started = false;
		$status  = 0;
		$ch      = curl_init( self::url( '/jobs/' . $job_id . '/file' ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_init
		curl_setopt_array( // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt_array
			$ch,
			array(
				CURLOPT_HTTPHEADER     => array( 'X-Fileora-Key: ' . self::key() ),
				CURLOPT_CONNECTTIMEOUT => 5,
				CURLOPT_TIMEOUT        => 600,
				CURLOPT_HEADERFUNCTION => function ( $ch, $line ) use ( &$headers, &$status ) {
					if ( preg_match( '#^HTTP/\S+\s+(\d{3})#', $line, $m ) ) {
						$status = (int) $m[1];
					}
					$parts = explode( ':', $line, 2 );
					if ( 2 === count( $parts ) ) {
						$headers[ strtolower( trim( $parts[0] ) ) ] = trim( $parts[1] );
					}
					return strlen( $line );
				},
				CURLOPT_WRITEFUNCTION  => function ( $ch, $chunk ) use ( &$headers, &$started, &$status, $fallback_name ) {
					if ( 200 !== $status ) {
						return strlen( $chunk ); // swallow error bodies; handled below
					}
					if ( ! $started ) {
						$started = true;
						while ( ob_get_level() ) {
							ob_end_clean();
						}
						nocache_headers();
						header( 'Content-Type: ' . ( isset( $headers['content-type'] ) ? $headers['content-type'] : 'application/octet-stream' ) );
						header( 'Content-Disposition: ' . ( isset( $headers['content-disposition'] ) ? $headers['content-disposition'] : 'attachment; filename="' . sanitize_file_name( $fallback_name ) . '"' ) );
						if ( isset( $headers['content-length'] ) ) {
							header( 'Content-Length: ' . (int) $headers['content-length'] );
						}
						header( 'X-Content-Type-Options: nosniff' );
					}
					echo $chunk; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- binary file data
					flush();
					return strlen( $chunk );
				},
			)
		);
		$ok = curl_exec( $ch ); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_exec
		curl_close( $ch ); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_close
		if ( $started ) {
			return true;
		}
		Fileora_Log::error( 'download failed', array( 'job' => $job_id, 'status' => $status, 'ok' => (bool) $ok ) );
		return new WP_Error( 'fileora_download', 'The result couldn’t be downloaded. Please run the task again.' );
	}

	/** @return array|WP_Error Tool readiness reported by the service. */
	public static function health() {
		$response = wp_remote_get( self::url( '/health' ), array( 'timeout' => 5 ) );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$json = json_decode( wp_remote_retrieve_body( $response ), true );
		return is_array( $json ) ? $json : new WP_Error( 'fileora_health', 'Unexpected answer from the processing server.' );
	}
}
