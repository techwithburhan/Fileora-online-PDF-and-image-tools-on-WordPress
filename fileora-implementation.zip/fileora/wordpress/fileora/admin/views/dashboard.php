<?php
/**
 * Dashboard screen: server health and usage of the last 30 days.
 *
 * @package Fileora
 * @var array|WP_Error $health
 * @var array          $stats
 * @var array          $failures
 * @var array          $tools
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wrap">
	<h1>Fileora</h1>

	<h2>Processing server</h2>
	<?php if ( is_wp_error( $health ) ) : ?>
		<div class="notice notice-error inline"><p><strong>Not reachable:</strong> <?php echo esc_html( $health->get_error_message() ); ?></p></div>
	<?php else : ?>
		<p>
			Status: <strong style="color:<?php echo ! empty( $health['ok'] ) ? '#008a20' : '#d63638'; ?>"><?php echo ! empty( $health['ok'] ) ? 'Running' : 'Running without a shared key'; ?></strong>
			<?php if ( isset( $health['workers'] ) ) : ?>
				&nbsp;·&nbsp; Parallel jobs: <?php echo (int) $health['workers']; ?>
			<?php endif; ?>
			<?php if ( ! empty( $health['ocr_languages'] ) ) : ?>
				&nbsp;·&nbsp; OCR languages: <code><?php echo esc_html( implode( ', ', array_diff( (array) $health['ocr_languages'], array( 'osd' ) ) ) ); ?></code>
			<?php endif; ?>
		</p>
	<?php endif; ?>

	<h2>Server tasks, last 30 days</h2>
	<?php if ( ! $stats ) : ?>
		<p>No server tasks yet. Browser tools aren’t counted because they never reach the server.</p>
	<?php else : ?>
		<table class="widefat striped" style="max-width:820px">
			<thead><tr><th>Tool</th><th>Tasks</th><th>Done</th><th>Failed</th><th>Average time</th><th>Uploaded</th></tr></thead>
			<tbody>
			<?php foreach ( $stats as $row ) : ?>
				<tr>
					<td><?php echo esc_html( isset( $tools[ $row->tool ] ) ? $tools[ $row->tool ]['label'] : $row->tool ); ?></td>
					<td><?php echo (int) $row->total; ?></td>
					<td><?php echo (int) $row->done; ?></td>
					<td><?php echo (int) $row->failed; ?></td>
					<td><?php echo null === $row->avg_seconds ? '–' : esc_html( (int) $row->avg_seconds . ' s' ); ?></td>
					<td><?php echo esc_html( size_format( (int) $row->bytes_in ) ); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>

	<?php if ( $failures ) : ?>
		<h2>Recent failures</h2>
		<table class="widefat striped" style="max-width:820px">
			<thead><tr><th>When (UTC)</th><th>Tool</th><th>Message shown to the visitor</th></tr></thead>
			<tbody>
			<?php foreach ( $failures as $row ) : ?>
				<tr>
					<td><?php echo esc_html( $row->created_at ); ?></td>
					<td><?php echo esc_html( isset( $tools[ $row->tool ] ) ? $tools[ $row->tool ]['label'] : $row->tool ); ?></td>
					<td><?php echo esc_html( (string) $row->error ); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>
</div>
