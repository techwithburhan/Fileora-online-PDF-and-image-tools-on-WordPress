/*
 * Fileora image tools: runs entirely in the browser (no upload, no server).
 * Works in current Chrome, Edge, Firefox and Safari.
 *
 *   const out = await FileoraImage.compress(file, { quality: 0.7, maxSide: 2400 });
 *   const out = await FileoraImage.resize(file, { width: 1080 });            // keeps the ratio
 *   const out = await FileoraImage.convert(file, 'image/png');              // JPG -> PNG
 *   const out = await FileoraImage.crop(file, { x: 0, y: 0, width: 800, height: 600 });
 *   // out = { blob, name, width, height }  -> URL.createObjectURL(out.blob) to download
 *
 * Image to PDF already exists in Fileora as the "JPG to PDF" tool.
 * build.mjs puts this file into fileora.html before app-core.js.
 */
(function (global) {
  'use strict';

  const EXT = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' };

  /* Decode any browser-supported image and apply its EXIF rotation. */
  async function decode(file) {
    try {
      const bmp = await createImageBitmap(file, { imageOrientation: 'from-image' });
      return { src: bmp, width: bmp.width, height: bmp.height, close: () => bmp.close() };
    } catch (e) {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.src = url;
      try { await img.decode(); } catch (err) { URL.revokeObjectURL(url); throw new Error(file.name + ' is not an image this browser can read.'); }
      return { src: img, width: img.naturalWidth, height: img.naturalHeight, close: () => URL.revokeObjectURL(url) };
    }
  }

  function canvasOf(w, h) {
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(w));
    c.height = Math.max(1, Math.round(h));
    return c;
  }

  function toBlob(canvas, type, quality) {
    return new Promise((resolve, reject) =>
      canvas.toBlob(b => (b ? resolve(b) : reject(new Error('This browser cannot write ' + type))), type, quality));
  }

  function rename(name, type, suffix) {
    return name.replace(/\.[^.]+$/, '') + (suffix || '') + '.' + EXT[type];
  }

  /* Draw an image region onto a canvas of the target size and encode it. */
  async function render(file, { sx = 0, sy = 0, sw, sh, width, height, type, quality = 0.9, suffix }) {
    const img = await decode(file);
    sw = sw || img.width; sh = sh || img.height;
    width = width || sw; height = height || sh;
    const c = canvasOf(width, height);
    const g = c.getContext('2d');
    if (type === 'image/jpeg') { g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); } // JPG has no transparency
    g.imageSmoothingQuality = 'high';
    g.drawImage(img.src, sx, sy, sw, sh, 0, 0, c.width, c.height);
    img.close();
    const blob = await toBlob(c, type, quality);
    return { blob, name: rename(file.name, type, suffix), width: c.width, height: c.height };
  }

  /* Pick an output type: keep JPG/PNG/WebP, turn anything else into JPG. */
  function sameType(file) { return EXT[file.type] ? file.type : 'image/jpeg'; }

  const FileoraImage = {
    /** Smaller file: lower quality and, optionally, a maximum width/height. */
    async compress(file, { quality = 0.72, maxSide = 0, type } = {}) {
      const img = await decode(file); const w = img.width, h = img.height; img.close();
      const scale = maxSide ? Math.min(1, maxSide / Math.max(w, h)) : 1;
      // PNG ignores the quality setting, so compress PNG photos as WebP unless told otherwise.
      const outType = type || (file.type === 'image/png' ? 'image/webp' : sameType(file));
      const out = await render(file, { width: w * scale, height: h * scale, type: outType, quality, suffix: '-compressed' });
      if (out.blob.size >= file.size && scale === 1) {
        return { blob: file, name: file.name, width: w, height: h, note: 'Already optimized' };
      }
      return out;
    },

    /** New size in pixels. Give width or height to keep the ratio, or both to force a size. */
    async resize(file, { width, height, percent, type } = {}) {
      const img = await decode(file); const w = img.width, h = img.height; img.close();
      if (percent) { width = w * percent / 100; height = h * percent / 100; }
      else if (width && !height) height = h * width / w;
      else if (height && !width) width = w * height / h;
      if (!width || !height) throw new Error('Give a width, a height or a percentage.');
      return render(file, { width, height, type: type || sameType(file), quality: 0.92, suffix: '-' + Math.round(width) + 'x' + Math.round(height) });
    },

    /** Change format: 'image/jpeg', 'image/png' or 'image/webp'. */
    async convert(file, type, { quality = 0.92 } = {}) {
      if (!EXT[type]) throw new Error('Choose JPG, PNG or WebP.');
      return render(file, { type, quality });
    },

    /** Keep only a rectangle, in pixels of the original image. */
    async crop(file, { x, y, width, height, type } = {}) {
      const img = await decode(file); const w = img.width, h = img.height; img.close();
      x = Math.max(0, Math.round(x || 0)); y = Math.max(0, Math.round(y || 0));
      width = Math.min(w - x, Math.round(width)); height = Math.min(h - y, Math.round(height));
      if (!(width > 0 && height > 0)) throw new Error('The crop area is outside the image.');
      return render(file, { sx: x, sy: y, sw: width, sh: height, type: type || sameType(file), quality: 0.92, suffix: '-cropped' });
    }
  };

  global.FileoraImage = FileoraImage;
})(window);
