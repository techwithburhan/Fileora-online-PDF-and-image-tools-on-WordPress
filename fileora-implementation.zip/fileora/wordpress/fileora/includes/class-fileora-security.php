<?php
/**
 * Upload validation, visitor identity (hashed) and job tokens.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Security {

	/** The visitor's IP. Behind Cloudflare or a proxy, filter this (see README). */
	public static function client_ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return (string) apply_filters( 'fileora_client_ip', $ip );
	}

	/** We store a keyed hash, never the raw IP address. */
	public static function ip_hash() {
		return hash_hmac( 'sha256', self::client_ip(), wp_salt( 'auth' ) );
	}

	/** Random token the browser must show to read a job's status or result. */
	public static function new_token() {
		$token = bin2hex( random_bytes( 24 ) );
		return array( $token, hash( 'sha256', $token ) );
	}

	public static function token_matches( $token, $hash ) {
		return is_string( $token ) && '' !== $token && hash_equals( (string) $hash, hash( 'sha256', $token ) );
	}

	/**
	 * Turns $_FILES['files'] (single or multiple) into a flat list.
	 *
	 * @param array|null $files Raw entry from the request.
	 * @return array<int, array{name:string, tmp_name:string, size:int, error:int}>
	 */
	public static function normalize_files( $files ) {
		if ( empty( $files ) || ! isset( $files['name'] ) ) {
			return array();
		}
		$list = array();
		if ( is_array( $files['name'] ) ) {
			foreach ( array_keys( $files['name'] ) as $i ) {
				$list[] = array(
					'name'     => (string) $files['name'][ $i ],
					'tmp_name' => (string) $files['tmp_name'][ $i ],
					'size'     => (int) $files['size'][ $i ],
					'error'    => (int) $files['error'][ $i ],
				);
			}
		} else {
			$list[] = array(
				'name'     => (string) $files['name'],
				'tmp_name' => (string) $files['tmp_name'],
				'size'     => (int) $files['size'],
				'error'    => (int) $files['error'],
			);
		}
		return $list;
	}

	/**
	 * Checks one uploaded file: upload error, size, extension and real content.
	 *
	 * @return true|WP_Error
	 */
	public static function validate_file( array $file, $accept, $max_bytes ) {
		$name = sanitize_file_name( $file['name'] );
		if ( UPLOAD_ERR_OK !== $file['error'] ) {
			if ( in_array( $file['error'], array( UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE ), true ) ) {
				return new WP_Error( 'fileora_too_big', sprintf( '%s is larger than this server allows.', $name ), array( 'status' => 413 ) );
			}
			return new WP_Error( 'fileora_upload', sprintf( '%s didn’t upload completely. Please try again.', $name ), array( 'status' => 400 ) );
		}
		if ( ! is_uploaded_file( $file['tmp_name'] ) ) {
			return new WP_Error( 'fileora_upload', 'The upload could not be verified.', array( 'status' => 400 ) );
		}
		if ( $file['size'] > $max_bytes ) {
			return new WP_Error( 'fileora_too_big', sprintf( '%s is larger than %d MB.', $name, (int) ( $max_bytes / MB_IN_BYTES ) ), array( 'status' => 413 ) );
		}
		$ext     = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
		$allowed = isset( Fileora_Tools::EXTENSIONS[ $accept ] ) ? Fileora_Tools::EXTENSIONS[ $accept ] : array();
		if ( ! in_array( $ext, $allowed, true ) ) {
			return new WP_Error( 'fileora_type', sprintf( '%s isn’t a supported file for this tool.', $name ), array( 'status' => 415 ) );
		}
		if ( ! self::content_matches( $file['tmp_name'], $ext ) ) {
			return new WP_Error( 'fileora_type', sprintf( '%s doesn’t look like a real .%s file.', $name, $ext ), array( 'status' => 415 ) );
		}
		return true;
	}

	/** Checks the file's first bytes, so a renamed .exe can't pass as a PDF. */
	public static function content_matches( $path, $ext ) {
		$fh = fopen( $path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		if ( ! $fh ) {
			return false;
		}
		$head = (string) fread( $fh, 1024 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fread
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose

		$zip = 0 === strpos( $head, "PK\x03\x04" );
		$ole = 0 === strpos( $head, "\xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1" );
		switch ( $ext ) {
			case 'pdf':
				return false !== strpos( $head, '%PDF-' );
			case 'docx':
			case 'xlsx':
			case 'pptx':
			case 'ppsx':
			case 'odt':
			case 'ods':
			case 'odp':
				return $zip;
			case 'doc':
			case 'xls':
			case 'ppt':
			case 'pps':
				return $ole;
			case 'rtf':
				return 0 === strpos( ltrim( $head ), '{\rtf' );
			case 'txt':
			case 'csv':
				return false === strpos( $head, "\0" );
		}
		return false;
	}
}
