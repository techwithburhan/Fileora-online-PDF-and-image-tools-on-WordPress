#!/usr/bin/env bash
# Fileora processing service installer, for Ubuntu 24.04 LTS.
#
#   sudo bash install.sh
#   sudo FILEORA_KEY=<key from WordPress> OCR_LANGS="hin ben tam" bash install.sh
#
# Run it from the folder that contains app.py. Safe to run again to update.
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "Run as root: sudo bash install.sh"; exit 1; }
HERE="$(cd "$(dirname "$0")" && pwd)"
OCR_LANGS="${OCR_LANGS:-hin}"   # extra OCR languages (English is always included)
. /etc/os-release
[ "${VERSION_ID:-}" = "24.04" ] || echo "Note: tested on Ubuntu 24.04; you have ${PRETTY_NAME:-unknown}."

echo "==> 1/5 System packages (LibreOffice, Ghostscript, qpdf, Tesseract, fonts)"
apt-get update -q
DEBIAN_FRONTEND=noninteractive apt-get install -y -q --no-install-recommends \
  python3 python3-venv python3-pip curl ca-certificates \
  libreoffice-writer libreoffice-calc libreoffice-impress \
  ghostscript qpdf tesseract-ocr unpaper pngquant \
  fonts-noto-core fonts-noto-cjk fonts-liberation fonts-dejavu-core \
  fonts-crosextra-carlito fonts-crosextra-caladea
for lang in $OCR_LANGS; do
  DEBIAN_FRONTEND=noninteractive apt-get install -y -q "tesseract-ocr-${lang}"
done

echo "==> 2/5 Service user and folders"
id fileora >/dev/null 2>&1 || useradd --system --home-dir /var/lib/fileora --shell /usr/sbin/nologin fileora
install -d -o fileora -g fileora -m 750 /var/lib/fileora /var/lib/fileora/jobs
install -d -m 755 /opt/fileora/app
install -m 644 "$HERE/app.py" "$HERE/requirements.txt" /opt/fileora/app/

echo "==> 3/5 Python libraries and Chromium"
[ -d /opt/fileora/venv ] || python3 -m venv /opt/fileora/venv
/opt/fileora/venv/bin/pip install -q --upgrade pip
/opt/fileora/venv/bin/pip install -q -r /opt/fileora/app/requirements.txt
PLAYWRIGHT_BROWSERS_PATH=/opt/fileora/browsers /opt/fileora/venv/bin/playwright install --with-deps chromium
chmod -R a+rX /opt/fileora/browsers

echo "==> 4/5 Configuration (/etc/fileora/fileora.env)"
install -d -m 755 /etc/fileora
[ -f /etc/fileora/fileora.env ] || install -m 600 "$HERE/deploy/fileora.env.example" /etc/fileora/fileora.env
if [ -n "${FILEORA_KEY:-}" ]; then
  sed -i "s|^FILEORA_KEY=.*|FILEORA_KEY=${FILEORA_KEY}|" /etc/fileora/fileora.env
fi

echo "==> 5/5 systemd service"
install -m 644 "$HERE/deploy/fileora.service" /etc/systemd/system/fileora.service
systemctl daemon-reload
systemctl enable fileora >/dev/null
systemctl restart fileora
sleep 4
if curl -fsS http://127.0.0.1:8000/health; then
  echo; echo "Fileora processing service is running on 127.0.0.1:8000."
else
  echo "The service didn't answer. Check: journalctl -u fileora -n 50"; exit 1
fi
grep -q '^FILEORA_KEY=paste' /etc/fileora/fileora.env && \
  echo "Next: put the shared key from WordPress -> Fileora -> Settings into /etc/fileora/fileora.env, then: systemctl restart fileora"
exit 0
