<?php
/**
 * Bootstrap: wires every module to WordPress.
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

final class Fileora_Plugin {

	public static function boot() {
		Fileora_Frontend::init();
		Fileora_REST::init();
		Fileora_Cleanup::init();
		if ( is_admin() ) {
			Fileora_Admin::init();
		}
		// Upgrade the database table when the plugin version changes.
		add_action( 'plugins_loaded', array( 'Fileora_Jobs', 'maybe_upgrade' ) );
	}

	public static function activate() {
		Fileora_Jobs::install();
		Fileora_Settings::ensure_defaults();
		Fileora_Cleanup::schedule();
	}

	public static function deactivate() {
		Fileora_Cleanup::unschedule();
	}
}
