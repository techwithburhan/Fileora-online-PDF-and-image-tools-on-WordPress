import fs from 'fs';
const d = new URL('./src/', import.meta.url);
let html = fs.readFileSync(new URL('index.html', d), 'utf8');
const css = fs.readFileSync(new URL('style.css', d), 'utf8');
const js = ['image-tools.js', 'app-core.js', 'app-tools.js'].map(f => fs.readFileSync(new URL(f, d), 'utf8')).join('\n');
html = html.replace('/*@CSS*/', () => css).replace('//@JS', () => js);
fs.writeFileSync(new URL('./fileora.html', import.meta.url), html);
console.log('built', (html.length/1024).toFixed(1)+' KB');
fs.mkdirSync(new URL('./wordpress/fileora/public/', import.meta.url), { recursive: true });
fs.writeFileSync(new URL('./wordpress/fileora/public/fileora.html', import.meta.url), html);
console.log('copied to wordpress/fileora/public/fileora.html');

/* tools.json: tool names, descriptions and page addresses for the WordPress plugin (SEO pages, sitemap) */
import vm from 'vm';
const sandbox = { window: {}, navigator: { platform: '', userAgent: '' }, localStorage: { getItem: () => null, setItem() {} },
  matchMedia: () => ({ matches: false }), document: { addEventListener() {}, documentElement: {} }, console };
sandbox.globalThis = sandbox;
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(new URL('app-core.js', d), 'utf8') + '\n;globalThis.__out = { TOOLS, CATS };', sandbox);
const { TOOLS, CATS } = sandbox.__out;
const slug = t => t.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
const tools = TOOLS.map(t => ({ id: t.id, slug: slug(t), name: t.name, desc: t.desc, category: CATS.find(c => c.id === t.cat).name, browser: !!t.client && !t.serverFirst }));
fs.writeFileSync(new URL('./wordpress/fileora/public/tools.json', import.meta.url), JSON.stringify(tools, null, 1));
console.log('tools.json:', tools.length, 'tools');
