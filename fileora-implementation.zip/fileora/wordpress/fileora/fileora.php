<?php
/**
 * Plugin Name:       Fileora
 * Plugin URI:        https://fileora.com
 * Description:       Online PDF and document tools. Serves the Fileora website and connects its server-side tools to the Fileora processing service.
 * Version:           1.0.0
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            Fileora
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       fileora
 *
 * @package Fileora
 */

defined( 'ABSPATH' ) || exit;

define( 'FILEORA_VERSION', '1.0.0' );
define( 'FILEORA_FILE', __FILE__ );
define( 'FILEORA_DIR', plugin_dir_path( __FILE__ ) );

require_once FILEORA_DIR . 'includes/class-fileora-log.php';
require_once FILEORA_DIR . 'includes/class-fileora-tools.php';
require_once FILEORA_DIR . 'includes/class-fileora-settings.php';
require_once FILEORA_DIR . 'includes/class-fileora-security.php';
require_once FILEORA_DIR . 'includes/class-fileora-jobs.php';
require_once FILEORA_DIR . 'includes/class-fileora-processor.php';
require_once FILEORA_DIR . 'includes/class-fileora-rest.php';
require_once FILEORA_DIR . 'includes/class-fileora-frontend.php';
require_once FILEORA_DIR . 'includes/class-fileora-cleanup.php';
require_once FILEORA_DIR . 'includes/class-fileora-admin.php';
require_once FILEORA_DIR . 'includes/class-fileora-plugin.php';

register_activation_hook( __FILE__, array( 'Fileora_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Fileora_Plugin', 'deactivate' ) );

Fileora_Plugin::boot();
