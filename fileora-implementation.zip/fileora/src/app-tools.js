/* =====================================================================
   Workspace, processing engine, workflows, drop handling, hero motion
   ===================================================================== */
class UserError extends Error {}
class NoServer extends Error {}

/* ---------------- on-demand libraries ---------------- */
const LIBS = {
  pdflib: ['https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js', 'https://unpkg.com/pdf-lib@1.17.1/dist/pdf-lib.min.js'],
  pdfjs: ['https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js', 'https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.min.js'],
  jszip: ['https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js', 'https://unpkg.com/jszip@3.10.1/dist/jszip.min.js']
};
const libCache = {};
function loadScript(src) {
  return new Promise((res, rej) => {
    const s = document.createElement('script');
    s.src = src; s.async = true; s.crossOrigin = 'anonymous';
    s.onload = () => res(src);
    s.onerror = () => { s.remove(); rej(new Error('load failed')); };
    document.head.appendChild(s);
  });
}
function lib(name) {
  if (!libCache[name]) {
    libCache[name] = (async () => {
      let used = null;
      for (const u of LIBS[name]) { try { used = await loadScript(u); break; } catch (e) { /* try next */ } }
      if (!used) throw new Error('offline');
      if (name === 'pdfjs') window.pdfjsLib.GlobalWorkerOptions.workerSrc = used.replace('pdf.min.js', 'pdf.worker.min.js');
      return name === 'pdflib' ? window.PDFLib : name === 'pdfjs' ? window.pdfjsLib : window.JSZip;
    })().catch(e => { delete libCache[name]; throw e; });
  }
  return libCache[name];
}

/* ---------------- low-level helpers ---------------- */
async function pdfjsDoc(file) {
  const pdfjs = await lib('pdfjs');
  const data = new Uint8Array(await file.arrayBuffer());
  return pdfjs.getDocument({ data, isEvalSupported: false }).promise;
}
async function renderPage(page, scale) {
  let vp = page.getViewport({ scale });
  const max = 16e6;
  if (vp.width * vp.height > max) { scale *= Math.sqrt(max / (vp.width * vp.height)); vp = page.getViewport({ scale }); }
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.floor(vp.width)); c.height = Math.max(1, Math.floor(vp.height));
  const g = c.getContext('2d');
  g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height);
  await page.render({ canvasContext: g, viewport: vp }).promise;
  return c;
}
const canvasToBlob = (c, type, q) => new Promise((res, rej) => c.toBlob(b => b ? res(b) : rej(new Error('canvas')), type, q));
async function canvasUrl(c, q = .8) { const u = URL.createObjectURL(await canvasToBlob(c, 'image/jpeg', q)); WS.urls.push(u); c.width = c.height = 0; return u; }
const pdfOut = (name, bytes, note) => ({ name, blob: new Blob([bytes], { type: 'application/pdf' }), note });
async function loadPdf(it) {
  const { PDFDocument } = await lib('pdflib');
  let doc;
  try { doc = await PDFDocument.load(await it.file.arrayBuffer(), { ignoreEncryption: true }); }
  catch (e) { throw new UserError(`${it.name} couldn’t be opened. It may be damaged, so try Repair PDF first.`); }
  if (doc.isEncrypted) throw new UserError(`${it.name} is password-protected. Unlock it first, then try again.`);
  return doc;
}
async function savePdf(doc) { doc.setProducer('Fileora'); doc.setCreator('Fileora'); return doc.save(); }
function friendly(e) {
  const m = String(e && (e.message || e.name) || '');
  if (m === 'offline') return 'The PDF engine couldn’t load. Check your internet connection and try again.';
  if (/password|encrypt/i.test(m)) return 'This PDF is password-protected. Unlock it first, then try again.';
  return 'Something went wrong while processing the file. If it may be damaged, try Repair PDF first.';
}
/* visual page geometry that respects /Rotate */
function vis(page) {
  const r = ((page.getRotation().angle % 360) + 360) % 360;
  const b = page.getCropBox();
  const W = b.width, H = b.height;
  const map = (u, v) => r === 90 ? { x: b.x + W - v, y: b.y + u } : r === 180 ? { x: b.x + W - u, y: b.y + H - v } : r === 270 ? { x: b.x + v, y: b.y + H - u } : { x: b.x + u, y: b.y + v };
  return { W: r % 180 ? H : W, H: r % 180 ? W : H, r, map };
}
function parseRanges(str, n) {
  const groups = [];
  for (const raw of String(str || '').split(/[,;]+/)) {
    const s = raw.trim().toLowerCase().replace(/\s+/g, '');
    if (!s) continue;
    let m, a, b;
    if ((m = /^(\d+)$/.exec(s))) { a = b = +m[1]; }
    else if ((m = /^(\d*)-(\d*|end|last)$/.exec(s))) { a = m[1] ? +m[1] : 1; b = (!m[2] || m[2] === 'end' || m[2] === 'last') ? n : +m[2]; }
    else throw new UserError(`“${raw.trim()}” isn’t a page range. Use something like 1-3, 5.`);
    if (a < 1 || b > n || a > b) throw new UserError(`Pages ${a}${a !== b ? '-' + b : ''} don’t exist. This PDF has ${n} page${n > 1 ? 's' : ''}.`);
    groups.push(Array.from({ length: b - a + 1 }, (_, i) => a - 1 + i));
  }
  return groups;
}
const rangeLabel = g => g.length === 1 ? `page-${g[0] + 1}` : (g[g.length - 1] - g[0] === g.length - 1 ? `pages-${g[0] + 1}-${g[g.length - 1] + 1}` : `part`);

/* images */
async function decodeImage(file) {
  try { const bmp = await createImageBitmap(file, { imageOrientation: 'from-image' }); return { src: bmp, w: bmp.width, h: bmp.height, done: () => bmp.close() }; }
  catch (e) {
    const url = URL.createObjectURL(file); const img = new Image(); img.src = url;
    try { await img.decode(); } catch (er) { URL.revokeObjectURL(url); throw new UserError(`${file.name} couldn’t be read as an image.`); }
    return { src: img, w: img.naturalWidth, h: img.naturalHeight, done: () => URL.revokeObjectURL(url) };
  }
}
function filterPixels(g, w, h, mode) {
  const d = g.getImageData(0, 0, w, h), px = d.data, n = px.length;
  const lum = new Float32Array(n / 4);
  const hist = new Uint32Array(256);
  for (let i = 0, k = 0; i < n; i += 4, k++) { const l = px[i] * .299 + px[i + 1] * .587 + px[i + 2] * .114; lum[k] = l; hist[l | 0]++; }
  const total = n / 4; let acc = 0, lo = 0, hi = 255;
  for (let v = 0; v < 256; v++) { acc += hist[v]; if (acc > total * .02) { lo = v; break; } }
  acc = 0; for (let v = 255; v >= 0; v--) { acc += hist[v]; if (acc > total * .08) { hi = v; break; } }
  const span = Math.max(24, hi - lo);
  for (let i = 0, k = 0; i < n; i += 4, k++) {
    let v = (lum[k] - lo) / span; v = v < 0 ? 0 : v > 1 ? 1 : v;
    if (mode === 'doc') v = 1 / (1 + Math.exp(-11 * (v - .52)));
    else v = Math.pow(v, .92);
    const o = v * 255; px[i] = px[i + 1] = px[i + 2] = o;
  }
  g.putImageData(d, 0, 0);
}
async function imageForPdf(file, filter) {
  const d = await decodeImage(file);
  const s = Math.min(1, 4200 / Math.max(d.w, d.h));
  const w = Math.max(1, Math.round(d.w * s)), h = Math.max(1, Math.round(d.h * s));
  const png = (file.type === 'image/png' || extOf(file.name) === 'png') && (!filter || filter === 'none');
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const g = c.getContext('2d', { willReadFrequently: !!filter && filter !== 'none' });
  if (!png) { g.fillStyle = '#fff'; g.fillRect(0, 0, w, h); }
  g.drawImage(d.src, 0, 0, w, h); d.done();
  if (filter && filter !== 'none') filterPixels(g, w, h, filter);
  const blob = await canvasToBlob(c, png ? 'image/png' : 'image/jpeg', .9);
  c.width = c.height = 0;
  return { bytes: await blob.arrayBuffer(), w, h, png };
}
const PAGE = { a4: [595.28, 841.89], letter: [612, 792] };
async function imagesToPdf(items, o, ctx, filter) {
  const { PDFDocument } = await lib('pdflib');
  const doc = await PDFDocument.create();
  const margin = { none: 0, small: 20, large: 42 }[o.margin] ?? 20;
  for (let i = 0; i < items.length; i++) {
    ctx.progress(i / items.length, `Image ${i + 1} of ${items.length}`);
    const im = await imageForPdf(items[i].file, filter);
    const img = im.png ? await doc.embedPng(im.bytes) : await doc.embedJpg(im.bytes);
    let pw, ph;
    if (o.size === 'fit') { pw = im.w * .75 + margin * 2; ph = im.h * .75 + margin * 2; }
    else {
      [pw, ph] = PAGE[o.size] || PAGE.a4;
      const land = o.orient === 'landscape' || (o.orient !== 'portrait' && im.w > im.h);
      if (land) [pw, ph] = [ph, pw];
    }
    const bw = pw - margin * 2, bh = ph - margin * 2, sc = Math.min(bw / im.w, bh / im.h);
    const dw = im.w * sc, dh = im.h * sc;
    doc.addPage([pw, ph]).drawImage(img, { x: (pw - dw) / 2, y: (ph - dh) / 2, width: dw, height: dh });
  }
  ctx.progress(.96, 'Saving');
  return savePdf(doc);
}
async function rasterize(file, dpi, q, prog) {
  const pdf = await pdfjsDoc(file);
  const { PDFDocument } = await lib('pdflib');
  const out = await PDFDocument.create();
  const n = pdf.numPages;
  for (let i = 1; i <= n; i++) {
    prog && prog((i - 1) / n, `Page ${i} of ${n}`);
    const page = await pdf.getPage(i);
    const vp = page.getViewport({ scale: 1 });
    const c = await renderPage(page, dpi / 72);
    const blob = await canvasToBlob(c, 'image/jpeg', q);
    c.width = c.height = 0;
    const img = await out.embedJpg(await blob.arrayBuffer());
    out.addPage([vp.width, vp.height]).drawImage(img, { x: 0, y: 0, width: vp.width, height: vp.height });
    page.cleanup();
  }
  await pdf.destroy();
  return savePdf(out);
}
async function textPng(text, color) {
  try { await document.fonts.load('700 120px Geist'); } catch (e) { /* fallback font */ }
  const px = 120, font = `700 ${px}px Geist, 'Helvetica Neue', Arial, 'Noto Sans', sans-serif`;
  const c = document.createElement('canvas'), g = c.getContext('2d');
  g.font = font;
  const w = Math.ceil(g.measureText(text).width + px * .24), h = Math.ceil(px * 1.32);
  c.width = w; c.height = h;
  g.font = font; g.fillStyle = color; g.textBaseline = 'middle';
  g.fillText(text, px * .12, h / 2 + px * .04);
  const blob = await canvasToBlob(c, 'image/png');
  return { bytes: await blob.arrayBuffer(), w, h, px };
}
/* text lines from a PDF (pdf.js) */
async function pdfLines(file, prog, label) {
  const pdf = await pdfjsDoc(file);
  const pages = [];
  for (let i = 1; i <= pdf.numPages; i++) {
    prog && prog((i - 1) / pdf.numPages, `${label} page ${i} of ${pdf.numPages}`);
    const page = await pdf.getPage(i);
    const tc = await page.getTextContent();
    const lines = [];
    for (const it of tc.items) {
      if (typeof it.str !== 'string' || !it.str) continue;
      const tr = it.transform, size = Math.hypot(tr[2], tr[3]) || it.height || 10, x = tr[4], y = tr[5];
      let ln = null;
      for (let k = lines.length - 1; k >= Math.max(0, lines.length - 8); k--) if (Math.abs(lines[k].y - y) < size * .45) { ln = lines[k]; break; }
      if (!ln) { ln = { y, x, parts: [] }; lines.push(ln); }
      ln.parts.push({ x, s: it.str, w: it.width, size });
    }
    for (const ln of lines) {
      ln.parts.sort((a, b) => a.x - b.x);
      let txt = '', end = null;
      for (const p of ln.parts) { if (end !== null && p.x - end > p.size * .22 && !/\s$/.test(txt) && !/^\s/.test(p.s)) txt += ' '; txt += p.s; end = p.x + p.w; }
      ln.text = txt.replace(/\s+/g, ' ').trim();
      ln.size = Math.max(...ln.parts.map(p => p.size));
      ln.x = ln.parts[0].x;
    }
    pages.push(lines.filter(l => l.text).sort((a, b) => b.y - a.y));
    page.cleanup();
  }
  await pdf.destroy();
  return pages;
}
function toMarkdown(pages, breaks) {
  const hist = new Map();
  pages.flat().forEach(l => { const k = Math.round(l.size * 2) / 2; hist.set(k, (hist.get(k) || 0) + l.text.length); });
  let body = 11, best = 0;
  hist.forEach((v, k) => { if (v > best) { best = v; body = k; } });
  const blocks = [];
  pages.forEach((lines, pi) => {
    if (pi && breaks) blocks.push({ t: 'hr' });
    let prev = null;
    for (const l of lines) {
      const r = l.size / body, gap = prev ? prev.y - l.y : 0, last = blocks[blocks.length - 1];
      const near = prev && gap < Math.max(l.size, prev.size) * 1.75;
      const bul = /^[•●▪◦‣∙·■□▸►\-–*]\s*(.+)/.exec(l.text), num = /^(\d{1,3}|[a-z])[.)]\s+.+/i.exec(l.text);
      if (r >= 1.18 && l.text.length < 140 && !bul) {
        const lvl = r >= 1.75 ? 1 : r >= 1.38 ? 2 : 3;
        if (last && last.t === 'h' && last.lvl === lvl && near) last.text += ' ' + l.text; else blocks.push({ t: 'h', lvl, text: l.text });
      } else if (bul) blocks.push({ t: 'li', text: bul[1] });
      else if (num && l.text.length > 3) blocks.push({ t: 'ol', text: l.text });
      else if (last && (last.t === 'p' || last.t === 'li' || last.t === 'ol') && near && pi === last.page) {
        last.text = /[A-Za-z]-$/.test(last.text) && /^[a-z]/.test(l.text) ? last.text.slice(0, -1) + l.text : last.text + ' ' + l.text;
      } else blocks.push({ t: 'p', text: l.text });
      const nb = blocks[blocks.length - 1]; if (nb) nb.page = pi;
      prev = l;
    }
  });
  const out = [];
  blocks.forEach((b, i) => {
    const nx = blocks[i + 1];
    if (b.t === 'h') out.push('#'.repeat(b.lvl) + ' ' + b.text, '');
    else if (b.t === 'hr') out.push('---', '');
    else if (b.t === 'li' || b.t === 'ol') { out.push((b.t === 'li' ? '- ' : '') + b.text); if (!nx || (nx.t !== 'li' && nx.t !== 'ol')) out.push(''); }
    else out.push(b.text, '');
  });
  return out.join('\n').replace(/\n{3,}/g, '\n\n').trim() + '\n';
}
function diffLines(a, b) {
  let s = 0; while (s < a.length && s < b.length && a[s] === b[s]) s++;
  let ea = a.length, eb = b.length; while (ea > s && eb > s && a[ea - 1] === b[eb - 1]) { ea--; eb--; }
  const ops = [];
  for (let i = 0; i < s; i++) ops.push(['=', i, i]);
  const A = a.slice(s, ea), B = b.slice(s, eb), n = A.length, m = B.length;
  if (n * m > 9e6) { for (let i = 0; i < n; i++) ops.push(['-', s + i, -1]); for (let j = 0; j < m; j++) ops.push(['+', -1, s + j]); }
  else {
    const W = m + 1, L = new Uint16Array((n + 1) * W);
    for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) L[i * W + j] = A[i] === B[j] ? L[(i + 1) * W + j + 1] + 1 : Math.max(L[(i + 1) * W + j], L[i * W + j + 1]);
    let i = 0, j = 0;
    while (i < n && j < m) {
      if (A[i] === B[j]) { ops.push(['=', s + i, s + j]); i++; j++; }
      else if (L[(i + 1) * W + j] >= L[i * W + j + 1]) { ops.push(['-', s + i, -1]); i++; }
      else { ops.push(['+', -1, s + j]); j++; }
    }
    while (i < n) { ops.push(['-', s + i, -1]); i++; }
    while (j < m) { ops.push(['+', -1, s + j]); j++; }
  }
  for (let k = 0; k < a.length - ea; k++) ops.push(['=', ea + k, eb + k]);
  return ops;
}

/* ---------------- processors (in-browser tools) ---------------- */
const P = {};
P.merge = async (items, o, ctx) => {
  const { PDFDocument } = await lib('pdflib');
  const out = await PDFDocument.create();
  for (let i = 0; i < items.length; i++) {
    ctx.progress(i / items.length, `Adding ${items[i].name}`);
    const src = await loadPdf(items[i]);
    (await out.copyPages(src, src.getPageIndices())).forEach(p => out.addPage(p));
  }
  ctx.progress(.95, 'Saving');
  return [pdfOut('fileora-merged.pdf', await savePdf(out), `${out.getPageCount()} pages from ${items.length} files`)];
};
P.split = async (items, o, ctx) => {
  const { PDFDocument } = await lib('pdflib');
  const it = items[0], src = await loadPdf(it), n = src.getPageCount(), b = baseName(it.name);
  let groups;
  if (o.mode === 'all') groups = Array.from({ length: n }, (_, i) => [i]);
  else if (o.mode === 'chunk') { const k = Math.max(1, Math.floor(+o.chunk || 1)); groups = []; for (let i = 0; i < n; i += k) groups.push(Array.from({ length: Math.min(k, n - i) }, (_, j) => i + j)); }
  else { groups = parseRanges(o.ranges, n); if (!groups.length) throw new UserError('Enter at least one page range, like 1-3, 5.'); if (o.together) groups = [groups.flat()]; }
  const outs = [];
  for (let g = 0; g < groups.length; g++) {
    ctx.progress(g / groups.length, `Creating file ${g + 1} of ${groups.length}`);
    const d = await PDFDocument.create();
    (await d.copyPages(src, groups[g])).forEach(p => d.addPage(p));
    outs.push(pdfOut(`${b}-${groups.length === 1 && o.together ? 'extract' : rangeLabel(groups[g])}${outs.some(x => x.name.includes(rangeLabel(groups[g]))) ? '-' + (g + 1) : ''}.pdf`, await savePdf(d), `${groups[g].length} page${groups[g].length > 1 ? 's' : ''}`));
  }
  return outs;
};
P.organize = async (items, o, ctx) => {
  const { PDFDocument, degrees } = await lib('pdflib');
  if (!ctx.pages || !ctx.pages.length) throw new UserError('Keep at least one page.');
  const src = await loadPdf(items[0]);
  const d = await PDFDocument.create();
  const copied = await d.copyPages(src, ctx.pages.map(p => p.i));
  copied.forEach((p, k) => { const r = ctx.pages[k].rot; if (r) p.setRotation(degrees((p.getRotation().angle + r) % 360)); d.addPage(p); });
  ctx.progress(.9, 'Saving');
  return [pdfOut(baseName(items[0].name) + '-organized.pdf', await savePdf(d), `${copied.length} pages`)];
};
P.rotate = async (items, o, ctx) => {
  const { degrees } = await lib('pdflib');
  const outs = [];
  for (let i = 0; i < items.length; i++) {
    ctx.progress(i / items.length, `Rotating ${items[i].name}`);
    const doc = await loadPdf(items[i]);
    doc.getPages().forEach((p, k) => {
      if ((o.which === 'odd' && k % 2) || (o.which === 'even' && !(k % 2))) return;
      p.setRotation(degrees((p.getRotation().angle + +o.angle) % 360));
    });
    outs.push(pdfOut(baseName(items[i].name) + '-rotated.pdf', await savePdf(doc)));
  }
  return outs;
};
P.compress = async (items, o, ctx) => {
  const outs = [];
  for (let i = 0; i < items.length; i++) {
    const it = items[i];
    const prog = (f, l) => ctx.progress((i + f) / items.length, `${items.length > 1 ? it.name + ': ' : ''}${l}`);
    let bytes;
    if (o.level === 'light') { prog(.3, 'Cleaning up the file'); const doc = await loadPdf(it); bytes = await doc.save({ useObjectStreams: true }); }
    else bytes = await rasterize(it.file, o.level === 'strong' ? 72 : 110, o.level === 'strong' ? .5 : .66, prog);
    let blob = new Blob([bytes], { type: 'application/pdf' }), note, good = false;
    if (blob.size >= it.size) { blob = it.file; note = 'Already well optimized, so we kept the original size'; }
    else { note = `${Math.round((1 - blob.size / it.size) * 100)}% smaller (${fmtSize(it.size)} to ${fmtSize(blob.size)})`; good = true; }
    outs.push({ name: baseName(it.name) + '-compressed.pdf', blob, note, good });
  }
  return outs;
};
P.repair = async (items, o, ctx) => {
  const it = items[0], b = baseName(it.name);
  try {
    ctx.progress(.2, 'Rebuilding the file structure');
    const { PDFDocument } = await lib('pdflib');
    const doc = await PDFDocument.load(await it.file.arrayBuffer(), { ignoreEncryption: true, throwOnInvalidObject: false });
    if (doc.isEncrypted) throw new UserError(`${it.name} is password-protected. Unlock it first.`);
    if (!doc.getPageCount()) throw new Error('no pages');
    return [pdfOut(b + '-repaired.pdf', await savePdf(doc), `Rebuilt structure, ${doc.getPageCount()} pages recovered`)];
  } catch (e) {
    if (e instanceof UserError) throw e;
    try { return [pdfOut(b + '-repaired.pdf', await rasterize(it.file, 150, .85, (f, l) => ctx.progress(.3 + f * .65, 'Recovering ' + l.toLowerCase())), 'Rebuilt from page images. Text may no longer be selectable.')]; }
    catch (e2) { throw new UserError(`We couldn’t recover ${it.name}. The file is too damaged, or it isn’t a PDF.`); }
  }
};
P.jpg2pdf = async (items, o, ctx) => [pdfOut(items.length === 1 ? baseName(items[0].name) + '.pdf' : 'fileora-images.pdf', await imagesToPdf(items, o, ctx, 'none'), `${items.length} page${items.length > 1 ? 's' : ''}`)];
P.scan = async (items, o, ctx) => [pdfOut('fileora-scan.pdf', await imagesToPdf(items, o, ctx, o.filter), `${items.length} page${items.length > 1 ? 's' : ''}`)];
P.pdf2jpg = async (items, o, ctx) => {
  const outs = [], ext = o.format === 'png' ? 'png' : 'jpg';
  for (let f = 0; f < items.length; f++) {
    const pdf = await pdfjsDoc(items[f].file), n = pdf.numPages, b = baseName(items[f].name);
    for (let i = 1; i <= n; i++) {
      ctx.progress((f + (i - 1) / n) / items.length, `Page ${i} of ${n}`);
      const page = await pdf.getPage(i);
      const c = await renderPage(page, +o.dpi / 72);
      const blob = await canvasToBlob(c, ext === 'png' ? 'image/png' : 'image/jpeg', .9);
      outs.push({ name: `${b}-page-${String(i).padStart(String(n).length, '0')}.${ext}`, blob, note: `${c.width} × ${c.height} px, ${fmtSize(blob.size)}` });
      c.width = c.height = 0; page.cleanup();
    }
    await pdf.destroy();
  }
  return outs;
};
P.pdf2md = async (items, o, ctx) => {
  const pages = await pdfLines(items[0].file, (f, l) => ctx.progress(f * .9, l), 'Reading');
  const md = toMarkdown(pages, o.breaks);
  if (md.trim().length < 2) throw new UserError('We couldn’t find any text in this PDF. If it’s a scan, run OCR PDF first.');
  ctx.result = { md };
  return [{ name: baseName(items[0].name) + '.md', blob: new Blob([md], { type: 'text/markdown' }), note: `${md.split(/\s+/).filter(Boolean).length.toLocaleString()} words` }];
};
P.sign = async (items, o, ctx) => {
  const { StandardFonts, rgb, degrees } = await lib('pdflib');
  const sg = o.signature;
  if (!sg) throw new UserError('Draw or type your signature first.');
  const doc = await loadPdf(items[0]);
  const png = await doc.embedPng(sg.bytes);
  const font = await doc.embedFont(StandardFonts.Helvetica);
  const pages = doc.getPages();
  const targets = o.where === 'first' ? [pages[0]] : o.where === 'all' ? pages : [pages[pages.length - 1]];
  const date = new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
  for (const p of targets) {
    const V = vis(p), w = V.W * (+o.width / 100), h = w * sg.h / sg.w, m = Math.min(V.W, V.H) * .06;
    const row = o.pos[0], col = o.pos[1], dateRoom = o.date ? 14 : 0;
    const u = col === 'l' ? m : col === 'c' ? (V.W - w) / 2 : V.W - m - w;
    const v = row === 't' ? V.H - m - h : row === 'm' ? (V.H - h) / 2 : m + dateRoom;
    let pt = V.map(u, v);
    p.drawImage(png, { x: pt.x, y: pt.y, width: w, height: h, rotate: degrees(V.r) });
    if (o.date) { pt = V.map(u + 2, v - 11); p.drawText(date, { x: pt.x, y: pt.y, size: 9, font, color: rgb(.3, .32, .45), rotate: degrees(V.r) }); }
  }
  ctx.progress(.9, 'Saving');
  return [pdfOut(baseName(items[0].name) + '-signed.pdf', await savePdf(doc), `Signed on ${targets.length} page${targets.length > 1 ? 's' : ''}`)];
};
P.watermark = async (items, o, ctx) => {
  const { degrees } = await lib('pdflib');
  const text = String(o.text || '').trim();
  if (!text) throw new UserError('Type the watermark text first.');
  const tp = await textPng(text, o.color);
  const outs = [];
  for (let f = 0; f < items.length; f++) {
    ctx.progress(f / items.length, `Stamping ${items[f].name}`);
    const doc = await loadPdf(items[f]);
    const img = await doc.embedPng(tp.bytes);
    const sc = +o.fsize / tp.px, w = tp.w * sc, h = tp.h * sc, th = (+o.angle) * Math.PI / 180, cos = Math.cos(th), sin = Math.sin(th);
    for (const p of doc.getPages()) {
      const V = vis(p);
      const centres = [];
      if (o.layout === 'tile') {
        const sx = Math.abs(w * cos) + Math.abs(h * sin) + 70, sy = Math.abs(w * sin) + Math.abs(h * cos) + 60;
        for (let r = 0, cy = sy / 2; cy < V.H + sy; cy += sy, r++) for (let cx = (r % 2 ? sx / 2 : 0); cx < V.W + sx; cx += sx) centres.push([cx, cy]);
      } else centres.push([V.W / 2, V.H / 2]);
      for (const [cx, cy] of centres) {
        const u = cx - (w / 2) * cos + (h / 2) * sin, v = cy - (w / 2) * sin - (h / 2) * cos;
        const pt = V.map(u, v);
        p.drawImage(img, { x: pt.x, y: pt.y, width: w, height: h, rotate: degrees(V.r + +o.angle), opacity: +o.opacity / 100 });
      }
    }
    outs.push(pdfOut(baseName(items[f].name) + '-watermarked.pdf', await savePdf(doc)));
  }
  return outs;
};
P.pagenum = async (items, o, ctx) => {
  const { StandardFonts, rgb, degrees } = await lib('pdflib');
  const outs = [];
  for (let f = 0; f < items.length; f++) {
    ctx.progress(f / items.length, `Numbering ${items[f].name}`);
    const doc = await loadPdf(items[f]);
    const font = await doc.embedFont(StandardFonts.Helvetica);
    const pages = doc.getPages(), skip = o.skipFirst ? 1 : 0, start = Math.floor(+o.start || 0), total = pages.length - skip + start - 1, size = +o.fsize;
    pages.forEach((p, i) => {
      if (i < skip) return;
      const n = i - skip + start;
      const label = { n: `${n}`, page: `Page ${n}`, of: `${n} of ${total}`, pageof: `Page ${n} of ${total}` }[o.fmt] || `${n}`;
      const V = vis(p), tw = font.widthOfTextAtSize(label, size), m = 26;
      const u = o.pos[1] === 'l' ? m : o.pos[1] === 'c' ? (V.W - tw) / 2 : V.W - m - tw;
      const v = o.pos[0] === 't' ? V.H - m - size * .72 : m;
      const pt = V.map(u, v);
      p.drawText(label, { x: pt.x, y: pt.y, size, font, color: rgb(.2, .21, .3), rotate: degrees(V.r) });
    });
    outs.push(pdfOut(baseName(items[f].name) + '-numbered.pdf', await savePdf(doc)));
  }
  return outs;
};
P.crop = async (items, o, ctx) => {
  const mm = 72 / 25.4, m = o.m || {};
  const [t, r, b, l] = ['top', 'right', 'bottom', 'left'].map(k => Math.max(0, +m[k] || 0) * mm);
  const outs = [];
  for (let f = 0; f < items.length; f++) {
    const doc = await loadPdf(items[f]);
    doc.getPages().forEach(p => {
      const rot = ((p.getRotation().angle % 360) + 360) % 360;
      const [L, R, T, B] = rot === 90 ? [t, b, r, l] : rot === 180 ? [r, l, b, t] : rot === 270 ? [b, t, l, r] : [l, r, t, b];
      const box = p.getCropBox(), nw = box.width - L - R, nh = box.height - T - B;
      if (nw < 20 || nh < 20) throw new UserError('Those margins are bigger than the page. Use smaller numbers.');
      p.setMediaBox(box.x + L, box.y + B, nw, nh);
      p.setCropBox(box.x + L, box.y + B, nw, nh);
    });
    ctx.progress(.9, 'Saving');
    outs.push(pdfOut(baseName(items[f].name) + '-cropped.pdf', await savePdf(doc)));
  }
  return outs;
};
P.compare = async (items, o, ctx) => {
  const [A, B] = items;
  const pa = await pdfLines(A.file, (f, l) => ctx.progress(f * .45, l), 'Reading the original,');
  const pb = await pdfLines(B.file, (f, l) => ctx.progress(.45 + f * .45, l), 'Reading the changed version,');
  const la = pa.flatMap((ls, i) => ls.map(l => ({ t: l.text, p: i + 1 }))), lb = pb.flatMap((ls, i) => ls.map(l => ({ t: l.text, p: i + 1 })));
  if (!la.length && !lb.length) throw new UserError('Neither file contains selectable text. Run OCR PDF on scans first.');
  ctx.progress(.92, 'Finding the differences');
  const norm = s => (o.ignoreCase ? s.toLowerCase() : s).replace(/\s+/g, ' ').trim();
  const ops = diffLines(la.map(x => norm(x.t)), lb.map(x => norm(x.t)));
  const rows = ops.map(([k, i, j]) => k === '=' ? { k: 'ctx', t: lb[j].t, p: lb[j].p } : k === '-' ? { k: 'del', t: la[i].t, p: la[i].p } : { k: 'add', t: lb[j].t, p: lb[j].p });
  const add = rows.filter(r => r.k === 'add').length, del = rows.filter(r => r.k === 'del').length;
  ctx.result = { diff: rows, add, del, a: A.name, b: B.name, title: add + del ? `${add + del} changed line${add + del > 1 ? 's' : ''} found` : 'No differences found' };
  const report = [`Fileora comparison`, `Original: ${A.name}`, `Changed:  ${B.name}`, `${add} lines added, ${del} lines removed`, '', ...rows.filter(r => r.k !== 'ctx').map(r => `${r.k === 'add' ? '+' : '-'} [p${r.p}] ${r.t}`)].join('\n');
  return [{ name: 'fileora-comparison.txt', blob: new Blob([report], { type: 'text/plain' }), note: `${add} added, ${del} removed` }];
};

/* images (FileoraImage comes from image-tools.js) */
function cropRect(w, h, o) {
  const ratio = { '1:1': 1, '4:5': 4 / 5, '4:3': 4 / 3, '3:2': 3 / 2, '16:9': 16 / 9 }[o.ratio] || w / h;
  let cw = w, ch = w / ratio;
  if (ch > h) { ch = h; cw = h * ratio; }
  const s = Math.max(.2, Math.min(1, (+o.size || 100) / 100));
  cw *= s; ch *= s;
  const col = (o.pos || 'mc')[1], row = (o.pos || 'mc')[0];
  return { x: Math.round(col === 'l' ? 0 : col === 'r' ? w - cw : (w - cw) / 2), y: Math.round(row === 't' ? 0 : row === 'b' ? h - ch : (h - ch) / 2), width: Math.round(cw), height: Math.round(ch) };
}
function imageNote(out, file) {
  if (out.note) return out.note;
  const dims = `${out.width} × ${out.height} px`;
  return out.blob.size < file.size ? `${dims}, ${Math.round((1 - out.blob.size / file.size) * 100)}% smaller (${fmtSize(file.size)} to ${fmtSize(out.blob.size)})` : `${dims}, ${fmtSize(out.blob.size)}`;
}
async function eachImage(items, ctx, fn) {
  const outs = [];
  for (let i = 0; i < items.length; i++) {
    ctx.progress(i / items.length, `Image ${i + 1} of ${items.length}`);
    const out = await fn(items[i].file);
    outs.push({ name: out.name, blob: out.blob, note: imageNote(out, items[i].file), good: out.blob.size < items[i].file.size });
  }
  return outs;
}
P.imgcompress = (items, o, ctx) => eachImage(items, ctx, f => FileoraImage.compress(f, { quality: +o.quality / 100, maxSide: +o.maxSide || 0, type: o.format === 'same' ? undefined : o.format }));
P.imgresize = (items, o, ctx) => eachImage(items, ctx, f => FileoraImage.resize(f, o.mode === 'pct' ? { percent: +o.percent } : { width: +o.width || undefined, height: +o.height || undefined }));
P.imgconvert = (items, o, ctx) => eachImage(items, ctx, f => FileoraImage.convert(f, o.to, { quality: +o.quality / 100 }));
P.jpg2png = (items, o, ctx) => eachImage(items, ctx, f => FileoraImage.convert(f, 'image/png'));
P.png2jpg = (items, o, ctx) => eachImage(items, ctx, f => FileoraImage.convert(f, 'image/jpeg', { quality: +o.quality / 100 }));
P.imgcrop = async (items, o, ctx) => {
  const it = items[0];
  const bmp = await createImageBitmap(it.file, { imageOrientation: 'from-image' }).catch(() => null);
  const w = bmp ? bmp.width : it.pw, h = bmp ? bmp.height : it.ph;
  if (bmp) bmp.close();
  if (!w || !h) throw new UserError(`${it.name} couldn’t be read as an image.`);
  return eachImage(items, ctx, f => FileoraImage.crop(f, cropRect(w, h, o)));
};

/* ---------------- server tools (job API) ---------------- */
const apiUrl = path => CONFIG.apiBase.replace(/\/$/, '') + path;
const apiHeaders = extra => Object.assign(CONFIG.nonce ? { 'X-WP-Nonce': CONFIG.nonce } : {}, extra || {});
function uploadForm(url, fd, onProgress) {
  return new Promise((resolve, reject) => {
    const x = new XMLHttpRequest();
    x.open('POST', url);
    Object.entries(apiHeaders()).forEach(([k, v]) => x.setRequestHeader(k, v));
    x.upload.onprogress = e => { if (e.lengthComputable) onProgress(e.loaded / e.total); };
    x.onload = () => { let body = {}; try { body = JSON.parse(x.responseText); } catch (e) { /* not JSON */ } resolve({ status: x.status, body }); };
    x.onerror = () => reject(new UserError('We couldn’t reach the Fileora server. Check your connection and try again.'));
    x.send(fd);
  });
}
async function serverRun(t, items, o, ctx) {
  if (!CONFIG.apiBase) throw new NoServer();
  const fd = new FormData();
  items.forEach(it => fd.append('files[]', it.file, it.name));
  const { signature, ...rest } = o;
  if (o.url) fd.append('url', /^https?:\/\//i.test(o.url) ? o.url : 'https://' + o.url);
  fd.append('options', JSON.stringify(rest));
  const up = await uploadForm(apiUrl('/jobs/' + t.id), fd, f => ctx.progress(f * .3, items.length ? `Uploading ${Math.round(f * 100)}%` : 'Sending'));
  if (up.status !== 202) throw new UserError(up.body.error || up.body.message || `The server couldn’t accept this request (error ${up.status}).`);
  const { job, token } = up.body;
  const headers = apiHeaders({ 'X-Fileora-Token': token || '' });
  const started = Date.now();
  let st = {}, wait = 800;
  for (;;) {
    await new Promise(r => setTimeout(r, wait));
    wait = Math.min(3000, wait + 300);
    if (ctx.alive && !ctx.alive()) throw new Error('cancelled');
    let r;
    try { r = await fetch(apiUrl('/jobs/' + job), { headers, cache: 'no-store' }); }
    catch (e) { continue; } /* brief network hiccup: keep polling */
    st = await r.json().catch(() => ({}));
    if (!r.ok) throw new UserError(st.error || 'We lost track of this task. Please run it again.');
    if (st.status === 'done') break;
    if (st.status === 'failed') throw new UserError(st.error || 'The server couldn’t process this file.');
    ctx.progress(.32 + Math.min(.55, (Date.now() - started) / 90000), st.status === 'queued' ? (st.ahead ? `Waiting in line, ${st.ahead} ahead of you` : 'Waiting in line') : `${t.verb} on the server`);
    if (Date.now() - started > 30 * 60000) throw new UserError('This is taking too long. Try a smaller file.');
  }
  if (st.kind === 'text') {
    ctx.result = { md: st.text, title: { summarize: 'Your summary is ready', translate: 'Your translation is ready' }[t.id] || null };
    return [{ name: st.name, blob: new Blob([st.text], { type: 'text/plain' }) }];
  }
  ctx.progress(.92, 'Downloading the result');
  const r = await fetch(apiUrl('/jobs/' + job + '/file'), { headers });
  if (!r.ok) throw new UserError('The result couldn’t be downloaded. Please run the task again.');
  return [{ name: st.name, blob: await r.blob() }];
}

/* ---------------- workflows ---------------- */
function defaults(tool) {
  const o = {};
  (tool.opts || []).forEach(f => { if (f.id && 'value' in f) o[f.id] = f.value && typeof f.value === 'object' ? { ...f.value } : f.value; });
  return o;
}
function wfTool(w) {
  const first = w.steps[0] && w.steps[0].tool;
  return { id: 'wf-' + w.id, name: w.name, cat: 'workflows', icon: 'workflow', client: true, accept: 'pdf', multi: true, min: first === 'merge' ? 2 : 1, ordered: first === 'merge', isWorkflow: true, wf: w,
    desc: w.desc || w.steps.map(s => TOOL[s.tool].name).join(', then '), cta: 'Run workflow', verb: 'Running the workflow',
    tip: first === 'merge' ? 'Add the files in the order they should be merged. Every step then runs in turn.' : 'Add your PDFs. Every step runs on each file in turn.', opts: [{ id: '_steps', type: 'steps', label: 'Steps' }] };
}
async function runWorkflow(w, items, ctx) {
  let cur = items, last = [];
  for (let s = 0; s < w.steps.length; s++) {
    const st = w.steps[s], t = TOOL[st.tool];
    const sub = { progress: (f, l) => ctx.progress((s + Math.max(0, f)) / w.steps.length, `Step ${s + 1} of ${w.steps.length}, ${t.name}${l ? ': ' + l : ''}`), pages: null };
    last = await P[t.id](cur, { ...defaults(t), ...st.o }, sub);
    cur = last.map(x => mkItem(new File([x.blob], x.name, { type: 'application/pdf' })));
  }
  return last;
}
function saveWfs() { store.set('workflows', userWfs); renderTabs(); renderCatalog(); }
function deleteWf(id) {
  const w = userWfs.find(x => x.id === id);
  if (!w || !confirm(`Delete the workflow “${w.name}”?`)) return;
  userWfs = userWfs.filter(x => x.id !== id);
  saveWfs(); toast('Workflow deleted', 'ok');
}
const WFB = { steps: [], open: -1 };
function openWfBuilder() {
  WFB.steps = []; WFB.open = -1;
  $('#wfName').value = '';
  renderWfb();
  openOv($('#wfModal'), { focus: '#wfName' });
}
function renderWfb() {
  const list = $('#wfSteps');
  list.innerHTML = WFB.steps.length ? WFB.steps.map((s, i) => { const t = TOOL[s.tool]; const hasOpts = t.opts.length; return `<li class="wfb-step" data-i="${i}">
      <div class="wfb-row"><span class="n"></span><span class="tile sm c-${t.cat}">${icon(t.icon)}</span><b>${esc(t.name)}</b>
      ${hasOpts ? `<button class="btn btn-quiet btn-sm" data-wfb="opts" aria-expanded="${WFB.open === i}">Settings</button>` : ''}
      <button class="icon-btn sm" data-wfb="up" aria-label="Move up" ${i === 0 || (i === 1 && WFB.steps[0].tool === 'merge') ? 'disabled' : ''}>${icon('chev-down', 'ic ic-sm" style="transform:rotate(180deg)')}</button>
      <button class="icon-btn sm" data-wfb="down" aria-label="Move down" ${i === WFB.steps.length - 1 || s.tool === 'merge' ? 'disabled' : ''}>${icon('chev-down', 'ic ic-sm')}</button>
      <button class="icon-btn sm" data-wfb="del" aria-label="Remove step">${icon('trash', 'ic ic-sm')}</button></div>
      ${hasOpts && WFB.open === i ? '<div class="wfb-opts"></div>' : ''}</li>`; }).join('')
    : '<li class="wfb-empty">No steps yet. Add the first one below.</li>';
  if (WFB.open >= 0 && WFB.steps[WFB.open]) {
    const s = WFB.steps[WFB.open], box = $(`.wfb-step[data-i="${WFB.open}"] .wfb-opts`);
    if (box) renderOpts(box, TOOL[s.tool].opts.filter(f => f.type !== 'signature'), s.o);
  }
  const avail = WF_STEPS.filter(id => id !== 'merge' || !WFB.steps.length);
  $('#wfAdd').innerHTML = avail.map(id => { const t = TOOL[id]; return `<button class="chip c-${t.cat}" data-wfadd="${id}">${icon(t.icon)}${esc(t.name)}</button>`; }).join('');
}

/* ---------------- options renderer ---------------- */
let optUid = 0;
const POS_LABEL = { tl: 'Top left', tc: 'Top centre', tr: 'Top right', ml: 'Middle left', mc: 'Centre', mr: 'Middle right', bl: 'Bottom left', bc: 'Bottom centre', br: 'Bottom right' };
function optHtml(f, v, uid) {
  const id = uid + '-' + f.id;
  const lab = f.label && f.type !== 'toggle' ? `<${['text', 'password', 'textarea', 'select', 'number', 'range'].includes(f.type) ? `label for="${id}"` : 'span'} class="opt-l">${esc(f.label)}</${['text', 'password', 'textarea', 'select', 'number', 'range'].includes(f.type) ? 'label' : 'span'}>` : '';
  switch (f.type) {
    case 'seg': return lab + `<div class="seg${f.choices.length > 3 ? ' wrapit' : ''}" role="group" aria-label="${esc(f.label)}">${f.choices.map(([val, l]) => `<button type="button" data-val="${esc(val)}" aria-pressed="${String(v) === String(val)}">${esc(l)}</button>`).join('')}</div>`;
    case 'select': return lab + `<select class="sel" id="${id}">${f.choices.map(([val, l]) => `<option value="${esc(val)}"${String(v) === String(val) ? ' selected' : ''}>${esc(l)}</option>`).join('')}</select>`;
    case 'text': case 'password': return lab + `<input class="inp" id="${id}" type="${f.type}" value="${esc(v || '')}" placeholder="${esc(f.placeholder || '')}" autocomplete="${f.type === 'password' ? 'new-password' : 'off'}" spellcheck="false">`;
    case 'textarea': return lab + `<textarea class="ta" id="${id}" placeholder="${esc(f.placeholder || '')}">${esc(v || '')}</textarea>`;
    case 'number': return lab + `<div class="num"><input class="inp" id="${id}" type="number" inputmode="numeric" value="${esc(v)}" min="${f.min ?? ''}" max="${f.max ?? ''}">${f.suffix ? `<span>${esc(f.suffix)}</span>` : ''}</div>`;
    case 'range': return lab + `<div class="rng"><input id="${id}" type="range" min="${f.min}" max="${f.max}" step="${f.step || 1}" value="${esc(v)}"><output>${esc(v)}${esc(f.suffix || '')}</output></div>`;
    case 'toggle': return `<label class="sw"><span>${esc(f.label)}</span><input type="checkbox"${v ? ' checked' : ''}></label>`;
    case 'color': return lab + `<div class="swatches" role="group" aria-label="${esc(f.label)}">${f.choices.map(c => `<button type="button" data-val="${c}" style="background:${c}" aria-pressed="${c === v}" aria-label="Colour ${c}"></button>`).join('')}</div>`;
    case 'pos': { const cells = f.cells || ['tl', 'tc', 'tr', 'ml', 'mc', 'mr', 'bl', 'bc', 'br']; return lab + `<div class="posgrid" role="group" aria-label="${esc(f.label)}">${cells.map(c => `<button type="button" data-val="${c}" aria-pressed="${c === v}" aria-label="${POS_LABEL[c]}" title="${POS_LABEL[c]}"><i></i></button>`).join('')}</div>`; }
    case 'margins': return lab + `<div class="margins">${['top', 'right', 'bottom', 'left'].map(s => `<label>${s[0].toUpperCase() + s.slice(1)}<input class="inp" type="number" min="0" max="300" inputmode="decimal" data-side="${s}" value="${esc(v[s])}"></label>`).join('')}</div>`;
    case 'signature': return lab + `<div class="seg sig-tabs" role="group" aria-label="Signature type"><button type="button" data-sigmode="draw" aria-pressed="true">Draw</button><button type="button" data-sigmode="type" aria-pressed="false">Type</button></div>
      <div class="sig-draw"><div class="sig-pad"><canvas aria-label="Signature pad. Draw your signature with a mouse, finger or stylus."></canvas><div class="hintline"></div><span class="ph">Sign above the line</span></div></div>
      <div class="sig-typewrap" hidden><input class="inp sig-type" type="text" placeholder="Type your name" aria-label="Type your name" maxlength="40"></div>
      <div class="sig-row"><div class="swatches" role="group" aria-label="Ink colour"><button type="button" data-ink="#16182F" style="background:#16182F" aria-pressed="true" aria-label="Black ink"></button><button type="button" data-ink="#2337B8" style="background:#2337B8" aria-pressed="false" aria-label="Blue ink"></button></div><button type="button" class="btn btn-quiet btn-sm" data-sigclear>Clear</button></div>`;
    case 'steps': return lab + `<ol class="wf-steps-mini">${WS.tool.wf.steps.map((s, i) => `<li><span>${i + 1}</span><span class="tile sm c-${TOOL[s.tool].cat}">${icon(TOOL[s.tool].icon)}</span>${esc(TOOL[s.tool].name)}</li>`).join('')}</ol>`;
    default: return '';
  }
}
function renderOpts(box, fields, vals, onChange) {
  const uid = 'o' + (++optUid);
  box.innerHTML = fields.map(f => `<div class="opt" data-f="${f.id}">${optHtml(f, vals[f.id], uid)}${f.help ? '<p class="opt-help"></p>' : ''}</div>`).join('');
  const refresh = () => fields.forEach(f => {
    const w = box.querySelector(`.opt[data-f="${f.id}"]`); if (!w) return;
    if (f.show) w.hidden = !f.show(vals);
    const h = w.querySelector('.opt-help'); if (h) h.textContent = typeof f.help === 'function' ? f.help(vals) : f.help;
  });
  fields.forEach(f => {
    const w = box.querySelector(`.opt[data-f="${f.id}"]`); if (!w) return;
    const set = v => { vals[f.id] = v; refresh(); onChange && onChange(f.id, v); };
    switch (f.type) {
      case 'seg': case 'color': case 'pos':
        w.addEventListener('click', e => { const b = e.target.closest('[data-val]'); if (!b) return; $$('[data-val]', w).forEach(x => x.setAttribute('aria-pressed', x === b)); set(b.dataset.val); }); break;
      case 'select': w.querySelector('select').addEventListener('change', e => set(e.target.value)); break;
      case 'text': case 'password': case 'textarea': w.querySelector('input,textarea').addEventListener('input', e => set(e.target.value)); break;
      case 'number': w.querySelector('input').addEventListener('input', e => { const n = parseFloat(e.target.value); if (!isNaN(n)) set(Math.min(f.max ?? Infinity, Math.max(f.min ?? -Infinity, n))); }); break;
      case 'range': { const inp = w.querySelector('input'), out = w.querySelector('output'); inp.addEventListener('input', () => { out.textContent = inp.value + (f.suffix || ''); set(+inp.value); }); break; }
      case 'toggle': w.querySelector('input').addEventListener('change', e => set(e.target.checked)); break;
      case 'margins': w.addEventListener('input', e => { const s = e.target.dataset.side; if (!s) return; set({ ...vals[f.id], [s]: Math.max(0, parseFloat(e.target.value) || 0) }); }); break;
      case 'signature': initSignature(w, set); break;
    }
  });
  refresh();
}
function initSignature(w, set) {
  const cv = $('canvas', w), pad = $('.sig-pad', w), ph = $('.ph', w), typeIn = $('.sig-type', w);
  let mode = 'draw', ink = '#16182F', strokes = [], cur = null, dpr = 1;
  const g = cv.getContext('2d');
  const size = () => { dpr = Math.min(2, devicePixelRatio || 1); const r = pad.getBoundingClientRect(); if (!r.width) return; cv.width = r.width * dpr; cv.height = r.height * dpr; redraw(); };
  const redraw = () => {
    g.clearRect(0, 0, cv.width, cv.height); g.lineCap = g.lineJoin = 'round'; g.strokeStyle = ink; g.lineWidth = 2.6 * dpr;
    for (const s of strokes) { g.beginPath(); s.forEach((p, i) => { if (!i) g.moveTo(p[0] * dpr, p[1] * dpr); else { const q = s[i - 1]; g.quadraticCurveTo(q[0] * dpr, q[1] * dpr, (p[0] + q[0]) / 2 * dpr, (p[1] + q[1]) / 2 * dpr); } }); if (s.length === 1) g.lineTo(s[0][0] * dpr + .1, s[0][1] * dpr); g.stroke(); }
    ph.hidden = strokes.length > 0;
  };
  const exportDraw = async () => {
    if (!strokes.length) return set(null);
    const pts = strokes.flat(), pd = 6;
    const x0 = Math.max(0, Math.min(...pts.map(p => p[0])) - pd), y0 = Math.max(0, Math.min(...pts.map(p => p[1])) - pd);
    const x1 = Math.max(...pts.map(p => p[0])) + pd, y1 = Math.max(...pts.map(p => p[1])) + pd;
    const sc = 3, c = document.createElement('canvas'); c.width = Math.ceil((x1 - x0) * sc); c.height = Math.ceil((y1 - y0) * sc);
    const k = c.getContext('2d'); k.lineCap = k.lineJoin = 'round'; k.strokeStyle = ink; k.lineWidth = 2.6 * sc;
    for (const s of strokes) { k.beginPath(); s.forEach((p, i) => { const X = (p[0] - x0) * sc, Y = (p[1] - y0) * sc; if (!i) k.moveTo(X, Y); else { const q = s[i - 1]; k.quadraticCurveTo((q[0] - x0) * sc, (q[1] - y0) * sc, ((p[0] + q[0]) / 2 - x0) * sc, ((p[1] + q[1]) / 2 - y0) * sc); } }); if (s.length === 1) k.lineTo((s[0][0] - x0) * sc + .1, (s[0][1] - y0) * sc); k.stroke(); }
    set({ bytes: await (await canvasToBlob(c, 'image/png')).arrayBuffer(), w: c.width, h: c.height });
  };
  const exportType = async () => {
    const t = typeIn.value.trim(); if (!t) return set(null);
    try { await document.fonts.load('600 110px Caveat'); } catch (e) { /* fallback */ }
    const c = document.createElement('canvas'), k = c.getContext('2d'), font = "600 110px Caveat, 'Segoe Script', 'Brush Script MT', cursive";
    k.font = font; const tw = k.measureText(t).width; c.width = Math.ceil(tw + 40); c.height = 150;
    k.font = font; k.fillStyle = ink; k.textBaseline = 'middle'; k.fillText(t, 20, 78);
    set({ bytes: await (await canvasToBlob(c, 'image/png')).arrayBuffer(), w: c.width, h: c.height });
  };
  const pos = e => { const r = cv.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
  cv.addEventListener('pointerdown', e => { e.preventDefault(); cv.setPointerCapture(e.pointerId); cur = [pos(e)]; strokes.push(cur); redraw(); });
  cv.addEventListener('pointermove', e => { if (!cur) return; const p = pos(e), q = cur[cur.length - 1]; if (Math.hypot(p[0] - q[0], p[1] - q[1]) > 1.2) { cur.push(p); redraw(); } });
  const end = () => { if (cur) { cur = null; exportDraw(); } };
  cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end);
  typeIn.addEventListener('input', exportType);
  w.addEventListener('click', e => {
    const m = e.target.closest('[data-sigmode]');
    if (m) { mode = m.dataset.sigmode; $$('[data-sigmode]', w).forEach(b => b.setAttribute('aria-pressed', b === m)); $('.sig-draw', w).hidden = mode !== 'draw'; $('.sig-typewrap', w).hidden = mode !== 'type'; if (mode === 'draw') { size(); exportDraw(); } else { typeIn.focus(); exportType(); } }
    const i = e.target.closest('[data-ink]');
    if (i) { ink = i.dataset.ink; $$('[data-ink]', w).forEach(b => b.setAttribute('aria-pressed', b === i)); typeIn.style.color = ink; redraw(); mode === 'draw' ? exportDraw() : exportType(); }
    if (e.target.closest('[data-sigclear]')) { strokes = []; typeIn.value = ''; redraw(); set(null); }
  });
  new ResizeObserver(size).observe(pad);
}

/* ---------------- workspace ---------------- */
const WS = { tool: null, items: [], pages: null, opts: {}, phase: 'empty', outputs: [], result: null, error: '', urls: [], seq: 0, queue: Promise.resolve(), sigUrl: null };
let itemSeq = 0;
const mkItem = file => ({ id: 'f' + (++itemSeq), file, name: file.name, size: file.size, kind: kindOf(file), pages: null, thumb: null, err: null, note: '' });
function kindOf(f) {
  const e = extOf(f.name);
  for (const [k, a] of Object.entries(ACCEPT)) if (a.ext.includes(e)) return k;
  if (f.type === 'application/pdf') return 'pdf';
  if (/^image\//.test(f.type)) return 'image';
  return 'other';
}
const isOrdered = t => t.ordered || ['merge', 'jpg2pdf', 'scan', 'compare'].includes(t.id);
const goodItems = () => WS.items.filter(i => !i.err);
function clearOutputs() { WS.outputs.forEach(o => URL.revokeObjectURL(o.url)); WS.outputs = []; WS.result = null; }
function clearItems() { WS.items = []; WS.pages = null; WS.allPages = null; WS.seq++; WS.queue = Promise.resolve(); clearOutputs(); }
function resetWS() { clearItems(); WS.urls.forEach(u => URL.revokeObjectURL(u)); WS.urls = []; WS.tool = null; WS.error = ''; if (WS.sigUrl) URL.revokeObjectURL(WS.sigUrl); WS.sigUrl = null; }

function openTool(idOrTool, files, fromRoute) {
  const t = typeof idOrTool === 'string' ? TOOL[idOrTool] : idOrTool;
  if (!t) return;
  closeMega();
  ['#palette', '#suggest', '#drawer', '#wfModal'].forEach(s => { const el = $(s); if (!el.hidden) closeOv(el); });
  resetWS();
  WS.tool = t; WS.opts = defaults(t);
  if (!fromRoute) setHash(t.isWorkflow ? '#wf/' + t.wf.id : '#tool/' + t.id);
  const panel = $('#ws .ws-panel');
  panel.dataset.cat = t.cat;
  $('#wsTile').className = tileCls(t);
  $('#wsTile').innerHTML = icon(t.icon);
  $('#wsTitle').textContent = t.name;
  $('#wsCat').textContent = CAT[t.cat].name;
  const priv = $('#wsPriv');
  priv.className = 'priv' + (t.client ? '' : ' srv');
  priv.innerHTML = t.client ? `${icon('device')}<span>Runs in your browser</span>` : `${icon('shield')}<span>Encrypted server processing</span>`;
  priv.title = t.client ? 'Your files never leave this device' : 'Files are sent over HTTPS and deleted within 2 hours';
  $('#wsSteps li[data-step="1"]').innerHTML = `<i>1</i>${t.accept === 'url' ? 'Enter address' : 'Add files'}`;
  renderOptsPanel();
  if ($('#ws').hidden) openOv($('#ws'), { focus: '.ws-panel' });
  else $('#wsMain').scrollTop = 0;
  setPhase('empty');
  if (!t.isWorkflow) pushRecent(t.id);
  document.title = `${t.name} | Fileora`;
  if (files && files.length) addFiles(files);
}
function closeTool(fromRoute) {
  if ($('#ws').hidden) return;
  closeOv($('#ws'));
  resetWS();
  document.title = 'Fileora: free PDF tools to merge, split, compress, convert and sign';
  if (!fromRoute) setHash('');
}
function renderOptsPanel() {
  const t = WS.tool;
  $('#wsOptsWrap h3').textContent = t.opts.length ? 'Options' : 'About this tool';
  $('#wsAbout').textContent = t.tip || t.desc;
  if (!t.opts.length) { $('#wsOpts').innerHTML = `<div class="note-box">${icon('info')}<span>No settings needed. Add your files and press “${esc(t.cta)}”.</span></div>`; return; }
  renderOpts($('#wsOpts'), t.opts, WS.opts, onOptChange);
}
function onOptChange(id) {
  updateCta();
  if (id === 'signature') { if (WS.sigUrl) URL.revokeObjectURL(WS.sigUrl); WS.sigUrl = WS.opts.signature ? URL.createObjectURL(new Blob([WS.opts.signature.bytes], { type: 'image/png' })) : null; }
  if (['watermark', 'pagenum', 'sign', 'crop', 'imgcrop'].includes(WS.tool.id)) refreshOverlays();
  if (WS.tool.id === 'rotate') rotatePreview();
}
function rotatePreview() {
  const g = $('#fileGrid'); if (!g || WS.tool.id !== 'rotate') return;
  const a = +WS.opts.angle;
  g.style.setProperty('--rot', a + 'deg'); g.style.setProperty('--rs', a % 180 ? .74 : 1);
}
function setPhase(p) { WS.phase = p; $('#ws .ws-panel').classList.toggle('is-done', p === 'done'); renderMain(); updateSteps(); updateCta(); }
function updateSteps() {
  const st = { empty: 1, ready: 2, working: 3, done: 4, error: 2, server: 2 }[WS.phase] || 1;
  $$('#wsSteps li[data-step]').forEach(li => { const n = +li.dataset.step; li.className = n < st ? 'done' : n === st ? 'on' : ''; });
}
function isUrl(v) { try { const u = new URL(/^https?:\/\//i.test(v) ? v : 'https://' + v); return /\./.test(u.hostname); } catch (e) { return false; } }
function updateCta() {
  const t = WS.tool, btn = $('#wsRun'), hint = $('#wsHint');
  if (!t) return;
  const acc = ACCEPT[t.accept];
  let ok = false, h = '';
  if (WS.phase === 'working') { btn.disabled = true; btn.textContent = t.verb + '…'; hint.textContent = 'Keep this window open until it finishes.'; return; }
  if (t.accept === 'url') { ok = isUrl(WS.opts.url || ''); h = ok ? '' : 'Enter a web address to continue.'; }
  else {
    const n = goodItems().length;
    ok = n >= t.min && (!t.pages || (WS.pages && WS.pages.length));
    if (!n) h = t.min > 1 ? `Add at least ${t.min} ${acc.nouns} to start.` : `Add ${t.multi ? acc.nouns : 'a ' + acc.noun} to start.`;
    else if (n < t.min) h = `Add ${t.min - n} more ${t.min - n === 1 ? acc.noun : acc.nouns}.`;
    else if (t.pages && !WS.pages) h = 'Loading pages…';
    else if (t.pages && !WS.pages.length) h = 'Keep at least one page.';
  }
  if (ok && t.validate) { const v = t.validate(WS.opts, WS.items); if (v) h = v; }
  const done = WS.phase === 'done';
  btn.disabled = !ok;
  btn.className = 'btn btn-lg ' + (done ? 'btn-line' : 'btn-ink');
  btn.textContent = done ? 'Run again' : t.cta;
  hint.textContent = h || (done ? (t.opts.length ? 'Change an option above, then run again.' : 'Runs the tool again on the same files.') : t.client ? 'Processed on your device.' : '');
}
function setProgress(f, label) {
  const bar = $('#wsMain .pbar'); if (!bar) return;
  bar.classList.toggle('indet', f < 0);
  if (f >= 0) bar.firstElementChild.style.width = Math.round(Math.min(1, f) * 100) + '%';
  if (label) $('#wsMain .plabel').textContent = label;
}

/* main area renderers */
function thumbHtml(it) {
  const ext = (extOf(it.name) || 'file').toUpperCase().slice(0, 4);
  const cat = it.kind === 'pdf' ? 'from' : it.kind === 'image' ? 'to' : it.kind === 'word' || it.kind === 'html' ? 'organize' : it.kind === 'excel' ? 'optimize' : 'to';
  const tag = `<span class="ext" style="--c:var(--c-${cat})">${esc(ext)}</span>`;
  if (!it.thumb) return icon(it.kind === 'image' ? 'image' : 'file') + tag;
  if ((it.kind === 'pdf' || WS.tool.id === 'imgcrop') && it.pw) {
    const r = it.pw / it.ph, c = .75;
    const sz = !WS.tool.multi ? '' : r < c ? `height:100%;width:${r / c * 100}%` : `width:100%;height:${c / r * 100}%`;
    return `<div class="pg" style="${sz}"><img src="${it.thumb}" alt=""><div class="ovl">${overlayHtml(it)}</div></div>${tag}`;
  }
  return `<img src="${it.thumb}" alt="">${tag}`;
}
/* live previews drawn over the first page */
let measureCtx;
function textWidth(text, size) { measureCtx = measureCtx || document.createElement('canvas').getContext('2d'); measureCtx.font = `700 ${size}px Geist, 'Helvetica Neue', Arial, sans-serif`; return measureCtx.measureText(text).width; }
function overlayHtml(it) {
  const t = WS.tool, o = WS.opts, W = it.pw, H = it.ph;
  if (!t || !W) return '';
  const pc = (v, d) => (v / d * 100).toFixed(3) + '%';
  if (t.id === 'watermark') {
    const text = String(o.text || '').trim(); if (!text) return '';
    const fs = +o.fsize, w = textWidth(text, fs) + fs * .24, h = fs * 1.32, th = (+o.angle) * Math.PI / 180, cos = Math.cos(th), sin = Math.sin(th);
    const centres = [];
    if (o.layout === 'tile') {
      const sx = Math.abs(w * cos) + Math.abs(h * sin) + 70, sy = Math.abs(w * sin) + Math.abs(h * cos) + 60;
      for (let r = 0, cy = sy / 2; cy < H + sy && centres.length < 80; cy += sy, r++) for (let cx = (r % 2 ? sx / 2 : 0); cx < W + sx; cx += sx) centres.push([cx, cy]);
    } else centres.push([W / 2, H / 2]);
    return centres.map(([cx, cy]) => `<span class="wm" style="left:${pc(cx, W)};top:${pc(H - cy, H)};font-size:${(fs / W * 100).toFixed(3)}cqw;color:${o.color};opacity:${+o.opacity / 100};transform:translate(-50%,-50%) rotate(${-o.angle}deg)">${esc(text)}</span>`).join('');
  }
  if (t.id === 'pagenum') {
    if (o.skipFirst) return '';
    const n = Math.floor(+o.start || 0), total = (it.pages || 1) + n - 1, size = +o.fsize, m = 26;
    const label = { n: `${n}`, page: `Page ${n}`, of: `${n} of ${total}`, pageof: `Page ${n} of ${total}` }[o.fmt] || `${n}`;
    const v = o.pos[0] === 't' ? `top:${pc(m, H)}` : `bottom:${pc(m, H)}`;
    const u = o.pos[1] === 'l' ? `left:${pc(m, W)}` : o.pos[1] === 'r' ? `right:${pc(m, W)}` : 'left:50%;transform:translateX(-50%)';
    return `<span class="pn" style="${v};${u};font-size:${(size / W * 100).toFixed(3)}cqw">${esc(label)}</span>`;
  }
  if (t.id === 'imgcrop') {
    const r = cropRect(W, H, o);
    return `<div class="cr" style="left:${pc(r.x, W)};top:${pc(r.y, H)};right:${pc(W - r.x - r.width, W)};bottom:${pc(H - r.y - r.height, H)}"></div>`;
  }
  if (t.id === 'crop') {
    const mm = 72 / 25.4, m = o.m || {}, cl = k => Math.min(49, (+m[k] || 0) * mm / (k === 'left' || k === 'right' ? W : H) * 100);
    return `<div class="cr" style="left:${cl('left')}%;right:${cl('right')}%;top:${cl('top')}%;bottom:${cl('bottom')}%"></div>`;
  }
  if (t.id === 'sign') {
    const sg = o.signature, ratio = sg ? sg.h / sg.w : .36, w = W * (+o.width / 100), h = w * ratio, m = Math.min(W, H) * .06;
    const row = o.pos[0], col = o.pos[1], dateRoom = o.date ? 14 : 0;
    const u = col === 'l' ? m : col === 'c' ? (W - w) / 2 : W - m - w;
    const v = row === 't' ? H - m - h : row === 'm' ? (H - h) / 2 : m + dateRoom;
    return `<div class="sgb" style="left:${pc(u, W)};bottom:${pc(v, H)};width:${pc(w, W)};height:${pc(h, H)}">${sg && WS.sigUrl ? `<img src="${WS.sigUrl}" alt="">` : '<span>Signature</span>'}</div>`;
  }
  return '';
}
function refreshOverlays() {
  WS.items.forEach(it => { const el = $(`#wsMain [data-iid="${it.id}"] .ovl`); if (el) el.innerHTML = overlayHtml(it); });
}
function metaText(it) { return it.err || [fmtSize(it.size), it.pages ? `${it.pages} page${it.pages > 1 ? 's' : ''}` : '', it.note].filter(Boolean).join(', '); }
function fileCard(it, i, ordered) {
  const label = WS.tool.id === 'compare' ? `<div class="slot-label">${i === 0 ? 'Original' : 'Changed version'}</div>` : '';
  return `<div class="file" data-iid="${it.id}"${ordered ? ' draggable="true"' : ''}>${label}
    ${ordered && WS.tool.id !== 'compare' ? `<span class="ord">${i + 1}</span>` : ''}
    <button class="file-x" data-remove="${it.id}" aria-label="Remove ${esc(it.name)}">${icon('x')}</button>
    <div class="thumb"${it.pw && !WS.tool.multi ? ` style="--ar:${it.pw / it.ph}"` : ''}>${thumbHtml(it)}</div>
    <div class="file-name" title="${esc(it.name)}">${esc(it.name)}</div>
    <div class="file-meta${it.err ? ' err' : ''}">${esc(metaText(it))}</div>
    ${ordered ? `<div class="file-acts"><button data-move="-1" ${i === 0 ? 'disabled' : ''} aria-label="Move ${esc(it.name)} earlier">${icon('chev-left')}</button><button data-move="1" ${i === WS.items.length - 1 ? 'disabled' : ''} aria-label="Move ${esc(it.name)} later">${icon('chev-right')}</button></div>` : ''}
  </div>`;
}
const rotStyle = r => `transform:rotate(${r}deg) scale(${r % 180 ? .74 : 1})`;
function pageCard(p, k) {
  return `<div class="file" data-pkey="${p.key}" draggable="true">
    <span class="ord">${k + 1}</span>
    <div class="thumb">${p.thumb ? `<img src="${p.thumb}" alt="" style="${rotStyle(p.rot)}">` : icon('file')}</div>
    <div class="file-name">Page ${p.i + 1}${p.rot ? `, turned ${p.rot}°` : ''}</div>
    <div class="file-acts"><button data-pmove="-1" ${k === 0 ? 'disabled' : ''} aria-label="Move page ${p.i + 1} earlier">${icon('chev-left')}</button><button data-prot aria-label="Rotate page ${p.i + 1}">${icon('rotate-cw')}</button><button data-pdel aria-label="Delete page ${p.i + 1}">${icon('trash')}</button><button data-pmove="1" ${k === WS.pages.length - 1 ? 'disabled' : ''} aria-label="Move page ${p.i + 1} later">${icon('chev-right')}</button></div>
  </div>`;
}
function renderMain() {
  const t = WS.tool, m = $('#wsMain'); if (!t) return;
  const acc = ACCEPT[t.accept];
  const tile = `<span class="${tileCls(t)} lg">${icon(t.icon)}</span>`;
  if (WS.phase === 'empty' && t.accept === 'url') {
    m.innerHTML = `<div class="dz">${tile}<h3>Which page should we save?</h3><p>${esc(t.desc)}</p>
      <form class="url-form" id="urlForm"><label class="opt-l" for="urlInp">Web address</label><input class="inp" id="urlInp" type="url" inputmode="url" autocomplete="url" placeholder="https://example.com/article" value="${esc(WS.opts.url || '')}"><small>We open the page on our server and save it exactly as it looks.</small></form></div>`;
    $('#urlInp').addEventListener('input', e => { WS.opts.url = e.target.value.trim(); updateCta(); });
    $('#urlForm').addEventListener('submit', e => { e.preventDefault(); if (!$('#wsRun').disabled) runTool(); });
  } else if (WS.phase === 'empty') {
    const what = t.id === 'compare' ? 'two PDF files' : t.multi ? acc.nouns : 'a ' + acc.noun;
    m.innerHTML = `<div class="dz" id="dz">${tile}<h3>Drop ${what} here</h3><p>${esc(t.desc)}</p>
      <div class="dz-actions"><button class="btn btn-ink btn-lg" data-pick>${icon('upload')}Choose ${t.multi ? acc.nouns : acc.noun}</button>${t.camera ? `<button class="btn btn-line btn-lg" data-cam>${icon('camera')}Take a photo</button>` : ''}</div>
      <small>${t.client ? 'Processed on your device. Nothing is uploaded.' : `Up to ${CONFIG.maxFileMB} MB per file. Encrypted, and deleted from our servers within 2 hours.`}</small></div>`;
  } else if (WS.phase === 'ready') {
    if (t.pages) {
      const it = WS.items[0];
      m.innerHTML = `<div class="files-head"><h3>${esc(it.name)} <span>${WS.pages ? `${WS.pages.length} of ${it.pages} pages kept` : ''}</span></h3>
        <button class="btn btn-quiet btn-sm" data-preset>${icon('rotate-ccw', 'ic ic-sm')}Reset pages</button><button class="btn btn-line btn-sm" data-pick>Change file</button></div>
        ${WS.pages ? `<div class="files" id="fileGrid">${WS.pages.map(pageCard).join('')}</div>` : `<div class="files" id="fileGrid">${fileCard(it, 0, false)}</div><p class="plabel">${it.err ? '' : 'Loading pages…'}</p>`}`;
    } else {
      const ordered = isOrdered(t), n = WS.items.length, total = WS.items.reduce((s, i) => s + i.size, 0);
      const canAdd = t.multi && (!t.max || n < t.max);
      m.innerHTML = `<div class="files-head"><h3>${n} ${n === 1 ? acc.noun : acc.nouns} <span>(${fmtSize(total)})</span></h3>
        ${ordered && n > 1 && t.id !== 'compare' ? `<button class="btn btn-quiet btn-sm" data-sort>${icon('sort', 'ic ic-sm')}Sort A to Z</button>` : ''}
        ${t.id === 'compare' && n === 2 ? `<button class="btn btn-quiet btn-sm" data-swap>${icon('rotate-cw', 'ic ic-sm')}Swap order</button>` : ''}
        ${canAdd ? `<button class="btn btn-line btn-sm" data-pick>${icon('plus', 'ic ic-sm')}Add more</button>` : !t.multi ? `<button class="btn btn-line btn-sm" data-pick>Change file</button>` : ''}
        <button class="btn btn-quiet btn-sm" data-clear>${t.multi ? 'Remove all' : 'Remove'}</button></div>
        <div class="files${t.multi ? '' : ' single'}" id="fileGrid">${WS.items.map((it, i) => fileCard(it, i, ordered)).join('')}
        ${canAdd ? `<button class="add-tile" data-pick>${icon('plus', 'ic ic-lg')}${t.id === 'compare' ? 'Add the changed version' : 'Add more files'}</button>` : ''}</div>
        ${t.camera ? `<p style="margin-top:14px"><button class="btn btn-line btn-sm" data-cam>${icon('camera', 'ic ic-sm')}Take another photo</button></p>` : ''}`;
      rotatePreview();
    }
  } else if (WS.phase === 'working') {
    m.innerHTML = `<div class="state">${tile}<h3>${esc(t.verb)}…</h3><p>${t.client ? 'This happens on your device, so it depends on its speed.' : 'Your files are processed securely, then deleted.'}</p><div class="pbar"><i></i></div><p class="plabel">Getting ready</p></div>`;
  } else if (WS.phase === 'done') {
    m.innerHTML = resultHtml();
  } else if (WS.phase === 'error') {
    m.innerHTML = `<div class="state"><span class="ok-mark err-mark">${icon('alert')}</span><h3>That didn’t work</h3><p>${esc(WS.error)}</p>
      <div class="res-actions"><button class="btn btn-ink" data-retry>Try again</button><button class="btn btn-line" data-again>Choose other files</button>${t.id !== 'repair' && TOOL.repair && t.accept === 'pdf' ? `<button class="btn btn-quiet" data-next="repair">Repair the PDF</button>` : ''}</div></div>`;
  } else if (WS.phase === 'server') {
    const alts = TOOLS.filter(x => x.client && x.accept === (t.accept === 'url' ? 'pdf' : t.accept)).slice(0, 6);
    m.innerHTML = `<div class="state"><span class="tile lg c-organize">${icon('server')}</span><h3>${esc(t.name)} needs the Fileora server</h3>
      <p>This tool runs on a processing server, and this copy of Fileora isn’t connected to one yet. Nothing was uploaded.</p>
      ${alts.length ? `<div class="next"><h4>These tools work right now, in your browser</h4><div>${alts.map(x => `<a class="chip c-${x.cat}" ${toolLink(x)}>${icon(x.icon)}${esc(x.name)}</a>`).join('')}</div></div>` : ''}
      <div class="res-actions"><button class="btn btn-line" data-retry>Back to my files</button></div></div>`;
  }
}
function resultHtml() {
  const t = WS.tool, outs = WS.outputs, r = WS.result || {};
  const title = r.title || (outs.length > 1 ? `${outs.length} files are ready` : t.id === 'pdf2md' ? 'Your Markdown is ready' : 'Your file is ready');
  const isPdf = o => /\.pdf$/i.test(o.name);
  const isImg = o => /\.(jpe?g|png|webp)$/i.test(o.name);
  const iconFor = o => /\.pdf$/i.test(o.name) ? ['file', 'from'] : isImg(o) ? ['image', 'image'] : /\.md$/i.test(o.name) ? ['markdown', 'from'] : ['file', 'organize'];
  const rows = outs.length > 1 || r.diff || r.md ? `<div class="outs">${outs.slice(0, 60).map(o => { const [ic, c] = iconFor(o); return `<div class="out"><span class="tile sm c-${c}">${icon(ic)}</span><div><b>${esc(o.name)}</b><small class="${o.good ? 'good' : ''}">${esc(o.note || fmtSize(o.blob.size))}</small></div>${isPdf(o) || isImg(o) ? `<a class="icon-btn sm" href="${o.url}" target="_blank" rel="noopener" aria-label="Preview ${esc(o.name)}">${icon('eye', 'ic ic-sm')}</a>` : ''}<a class="btn btn-line btn-sm" href="${o.url}" download="${esc(o.name)}">${icon('download', 'ic ic-sm')}Save</a></div>`; }).join('')}${outs.length > 60 ? `<p class="plabel">And ${outs.length - 60} more in the ZIP file.</p>` : ''}</div>` : '';
  const o1 = outs[0];
  const sub = outs.length === 1 ? `<p><b>${esc(o1.name)}</b><br><span style="${o1.good ? 'color:var(--ok);font-weight:500' : ''}">${esc(o1.note ? o1.note + ', ' + fmtSize(o1.blob.size) : fmtSize(o1.blob.size))}</span></p>` : `<p>${fmtSize(outs.reduce((s, o) => s + o.blob.size, 0))} in total.</p>`;
  const main = outs.length === 1
    ? `<a class="btn btn-ink btn-lg" href="${o1.url}" download="${esc(o1.name)}">${icon('download')}Download ${esc(extOf(o1.name).toUpperCase() || 'file')}</a>${isPdf(o1) || isImg(o1) ? `<a class="btn btn-line btn-lg" href="${o1.url}" target="_blank" rel="noopener">${icon('eye')}Preview</a>` : ''}`
    : `<button class="btn btn-ink btn-lg" data-zip>${icon('zip')}Download all as ZIP</button>`;
  let extra = '';
  if (r.md) extra = `<pre class="md-prev">${esc(r.md.length > 20000 ? r.md.slice(0, 20000) + '\n…' : r.md)}</pre>`;
  if (r.diff) extra = diffHtml(r);
  const pdfOuts = outs.filter(isPdf);
  const imgOuts = outs.filter(isImg);
  const nextIds = (pdfOuts.length ? ['compress', 'sign', 'watermark', 'pagenum', 'merge', 'protect', 'split'] : imgOuts.length === outs.length && outs.length ? ['imgcompress', 'imgresize', 'imgcrop', 'imgconvert', 'jpg2pdf'] : []).filter(id => id !== t.id && TOOL[id]).slice(0, 6);
  return `<div class="state"><span class="ok-mark">${icon('check')}</span><h3>${esc(title)}</h3>${sub}
    <div class="res-actions">${main}${r.md ? `<button class="btn btn-line btn-lg" data-copy>${icon('copy')}Copy text</button>` : ''}</div>
    ${extra}${rows && outs.length > 1 ? rows : ''}
    ${nextIds.length ? `<div class="next"><h4>Keep going with this file</h4><div>${nextIds.map(id => `<button class="chip c-${TOOL[id].cat}" data-next="${id}">${icon(TOOL[id].icon)}${esc(TOOL[id].name)}</button>`).join('')}</div></div>` : ''}
    <div class="res-actions"><button class="btn btn-quiet" data-again>${icon('rotate-ccw', 'ic ic-sm')}Start over</button><button class="btn btn-quiet" data-close>${icon('arrow-left', 'ic ic-sm')}All tools</button></div></div>`;
}
function diffHtml(r) {
  const rows = r.diff, show = new Array(rows.length).fill(false);
  rows.forEach((x, i) => { if (x.k !== 'ctx') for (let k = Math.max(0, i - 2); k <= Math.min(rows.length - 1, i + 2); k++) show[k] = true; });
  if (!r.add && !r.del) return `<div class="diff"><div class="diff-stats"><span>The text in both files is identical.</span><span>${esc(r.a)} and ${esc(r.b)}</span></div></div>`;
  let html = '', i = 0;
  const line = x => `<div class="dl ${x.k}"><span class="pg">p${x.p}</span><span class="sg">${x.k === 'add' ? '+' : x.k === 'del' ? '−' : ''}</span><span>${esc(x.t)}</span></div>`;
  while (i < rows.length) {
    if (show[i]) { html += line(rows[i]); i++; continue; }
    let j = i; while (j < rows.length && !show[j]) j++;
    html += `<button class="dl-skip" data-expand="${i}-${j}">Show ${j - i} unchanged line${j - i > 1 ? 's' : ''}</button>`;
    i = j;
  }
  return `<div class="diff"><div class="diff-stats"><span class="a">+${r.add} added</span><span class="r">−${r.del} removed</span><span>Original: ${esc(r.a)}</span></div><div class="diff-body">${html}</div></div>`;
}

/* add files & metadata */
function addFiles(list) {
  const t = WS.tool;
  if (!t || t.accept === 'url' || WS.phase === 'working') return;
  if (['done', 'error', 'server'].includes(WS.phase)) { clearItems(); }
  const acc = ACCEPT[t.accept];
  let files = [...list];
  const bad = files.filter(f => kindOf(f) !== t.accept);
  files = files.filter(f => kindOf(f) === t.accept);
  if (bad.length) toast(`${t.name} works with ${acc.nouns}. Skipped ${bad.length === 1 ? bad[0].name : bad.length + ' files'}.`, 'error');
  const big = files.filter(f => f.size > CONFIG.maxFileMB * 1048576);
  if (big.length) { toast(`${big[0].name} is larger than ${CONFIG.maxFileMB} MB.`, 'error'); files = files.filter(f => !big.includes(f)); }
  if (!files.length) { if (WS.phase !== 'ready') setPhase(WS.items.length ? 'ready' : 'empty'); return; }
  if (!t.multi) { if (files.length > 1) toast(`${t.name} works on one file at a time, so we used ${files[0].name}.`); clearItems(); files = [files[0]]; }
  if (t.max) { const room = t.max - WS.items.length; if (files.length > room) { toast(`${t.name} uses exactly ${t.max} files.`); files = files.slice(0, Math.max(0, room)); } }
  const seq = WS.seq, items = files.map(mkItem);
  WS.items.push(...items);
  setPhase('ready');
  items.forEach(it => { WS.queue = WS.queue.then(() => loadMeta(it, seq)).catch(e => console.warn(e)); });
}
function refreshItem(it) {
  const el = $(`#wsMain [data-iid="${it.id}"]`); if (!el) return;
  const th = $('.thumb', el);
  th.innerHTML = thumbHtml(it);
  if (it.pw && !WS.tool.multi) th.style.setProperty('--ar', it.pw / it.ph);
  const mt = $('.file-meta', el); mt.textContent = metaText(it); mt.classList.toggle('err', !!it.err);
}
let warnedOffline = false;
async function loadMeta(it, seq) {
  if (seq !== WS.seq) return;
  if (it.kind === 'image') {
    it.thumb = URL.createObjectURL(it.file); WS.urls.push(it.thumb);
    try { const b = await createImageBitmap(it.file, { imageOrientation: 'from-image' }); it.pw = b.width; it.ph = b.height; it.note = `${b.width} × ${b.height} px`; b.close(); }
    catch (e) { it.err = WS.tool.client ? 'This image can’t be opened in this browser.' : null; }
    refreshItem(it); updateCta(); return;
  }
  if (it.kind !== 'pdf') return;
  let pdf;
  try { pdf = await pdfjsDoc(it.file); }
  catch (e) {
    if (seq !== WS.seq) return;
    if (e && e.message === 'offline') { if (!warnedOffline) { warnedOffline = true; toast('Previews need an internet connection the first time.', 'error'); } }
    else if (e && e.name === 'PasswordException') { it.note = 'Password-protected'; if (WS.tool.id !== 'unlock' && WS.tool.client) it.err = 'Password-protected. Unlock it first.'; }
    else if (WS.tool.id === 'repair') it.note = 'Damaged file';
    else if (WS.tool.client) it.err = 'This file can’t be read as a PDF.';
    refreshItem(it); updateCta();
    if (WS.tool.pages && WS.items[0] === it) { WS.pages = null; renderMain(); }
    return;
  }
  try {
    if (seq !== WS.seq) return;
    it.pages = pdf.numPages; refreshItem(it);
    const page = await pdf.getPage(1), vp1 = page.getViewport({ scale: 1 });
    it.pw = vp1.width; it.ph = vp1.height;
    const c = await renderPage(page, (WS.tool.multi ? 260 : 640) / vp1.width);
    if (seq !== WS.seq) return;
    it.thumb = await canvasUrl(c, .82); refreshItem(it);
    page.cleanup();
    if (WS.tool.pages && WS.items[0] === it) await loadPages(it, pdf, seq);
  } catch (e) { console.warn(e); }
  finally { pdf.destroy(); updateCta(); }
}
async function loadPages(it, pdf, seq) {
  WS.pages = Array.from({ length: pdf.numPages }, (_, i) => ({ i, rot: 0, thumb: null, key: 'p' + i }));
  WS.allPages = WS.pages.slice();
  renderMain(); updateCta();
  for (let i = 0; i < pdf.numPages; i++) {
    if (seq !== WS.seq) return;
    const page = await pdf.getPage(i + 1);
    const c = await renderPage(page, 170 / page.getViewport({ scale: 1 }).width);
    const url = await canvasUrl(c, .75);
    page.cleanup();
    if (seq !== WS.seq) return;
    const p = WS.allPages[i]; p.thumb = url;
    const el = $(`#wsMain [data-pkey="${p.key}"] .thumb`);
    if (el) el.innerHTML = `<img src="${url}" alt="" style="${rotStyle(p.rot)}">`;
  }
}

async function runTool() {
  const t = WS.tool;
  if (!t || WS.phase === 'working' || $('#wsRun').disabled) return;
  const v = t.validate && t.validate(WS.opts, WS.items);
  if (v) { toast(v, 'error'); return; }
  const items = goodItems();
  clearOutputs(); WS.error = '';
  const seq = WS.seq;
  setPhase('working');
  const ctx = { progress: setProgress, pages: WS.pages && WS.pages.map(p => ({ i: p.i, rot: p.rot })), result: null, alive: () => seq === WS.seq && WS.tool === t };
  try {
    const outs = t.isWorkflow ? await runWorkflow(t.wf, items, ctx) : t.client ? await P[t.id](items, WS.opts, ctx) : await serverRun(t, items, WS.opts, ctx);
    if (seq !== WS.seq || WS.tool !== t) return;
    setProgress(1, 'Done');
    WS.outputs = outs.map(o => ({ ...o, url: URL.createObjectURL(o.blob) }));
    WS.result = ctx.result;
    setPhase('done');
    if (HAS_GSAP() && !REDUCED) gsap.from('#wsMain .ok-mark', { scale: .6, opacity: 0, duration: .45, ease: 'back.out(2.2)' });
  } catch (e) {
    if (seq !== WS.seq) return;
    if (e instanceof NoServer) return setPhase('server');
    if (!(e instanceof UserError)) console.error(e);
    WS.error = e instanceof UserError ? e.message : friendly(e);
    setPhase('error');
  }
}
async function downloadZip(btn) {
  btn.disabled = true; const old = btn.innerHTML; btn.textContent = 'Preparing ZIP…';
  try {
    const JSZip = await lib('jszip'), zip = new JSZip();
    WS.outputs.forEach(o => zip.file(o.name, o.blob));
    const blob = await zip.generateAsync({ type: 'blob' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
    a.download = `fileora-${WS.tool.id}.zip`; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  } catch (e) { toast('The ZIP file couldn’t be created. Save the files one by one instead.', 'error'); }
  btn.disabled = false; btn.innerHTML = old;
}
function pickFiles(camera) {
  const t = WS.tool, inp = camera ? $('#wsCam') : $('#wsFile');
  if (!camera) { inp.accept = ACCEPT[t.accept].input; inp.multiple = !!t.multi; }
  inp.value = ''; inp.click();
}
function move(arr, from, to) { if (to < 0 || to >= arr.length || from === to) return; const [x] = arr.splice(from, 1); arr.splice(to, 0, x); }

function initWorkspace() {
  ['#wsFile', '#wsCam'].forEach(s => $(s).addEventListener('change', e => { const f = [...e.target.files]; e.target.value = ''; if (f.length) addFiles(f); }));
  $('#wsRun').addEventListener('click', runTool);
  const main = $('#wsMain');
  main.addEventListener('click', e => {
    const b = e.target.closest('button, a'); if (!b) return;
    const d = b.dataset;
    if ('pick' in d) return pickFiles(false);
    if ('cam' in d) return pickFiles(true);
    if ('clear' in d || 'again' in d) { clearItems(); WS.opts.url = WS.tool.accept === 'url' ? WS.opts.url : undefined; return setPhase('empty'); }
    if ('retry' in d) return setPhase(WS.items.length ? 'ready' : 'empty');
    if ('sort' in d) { WS.items.sort((a, c) => a.name.localeCompare(c.name, undefined, { numeric: true })); return renderMain(); }
    if ('swap' in d) { WS.items.reverse(); return renderMain(); }
    if ('zip' in d) return downloadZip(b);
    if ('copy' in d) { navigator.clipboard.writeText(WS.result.md).then(() => toast('Copied to the clipboard', 'ok'), () => toast('Copy isn’t allowed here. Download the file instead.', 'error')); return; }
    if ('next' in d) { const files = WS.outputs.length ? WS.outputs.map(o => new File([o.blob], o.name, { type: o.blob.type || 'application/pdf' })) : WS.items.map(i => i.file); return openTool(d.next, files); }
    if ('expand' in d) { const [a, c] = d.expand.split('-').map(Number); const rows = WS.result.diff.slice(a, c); b.outerHTML = rows.map(x => `<div class="dl ctx"><span class="pg">p${x.p}</span><span class="sg"></span><span>${esc(x.t)}</span></div>`).join(''); return; }
    if ('remove' in d) { WS.items = WS.items.filter(i => i.id !== d.remove); if (!WS.items.length) { clearItems(); return setPhase('empty'); } renderMain(); return updateCta(); }
    if ('move' in d) { const el = b.closest('[data-iid]'), i = WS.items.findIndex(x => x.id === el.dataset.iid); move(WS.items, i, i + +d.move); renderMain(); const nb = $(`#wsMain [data-iid="${el.dataset.iid}"] [data-move="${d.move}"]`); (nb && !nb.disabled ? nb : $(`#wsMain [data-iid="${el.dataset.iid}"] [data-move]:not([disabled])`))?.focus(); return; }
    if ('preset' in d) { if (WS.allPages) { WS.pages = WS.allPages.map(p => (p.rot = 0, p)); renderMain(); updateCta(); } return; }
    const pel = b.closest('[data-pkey]');
    if (pel && WS.pages) {
      const k = WS.pages.findIndex(p => p.key === pel.dataset.pkey), p = WS.pages[k];
      if ('pmove' in d) { move(WS.pages, k, k + +d.pmove); renderMain(); $(`#wsMain [data-pkey="${p.key}"] [data-pmove="${d.pmove}"]`)?.focus(); }
      else if ('prot' in d) { p.rot = (p.rot + 90) % 360; const img = $('.thumb img', pel); if (img) img.style.cssText = rotStyle(p.rot); $('.file-name', pel).textContent = `Page ${p.i + 1}${p.rot ? `, turned ${p.rot}°` : ''}`; }
      else if ('pdel' in d) { WS.pages.splice(k, 1); renderMain(); updateCta(); }
    }
  });
  /* drag to reorder (files and pages) */
  let dragKey = null;
  const keyOf = el => el.dataset.iid || el.dataset.pkey;
  main.addEventListener('dragstart', e => { const el = e.target.closest('.file[draggable="true"]'); if (!el) return; dragKey = keyOf(el); el.classList.add('dragging'); e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', dragKey); });
  main.addEventListener('dragover', e => {
    if (!dragKey) return;
    const el = e.target.closest('.file[draggable="true"]'); e.preventDefault();
    $$('.drop-before,.drop-after', main).forEach(x => x.classList.remove('drop-before', 'drop-after'));
    if (!el || keyOf(el) === dragKey) return;
    const r = el.getBoundingClientRect(); el.classList.add(e.clientX < r.left + r.width / 2 ? 'drop-before' : 'drop-after');
  });
  main.addEventListener('drop', e => {
    if (!dragKey) return;
    e.preventDefault(); e.stopPropagation();
    const el = e.target.closest('.file[draggable="true"]');
    if (el && keyOf(el) !== dragKey) {
      const arr = WS.pages && WS.tool.pages ? WS.pages : WS.items, kf = x => x.id || x.key;
      const from = arr.findIndex(x => kf(x) === dragKey);
      const [x] = arr.splice(from, 1);
      let to = arr.findIndex(y => kf(y) === keyOf(el));
      if (el.classList.contains('drop-after')) to++;
      arr.splice(to, 0, x);
    }
    dragKey = null; renderMain();
  });
  main.addEventListener('dragend', () => { dragKey = null; $$('.dragging,.drop-before,.drop-after', main).forEach(x => x.classList.remove('dragging', 'drop-before', 'drop-after')); });

  /* workflow builder */
  $('#wfAdd').addEventListener('click', e => { const b = e.target.closest('[data-wfadd]'); if (!b) return; const id = b.dataset.wfadd; WFB.steps.push({ tool: id, o: defaults(TOOL[id]) }); WFB.open = TOOL[id].opts.length ? WFB.steps.length - 1 : -1; renderWfb(); });
  $('#wfSteps').addEventListener('click', e => {
    const b = e.target.closest('[data-wfb]'); if (!b) return;
    const i = +b.closest('[data-i]').dataset.i, a = b.dataset.wfb;
    if (a === 'up') { move(WFB.steps, i, i - 1); if (WFB.open === i) WFB.open = i - 1; }
    if (a === 'down') { move(WFB.steps, i, i + 1); if (WFB.open === i) WFB.open = i + 1; }
    if (a === 'del') { WFB.steps.splice(i, 1); WFB.open = -1; }
    if (a === 'opts') WFB.open = WFB.open === i ? -1 : i;
    renderWfb();
  });
  $('#wfSave').addEventListener('click', () => {
    if (!WFB.steps.length) return toast('Add at least one step first.', 'error');
    const name = $('#wfName').value.trim() || `My workflow ${userWfs.length + 1}`;
    const w = { id: 'u' + Date.now().toString(36), name, steps: WFB.steps.map(s => ({ tool: s.tool, o: { ...s.o } })) };
    userWfs.push(w); saveWfs(); closeOv($('#wfModal'));
    toast(`“${name}” saved. You’ll find it under Workflows.`, 'ok');
    setTimeout(() => setCat('workflows', true), 200);
  });
}

/* ---------------- dropped files: suggestions ---------------- */
function showSuggest(files) {
  const groups = {};
  files.forEach(f => { const k = kindOf(f); (groups[k] = groups[k] || []).push(f); });
  const sections = [];
  if (groups.pdf) {
    const n = groups.pdf.length;
    const ids = n > 1 ? ['merge', 'compress', ...(n === 2 ? ['compare'] : []), 'rotate', 'pagenum', 'watermark', 'pdf2jpg', 'pdf2word', 'protect'] : ['compress', 'split', 'organize', 'pdf2word', 'pdf2jpg', 'sign', 'edit', 'watermark', 'pagenum', 'rotate', 'crop', 'pdf2md', 'summarize', 'translate', 'protect'];
    sections.push({ title: n > 1 ? `For your ${n} PDFs` : 'For your PDF', ids: ids.filter(id => TOOL[id]), files: groups.pdf });
  }
  if (groups.image) sections.push({ title: groups.image.length > 1 ? `For your ${groups.image.length} images` : 'For your image', ids: ['imgcompress', 'imgresize', 'imgcrop', 'imgconvert', 'jpg2pdf', 'scan'].filter(id => TOOL[id]), files: groups.image });
  ['word', 'ppt', 'excel'].forEach(k => { const id = { word: 'word2pdf', ppt: 'ppt2pdf', excel: 'excel2pdf' }[k]; if (groups[k] && TOOL[id]) sections.push({ title: `For your ${ACCEPT[k].nouns}`, ids: [id], files: groups[k] }); });
  for (let i = sections.length - 1; i >= 0; i--) if (!sections[i].ids.length) sections.splice(i, 1);
  const unknown = [...(groups.other || []), ...(groups.html || [])];
  if (sections.length === 1 && sections[0].ids.length === 1 && !unknown.length) return openTool(sections[0].ids[0], sections[0].files);
  const show = files.slice(0, 4).map(f => `<span class="chip">${icon(kindOf(f) === 'image' ? 'image' : 'file')}${esc(f.name.length > 34 ? f.name.slice(0, 31) + '…' : f.name)}</span>`).join('') + (files.length > 4 ? `<span class="chip">+${files.length - 4} more</span>` : '');
  $('#sgTitle').textContent = files.length === 1 ? `What should we do with ${files[0].name.length > 40 ? 'this file' : files[0].name}?` : `What should we do with these ${files.length} files?`;
  $('#sgSub').textContent = sections.length ? 'Pick a tool. Your files go straight into it.' : '';
  $('#sgFiles').innerHTML = show;
  $('#sgBody').innerHTML = sections.map((s, si) => `<h3 class="sg-sub">${esc(s.title)}</h3><div class="sg-grid">${s.ids.map(id => { const t = TOOL[id]; return `<button class="sg-item c-${t.cat}" data-sg="${si}:${id}"><span class="${tileCls(t)} sm">${icon(t.icon)}</span><span><b>${esc(t.name)}</b><small>${t.client ? 'In browser' : 'Secure server'}</small></span></button>`; }).join('')}</div>`).join('')
    + (unknown.length ? `<div class="note-box" style="margin-top:18px">${icon('info')}<span>Fileora can’t open ${unknown.length === 1 ? esc(unknown[0].name) : unknown.length + ' of these files'} yet. We support PDF, Word, Excel, PowerPoint and image files.</span></div>` : '');
  $('#sgBody').onclick = e => { const b = e.target.closest('[data-sg]'); if (!b) return; const [si, id] = b.dataset.sg.split(':'); openTool(id, sections[+si].files); };
  if ($('#suggest').hidden) openOv($('#suggest'));
}
function initDrop() {
  let depth = 0;
  const hasFiles = e => e.dataTransfer && [...(e.dataTransfer.types || [])].includes('Files');
  const hide = () => { $('#pageDrop').hidden = true; $('#dz') && $('#dz').classList.remove('over'); };
  addEventListener('dragenter', e => {
    if (!hasFiles(e)) return; e.preventDefault(); depth++;
    if (!$('#ws').hidden) { $('#dz') && $('#dz').classList.add('over'); return; }
    if (!OV.length) $('#pageDrop').hidden = false;
  });
  addEventListener('dragover', e => { if (hasFiles(e)) { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; } });
  addEventListener('dragleave', e => { if (!hasFiles(e)) return; depth--; if (depth <= 0) { depth = 0; hide(); } });
  addEventListener('drop', e => {
    if (!hasFiles(e)) return; e.preventDefault(); depth = 0; hide();
    const files = [...e.dataTransfer.files]; if (!files.length) return;
    if (!$('#ws').hidden && WS.tool) addFiles(files);
    else if (!OV.length) showSuggest(files);
  });
  $('#heroFile').addEventListener('change', e => { const f = [...e.target.files]; e.target.value = ''; if (f.length) showSuggest(f); });
}

/* ---------------- hero: light-table animation ---------------- */
function initStage() {
  if (!HAS_GSAP()) return;
  if (window.Flip) gsap.registerPlugin(Flip);
  const sh1 = $('#sh1'), sh2 = $('#sh2'), badge = $('#stBadge'), size = $('#stSize'), sizeV = $('#stSizeV'), sig = $('#sigPath'), cap = $('#stCap'), capUse = $('#stCapIcon use'), band = $('#sh2band'), tag = $('#sh2tag');
  if (REDUCED) { gsap.set(sh1, { x: -26, rotation: -4 }); gsap.set(sh2, { x: 18, y: 10, rotation: 3 }); gsap.set('#sig', { opacity: 1 }); return; }
  const len = sig.getTotalLength(), sz = { v: 8.4 };
  const setCap = (text, ic) => gsap.to('.stage-cap', { opacity: 0, y: -4, duration: .18, onComplete: () => { cap.textContent = text; capUse.setAttribute('href', '#i-' + ic); gsap.to('.stage-cap', { opacity: 1, y: 0, duration: .25 }); } });
  const paint = (c, label) => { band.style.background = c; tag.style.background = c; tag.textContent = label; };
  const tl = gsap.timeline({ repeat: -1, defaults: { ease: 'power3.inOut' }, delay: .6 });
  tl.set([sh1, sh2], { opacity: 0, y: 40, rotationY: 0, scale: 1 })
    .set(sh1, { x: -120, rotation: -9 }).set(sh2, { x: 120, rotation: 8 })
    .set([badge, size], { opacity: 0, y: 6 }).set(sz, { v: 8.4 })
    .set(sig, { strokeDasharray: len, strokeDashoffset: len }).set('#sig', { opacity: 1 })
    .call(() => { paint('#E0464C', 'PDF'); sizeV.textContent = '8.4'; setCap('Merge PDF', 'merge'); })
    .to([sh1, sh2], { opacity: 1, y: 0, duration: .7, stagger: .12, ease: 'power3.out' })
    .to(sh1, { x: -14, rotation: -4, duration: .9 }, '+=.45')
    .to(sh2, { x: 12, y: 12, rotation: 3, duration: .9 }, '<')
    .to(badge, { opacity: 1, y: 0, duration: .35, ease: 'back.out(2)' }, '-=.15')
    .to(badge, { opacity: 0, y: -6, duration: .3 }, '+=1.1')
    .call(() => setCap('Compress PDF', 'compress'))
    .to(size, { opacity: 1, y: 0, duration: .3 })
    .to([sh1, sh2], { scale: .8, duration: .9, ease: 'power2.inOut' }, '+=.15')
    .to(sz, { v: 1.9, duration: .9, ease: 'power2.inOut', onUpdate: () => { sizeV.textContent = sz.v.toFixed(1); } }, '<')
    .to(size, { opacity: 0, duration: .3 }, '+=.9')
    .call(() => setCap('Sign PDF', 'sign'))
    .to(sh1, { opacity: 0, x: -50, duration: .4 }, '<')
    .to(sh2, { scale: 1, x: 0, y: 0, rotation: 0, duration: .6 }, '<')
    .to(sig, { strokeDashoffset: 0, duration: 1.3, ease: 'power1.inOut' }, '+=.1')
    .call(() => setCap('PDF to Word', 'doc'), null, '+=.6')
    .to(sh2, { rotationY: 90, duration: .3, ease: 'power2.in' })
    .call(() => paint('#2F6BF3', 'DOCX'))
    .to(sh2, { rotationY: 0, duration: .42, ease: 'power2.out' })
    .to(sh2, { opacity: 0, y: -24, duration: .5, ease: 'power2.in' }, '+=1.4');
  if ('IntersectionObserver' in window) new IntersectionObserver(([en]) => { en.isIntersecting ? tl.resume() : tl.pause(); }).observe($('#stage'));

  /* one orchestrated page-load moment */
  gsap.from('.h-display .ln > span', { yPercent: 108, duration: .95, ease: 'power4.out', stagger: .1 });
  gsap.from(['.lede', '.hero-search', '.quick', '.hero-note'], { opacity: 0, y: 14, duration: .7, ease: 'power3.out', stagger: .07, delay: .3, clearProps: 'transform,opacity' });
  gsap.from('#stage', { opacity: 0, scale: .97, duration: .9, ease: 'power3.out', delay: .15, clearProps: 'transform,opacity' });
}

/* ---------------- boot ---------------- */
if (TOOL.sign) TOOL.sign.validate = o => o.signature ? '' : 'Draw or type your signature to continue.';
if (TOOL.watermark) TOOL.watermark.validate = o => String(o.text || '').trim() ? '' : 'Type the watermark text to continue.';
if (TOOL.split) TOOL.split.validate = o => o.mode === 'ranges' && !String(o.ranges || '').trim() ? 'Enter the pages to extract, like 1-3, 5.' : '';
initCore();
initWorkspace();
initDrop();
initStage();
route();
